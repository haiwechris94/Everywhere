module.exports = {
  Partner: require('./Partner'),
  Center: require('./Center'),
  FocusPeople: require('./FocusPeople'),
  Adoption: require('./Adoption'),
  Programme: require('./Programme'),
  Target: require('./Target'),
  SendingAxis: require('./SendingAxis'),
};
