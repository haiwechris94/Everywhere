/**
 * Partner — église, mission ou organisation partenaire de WAMM.
 * (Vineyard, Emmanuel World Mission, MIDJ, Elim, Word of God Church, Mergon…)
 */
const mongoose = require('mongoose');
const { Schema } = mongoose;

const PARTNER_TYPES = ['church', 'mission', 'denomination', 'agency', 'institute', 'foundation', 'other'];
const PARTNERSHIP_LEVELS = ['strategic', 'field', 'adopter', 'financial', 'prayer'];

const ContactSchema = new Schema(
  {
    name: { type: String, trim: true, default: '' },
    role: { type: String, trim: true, default: '' },
    phone: { type: String, trim: true, default: '' },
    email: { type: String, trim: true, lowercase: true, default: '' },
  },
  { _id: false }
);

const partnerSchema = new Schema(
  {
    name: { type: String, required: [true, 'Le nom du partenaire est requis'], trim: true, maxlength: 200 },
    acronym: { type: String, trim: true, default: '', maxlength: 30 },
    type: { type: String, enum: PARTNER_TYPES, default: 'church' },
    levels: { type: [{ type: String, enum: PARTNERSHIP_LEVELS }], default: ['field'] },
    countryCodes: { type: [String], default: [] }, // ISO alpha-2
    city: { type: String, trim: true, default: '' },
    since: { type: Number, min: 1950, max: 2100 },
    status: { type: String, enum: ['active', 'prospect', 'paused', 'ended'], default: 'active' },
    contacts: { type: [ContactSchema], default: [] },
    website: { type: String, trim: true, default: '' },
    description: { type: String, trim: true, maxlength: 3000, default: '' },
    supportTypes: { type: [String], default: [] }, // ex. « Formation des leaders », « Coaching »
    createdBy: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

partnerSchema.index({ name: 1 }, { unique: true });
partnerSchema.index({ countryCodes: 1 });
partnerSchema.statics.TYPES = PARTNER_TYPES;
partnerSchema.statics.LEVELS = PARTNERSHIP_LEVELS;

module.exports = mongoose.model('Partner', partnerSchema, 'wamm_partners');
