/**
 * Target — objectif chiffré WAMM (objectifs cumulés 2026-2030, cibles
 * annuelles par pays ou programme). Le « réalisé » est calculé à partir des
 * données saisies (centres, adoptions, partenaires…) ; `manualActual`
 * permet de forcer une valeur quand la donnée n'est pas suivie dans l'appli.
 */
const mongoose = require('mongoose');
const { Schema } = mongoose;

// Indicateurs suivis. `auto` = calculé automatiquement par /api/wamm/overview.
const INDICATORS = {
  ifm: { fr: 'Instituts de formation missionnaire (IFM)', en: 'Missionary Training Institutes', auto: true },
  ceimp: { fr: "Centres d'équipement intégrés (CEIMP)", en: 'Integrated Equipping Centres', auto: true },
  peoplesEngaged: { fr: 'Peuples non atteints engagés', en: 'Unreached people groups engaged', auto: true },
  countries: { fr: "Pays d'intervention", en: 'Countries of intervention', auto: true },
  partners: { fr: 'Partenaires stratégiques', en: 'Strategic partners', auto: true },
  personsOfPeace: { fr: 'Personnes de paix', en: 'Persons of Peace', auto: true },
  churchesPlanted: { fr: 'Églises implantées', en: 'Churches planted', auto: true },
  discoveryGroups: { fr: 'Groupes de découverte biblique', en: 'Discovery Bible groups', auto: true },
  baptisms: { fr: 'Baptêmes', en: 'Baptisms', auto: true },
  newBelievers: { fr: 'Nouveaux croyants', en: 'New believers', auto: true },
  leadersTrained: { fr: 'Leaders formés', en: 'Leaders trained', auto: true },
  secondGenLeaders: { fr: 'Leaders de 2e génération', en: '2nd-generation leaders', auto: true },
  workers: { fr: 'Ouvriers pionniers envoyés', en: 'Pioneer workers sent', auto: true },
};

const targetSchema = new Schema(
  {
    indicator: { type: String, enum: Object.keys(INDICATORS), required: true },
    scope: { type: String, enum: ['global', 'country', 'programme'], default: 'global' },
    countryCode: { type: String, uppercase: true, trim: true, default: '' },
    programme: { type: Schema.Types.ObjectId, ref: 'Programme' },
    periodLabel: { type: String, trim: true, default: '2026-2030' },
    startYear: { type: Number, default: 2026 },
    endYear: { type: Number, default: 2030 },
    value: { type: Number, min: 0, required: true },
    manualActual: { type: Number, min: 0, default: null },
    notes: { type: String, trim: true, default: '' },
  },
  { timestamps: true }
);

targetSchema.index({ indicator: 1, scope: 1, countryCode: 1, programme: 1, periodLabel: 1 }, { unique: true });
targetSchema.statics.INDICATORS = INDICATORS;

module.exports = mongoose.model('Target', targetSchema, 'wamm_targets');
