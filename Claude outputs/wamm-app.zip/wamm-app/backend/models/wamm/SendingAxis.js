/**
 * SendingAxis — axe d'envoi / de rayonnement : d'un centre pivot vers un
 * peuple, une ville ou un pays voisin (schéma du corridor Ghana-Togo-Bénin,
 * axes Abidjan → Saint-Louis et Abidjan → Kara).
 */
const mongoose = require('mongoose');
const { Schema } = mongoose;
const { PointSchema } = require('./_shared');

const sendingAxisSchema = new Schema(
  {
    label: { type: String, required: true, trim: true, maxlength: 200 },
    kind: { type: String, enum: ['sending', 'outreach', 'corridor'], default: 'sending' },
    fromCenter: { type: Schema.Types.ObjectId, ref: 'Center' },
    fromName: { type: String, trim: true, default: '' },
    from: { type: PointSchema, required: true },
    toName: { type: String, trim: true, required: true },
    to: { type: PointSchema, required: true },
    targetPeoples: { type: [String], default: [] },
    countryCodes: { type: [String], default: [] },
    regionId: { type: String, trim: true, uppercase: true, default: '' },
    status: { type: String, enum: ['active', 'planned', 'paused'], default: 'active' },
    locationApprox: { type: Boolean, default: true },
    notes: { type: String, trim: true, default: '' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('SendingAxis', sendingAxisSchema, 'wamm_sending_axes');
