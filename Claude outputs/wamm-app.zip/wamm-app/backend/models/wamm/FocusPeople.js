/**
 * FocusPeople — peuple prioritaire suivi par WAMM (panier d'adoption, lot,
 * ouvriers pionniers nécessaires). Peut être relié à la fiche MasterPeople
 * (référentiel Joshua Project) quand elle existe.
 */
const mongoose = require('mongoose');
const { Schema } = mongoose;
const { PointSchema } = require('./_shared');

const REACH_STATUSES = ['frontier', 'unreached', 'minimally_reached', 'partially_reached', 'reached', 'unknown'];
const ENGAGEMENT_STAGES = ['identified', 'adopted', 'workers_sent', 'engaged', 'movement'];

const focusPeopleSchema = new Schema(
  {
    name: { type: String, required: [true, 'Le nom du peuple est requis'], trim: true, maxlength: 200 },
    alternateNames: { type: [String], default: [] },
    countryCode: { type: String, required: true, uppercase: true, trim: true }, // pays principal (alpha-2)
    otherCountryCodes: { type: [String], default: [] }, // peuples transfrontaliers
    masterPeople: { type: Schema.Types.ObjectId, ref: 'MasterPeople' },
    lot: { type: String, trim: true, default: '' }, // lot d'adoption (Guinée : lots 1, 2, 3, 7)
    population: { type: Number, min: 0, default: 0 },
    reachStatus: { type: String, enum: REACH_STATUSES, default: 'unknown' },
    religion: { type: String, trim: true, default: '' },
    workersNeeded: { type: Number, min: 0, default: 0 },
    workersInPlace: { type: Number, min: 0, default: 0 },
    stage: { type: String, enum: ENGAGEMENT_STAGES, default: 'identified' },
    area: { type: String, trim: true, default: '' }, // zone / préfecture
    location: { type: PointSchema, default: undefined },
    locationApprox: { type: Boolean, default: true }, // position indicative (zone du peuple)
    // Adoptants annoncés par une source (ex. 19 adoptants à la conférence de
    // Lomé) quand le détail nominatif n'est pas encore saisi.
    declaredAdopters: { type: Number, min: 0, default: 0 },
    adoptionEvent: { type: String, trim: true, default: '' },
    isPastoral: { type: Boolean, default: false }, // peuple nomade / pastoral (Peuls)
    programme: { type: Schema.Types.ObjectId, ref: 'Programme' },
    notes: { type: String, trim: true, maxlength: 3000, default: '' },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

focusPeopleSchema.index({ countryCode: 1, name: 1 }, { unique: true });
focusPeopleSchema.index({ location: '2dsphere' }, { sparse: true });
focusPeopleSchema.statics.REACH_STATUSES = REACH_STATUSES;
focusPeopleSchema.statics.STAGES = ENGAGEMENT_STAGES;

module.exports = mongoose.model('FocusPeople', focusPeopleSchema, 'wamm_focus_peoples');
