/**
 * Center — implantation WAMM sur le terrain.
 * Types : institut de formation missionnaire (IFM), centre d'équipement intégré
 * (CEIMP), alphabétisation, santé, agriculture, radio, centre pivot (hub).
 */
const mongoose = require('mongoose');
const { Schema } = mongoose;
const { PointSchema, DmmResultSchema, sumResults } = require('./_shared');

const CENTER_TYPES = ['ifm', 'ceimp', 'literacy', 'health', 'agricultural', 'radio', 'hub', 'office'];
const CENTER_STATUSES = ['existing', 'new', 'planned', 'paused', 'closed'];

const centerSchema = new Schema(
  {
    name: { type: String, required: [true, 'Le nom du centre est requis'], trim: true, maxlength: 200 },
    type: { type: String, enum: CENTER_TYPES, required: true, default: 'ceimp' },
    status: { type: String, enum: CENTER_STATUSES, default: 'existing' },
    countryCode: { type: String, required: true, uppercase: true, trim: true }, // alpha-2
    zone: { type: String, trim: true, default: '' }, // ex. « Zone 1 : Nord-Est »
    city: { type: String, trim: true, default: '' },
    location: { type: PointSchema, default: undefined },
    locationApprox: { type: Boolean, default: false },
    partner: { type: Schema.Types.ObjectId, ref: 'Partner' },
    programme: { type: Schema.Types.ObjectId, ref: 'Programme' },
    openingYear: { type: Number, min: 1990, max: 2100 },
    peoplesServed: { type: [String], default: [] }, // noms des peuples
    focusPeoples: [{ type: Schema.Types.ObjectId, ref: 'FocusPeople' }],
    description: { type: String, trim: true, maxlength: 3000, default: '' },
    results: { type: [DmmResultSchema], default: [] },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true, toJSON: { virtuals: true }, toObject: { virtuals: true } }
);

centerSchema.virtual('totals').get(function totals() {
  return sumResults(this.results);
});

centerSchema.index({ countryCode: 1, type: 1 });
centerSchema.index({ location: '2dsphere' }, { sparse: true });
centerSchema.statics.TYPES = CENTER_TYPES;
centerSchema.statics.STATUSES = CENTER_STATUSES;

module.exports = mongoose.model('Center', centerSchema, 'wamm_centers');
