/**
 * Programme — programme WAMM (remplace les initiatives ESP300/YCS du réseau NG).
 * Ex. « Programme peul Togo-Bénin-Tchad » avec Mergon, adoption des peuples,
 * ministère de compassion, mouvement de prière.
 */
const mongoose = require('mongoose');
const { Schema } = mongoose;
const { DmmResultSchema, sumResults } = require('./_shared');

const PILLARS = ['dmm', 'compassion', 'prayer'];

const AnnualTargetSchema = new Schema(
  {
    indicator: { type: String, required: true, trim: true }, // clé d'indicateur (voir Target.INDICATORS)
    value: { type: Number, min: 0, required: true },
  },
  { _id: false }
);

const programmeSchema = new Schema(
  {
    key: { type: String, required: true, unique: true, uppercase: true, trim: true, maxlength: 40 },
    name: { type: String, required: true, trim: true, maxlength: 200 },
    pillar: { type: String, enum: PILLARS, default: 'dmm' },
    status: { type: String, enum: ['draft', 'validation', 'active', 'completed', 'paused'], default: 'active' },
    description: { type: String, trim: true, maxlength: 4000, default: '' },
    regionId: { type: String, trim: true, uppercase: true, default: '' }, // ex. FRONT-PEUL
    countryCodes: { type: [String], default: [] },
    partners: [{ type: Schema.Types.ObjectId, ref: 'Partner' }],
    targetPeoples: { type: [String], default: [] },
    startYear: { type: Number, min: 2000, max: 2100 },
    endYear: { type: Number, min: 2000, max: 2100 },
    annualTargets: { type: [AnnualTargetSchema], default: [] },
    results: { type: [DmmResultSchema], default: [] },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true, toJSON: { virtuals: true }, toObject: { virtuals: true } }
);

programmeSchema.virtual('totals').get(function totals() {
  return sumResults(this.results);
});

programmeSchema.statics.PILLARS = PILLARS;

module.exports = mongoose.model('Programme', programmeSchema, 'wamm_programmes');
