/**
 * Petits schémas partagés par les modèles WAMM.
 */
const mongoose = require('mongoose');
const { Schema } = mongoose;

// Point GeoJSON [lng, lat] — optionnel sur la plupart des entités.
const PointSchema = new Schema(
  {
    type: { type: String, enum: ['Point'], default: 'Point' },
    coordinates: {
      type: [Number],
      validate: {
        validator: (v) => !v || v.length === 0 || (v.length === 2 && v[0] >= -180 && v[0] <= 180 && v[1] >= -90 && v[1] <= 90),
        message: 'Coordonnées invalides (attendu [longitude, latitude])',
      },
    },
  },
  { _id: false }
);

// Indicateurs DMM saisis pour une période (résultats d'un centre, d'un programme…).
const DmmResultSchema = new Schema(
  {
    periodLabel: { type: String, trim: true, required: true }, // ex. « Avril-Mai 2026 »
    from: { type: Date },
    to: { type: Date },
    personsOfPeace: { type: Number, min: 0, default: 0 },
    discoveryGroups: { type: Number, min: 0, default: 0 },
    churchesPlanted: { type: Number, min: 0, default: 0 },
    baptisms: { type: Number, min: 0, default: 0 },
    newBelievers: { type: Number, min: 0, default: 0 },
    leadersTrained: { type: Number, min: 0, default: 0 },
    secondGenLeaders: { type: Number, min: 0, default: 0 },
    notes: { type: String, trim: true, default: '' },
  },
  { _id: true, timestamps: true }
);

const RESULT_FIELDS = ['personsOfPeace', 'discoveryGroups', 'churchesPlanted', 'baptisms', 'newBelievers', 'leadersTrained', 'secondGenLeaders'];

function sumResults(results = []) {
  const out = Object.fromEntries(RESULT_FIELDS.map((k) => [k, 0]));
  (results || []).forEach((r) => RESULT_FIELDS.forEach((k) => { out[k] += Number(r && r[k]) || 0; }));
  return out;
}

module.exports = { PointSchema, DmmResultSchema, RESULT_FIELDS, sumResults };
