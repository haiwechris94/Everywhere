/**
 * Adoption — engagement d'une église / organisation envers un peuple
 * (ex. conférence de vision de Lomé, 18 juillet 2026 : 27 adoptants).
 */
const mongoose = require('mongoose');
const { Schema } = mongoose;

const COMMITMENTS = ['prayer', 'workers', 'finance', 'dmm', 'compassion', 'research'];

const adoptionSchema = new Schema(
  {
    focusPeople: { type: Schema.Types.ObjectId, ref: 'FocusPeople', required: true },
    partner: { type: Schema.Types.ObjectId, ref: 'Partner' },
    adopterName: { type: String, trim: true, default: '' }, // si l'adoptant n'est pas (encore) un partenaire enregistré
    event: { type: String, trim: true, default: '' },
    date: { type: Date },
    commitments: { type: [{ type: String, enum: COMMITMENTS }], default: ['prayer'] },
    workersCommitted: { type: Number, min: 0, default: 0 },
    status: { type: String, enum: ['committed', 'active', 'paused', 'ended'], default: 'committed' },
    notes: { type: String, trim: true, maxlength: 2000, default: '' },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

adoptionSchema.index({ focusPeople: 1 });
adoptionSchema.index({ partner: 1 });
adoptionSchema.statics.COMMITMENTS = COMMITMENTS;

module.exports = mongoose.model('Adoption', adoptionSchema, 'wamm_adoptions');
