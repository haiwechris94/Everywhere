#!/usr/bin/env node
/**
 * Seed WAMM — charge les données de démarrage (backend/seed/wammSeed2026.js).
 *
 *   node scripts/seedWamm.js            # ajoute / met à jour (idempotent)
 *   node scripts/seedWamm.js --reset    # vide d'abord les collections WAMM
 *   node scripts/seedWamm.js --dry-run  # valide les données sans rien écrire
 *
 * Crée aussi un compte administrateur si ADMIN_EMAIL / ADMIN_PASSWORD sont
 * définis dans .env et que le compte n'existe pas encore.
 */
require('dotenv').config({ path: require('path').join(__dirname, '../.env') });
const mongoose = require('mongoose');
const seed = require('../seed/wammSeed2026');
const { Partner, Center, FocusPeople, Adoption, Programme, Target, SendingAxis } = require('../models/wamm');
const Activity = require('../models/Activity');
const User = require('../models/User');

const RESET = process.argv.includes('--reset');
const DRY = process.argv.includes('--dry-run');
const log = (...a) => console.log('[seed-wamm]', ...a);

async function upsert(Model, filter, doc) {
  const existing = await Model.findOne(filter);
  if (existing) { existing.set(doc); await existing.save(); return existing; }
  return Model.create(doc);
}

function validateAll() {
  const errors = [];
  const check = (Model, doc, label) => {
    const e = new Model(doc).validateSync();
    if (e) errors.push(`${label}: ${e.message}`);
  };
  const fakeId = new mongoose.Types.ObjectId();
  seed.partners.forEach(({ key, ...p }) => check(Partner, p, `partner ${key}`));
  seed.programmes.forEach(({ partnerKeys, ...p }) => check(Programme, p, `programme ${p.key}`));
  seed.centers.forEach(({ partnerKey, programmeKey, churches, ...c }) => check(Center, c, `center ${c.name}`));
  seed.focusPeoples.forEach(({ partnerKeys, programmeKey, ...f }) => check(FocusPeople, f, `people ${f.name}`));
  seed.axes.forEach(({ fromHub, ...a }) => check(SendingAxis, a, `axis ${a.label}`));
  seed.targets.forEach((t) => check(Target, t, `target ${t.indicator}`));
  seed.activities.forEach(([from, to, title, type, mec, cc]) => check(Activity, {
    type, mecPillar: mec, title, description: title, date: new Date(from), endDate: new Date(to), countryCode: cc, user: fakeId,
  }, `activity ${title}`));
  return errors;
}

async function main() {
  const errors = validateAll();
  if (errors.length) {
    errors.forEach((e) => console.error('  ✗', e));
    throw new Error(`${errors.length} enregistrement(s) invalide(s)`);
  }
  log('Validation OK :', seed.partners.length, 'partenaires,', seed.centers.length, 'centres,', seed.focusPeoples.length, 'peuples,',
    seed.programmes.length, 'programmes,', seed.axes.length, 'axes,', seed.targets.length, 'objectifs,', seed.activities.length, 'activités');
  if (DRY) return;

  if (!process.env.MONGODB_URI) throw new Error('MONGODB_URI manquant dans backend/.env');
  await mongoose.connect(process.env.MONGODB_URI);
  log('Connecté à', mongoose.connection.name);

  if (RESET) {
    await Promise.all([Partner, Center, FocusPeople, Adoption, Programme, Target, SendingAxis].map((M) => M.deleteMany({})));
    await Activity.deleteMany({ mecPillar: { $in: ['mobilisation', 'equipement', 'coaching'] } });
    log('Collections WAMM vidées');
  }

  // Compte administrateur
  let admin = null;
  if (process.env.ADMIN_EMAIL) {
    admin = await User.findOne({ email: process.env.ADMIN_EMAIL.toLowerCase() });
    if (!admin && process.env.ADMIN_PASSWORD) {
      admin = await User.create({ name: process.env.ADMIN_NAME || 'Administrateur WAMM', email: process.env.ADMIN_EMAIL, password: process.env.ADMIN_PASSWORD, role: 'admin', organizationName: 'WAMM' });
      log('Compte admin créé :', admin.email);
    }
  }
  if (!admin) admin = await User.findOne({ role: 'admin' });

  const partners = {};
  for (const { key, ...p } of seed.partners) partners[key] = await upsert(Partner, { name: p.name }, p);

  const programmes = {};
  for (const { partnerKeys = [], ...p } of seed.programmes) {
    programmes[p.key] = await upsert(Programme, { key: p.key }, { ...p, partners: partnerKeys.map((k) => partners[k]._id) });
  }

  const centers = {};
  for (const { partnerKey, programmeKey, churches, ...c } of seed.centers) {
    const doc = { ...c };
    if (partnerKey) doc.partner = partners[partnerKey]._id;
    if (programmeKey) doc.programme = programmes[programmeKey]._id;
    if (churches !== undefined) {
      doc.results = [{ periodLabel: 'Avril-Mai 2026', from: new Date('2026-04-01'), to: new Date('2026-05-31'), churchesPlanted: churches }];
    }
    centers[c.name] = await upsert(Center, { name: c.name, countryCode: c.countryCode }, doc);
  }

  for (const { partnerKeys = [], programmeKey, ...f } of seed.focusPeoples) {
    const doc = { ...f };
    if (programmeKey) doc.programme = programmes[programmeKey]._id;
    const fp = await upsert(FocusPeople, { name: f.name, countryCode: f.countryCode }, doc);
    for (const k of partnerKeys) {
      await upsert(Adoption, { focusPeople: fp._id, partner: partners[k]._id }, {
        focusPeople: fp._id, partner: partners[k]._id, status: 'active', commitments: ['dmm'],
        notes: 'Peuple engagé par ce partenaire (projection WAMM 2024-2030).',
      });
    }
  }

  for (const { fromHub, ...a } of seed.axes) {
    const doc = { ...a };
    if (fromHub && centers[fromHub]) { doc.fromCenter = centers[fromHub]._id; doc.fromName = fromHub; }
    await upsert(SendingAxis, { label: a.label }, doc);
  }

  for (const t of seed.targets) {
    await upsert(Target, { indicator: t.indicator, scope: 'global', periodLabel: '2026-2030' }, { ...t, scope: 'global', periodLabel: '2026-2030' });
  }
  const fulani = programmes['FULANI-MERGON'];
  for (const t of fulani.annualTargets) {
    await upsert(Target, { indicator: t.indicator, scope: 'programme', programme: fulani._id, periodLabel: 'Annuel' }, {
      indicator: t.indicator, scope: 'programme', programme: fulani._id, periodLabel: 'Annuel', startYear: null, endYear: null, value: t.value,
    });
  }

  if (!admin) {
    log('⚠ Aucun administrateur : les activités du semestre ne sont pas importées (définir ADMIN_EMAIL et ADMIN_PASSWORD).');
  } else {
    for (const [from, to, title, type, mec, cc, place, partnerKeys = [], peoples = []] of seed.activities) {
      await upsert(Activity, { title, date: new Date(from) }, {
        type, mecPillar: mec, wammPillar: 'dmm', title,
        description: `${title}${place ? ` — ${place}` : ''} (bilan janvier-juin 2026).`,
        date: new Date(from), endDate: new Date(to), countryCode: cc, place,
        partners: partnerKeys.map((k) => partners[k]._id), peoples, user: admin._id,
      });
    }
  }

  log('Terminé.');
}

main()
  .catch((err) => { console.error('[seed-wamm] Échec :', err.message); process.exitCode = 1; })
  .finally(() => mongoose.connection.readyState && mongoose.disconnect());
