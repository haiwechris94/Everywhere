/**
 * Référentiel géographique WAMM — toute l'Afrique.
 *
 * - AFRICA_COUNTRIES : 55 pays/territoires (ISO alpha-2 / alpha-3, noms FR/EN,
 *   capitale, sous-région, centre [lat, lng], emprise [[S, O], [N, E]]).
 * - WAMM_REGIONS     : 5 sous-régions africaines + la ceinture sahélienne +
 *   les 4 fronts opérationnels de WAMM (projection globale 2024-2030).
 *   Un pays appartient à UNE sous-région et peut appartenir à plusieurs fronts.
 * - WAMM_COUNTRY_STATUS : niveau de présence WAMM par pays (valeur de départ,
 *   modifiable plus tard par l'administration).
 *
 * Fichier généré — garder backend/config/wammGeography.js et
 * frontend/src/config/wammGeography.js identiques.
 */
const AFRICA_COUNTRIES = [
  {
    "code": "ZA",
    "code3": "ZAF",
    "name": "Afrique du Sud",
    "nameEn": "South Africa",
    "capital": "Pretoria",
    "subregion": "AUSTRALE",
    "center": [
      -30.5595,
      22.9375
    ],
    "zoom": 5,
    "bounds": [
      [
        -34.786,
        16.448
      ],
      [
        -22.146,
        32.886
      ]
    ],
    "languages": [
      "Zulu",
      "Xhosa",
      "Afrikaans",
      "English",
      "Sepedi",
      "Tswana",
      "Sesotho",
      "Tsonga",
      "Swazi",
      "Venda",
      "Ndebele"
    ],
    "currency": "ZAR",
    "population": 58558270
  },
  {
    "code": "DZ",
    "code3": "DZA",
    "name": "Algérie",
    "nameEn": "Algeria",
    "capital": "Alger",
    "subregion": "NORD",
    "center": [
      28.0339,
      2.6325
    ],
    "zoom": 4,
    "bounds": [
      [
        18.988,
        -8.683
      ],
      [
        37.092,
        11.968
      ]
    ],
    "languages": [
      "Arabic",
      "Berber",
      "French"
    ],
    "currency": "DZD",
    "population": 43053054
  },
  {
    "code": "AO",
    "code3": "AGO",
    "name": "Angola",
    "nameEn": "Angola",
    "capital": "Luanda",
    "subregion": "CENTRE",
    "center": [
      -11.2027,
      17.8739
    ],
    "zoom": 5,
    "bounds": [
      [
        -18.006,
        11.743
      ],
      [
        -4.445,
        24.047
      ]
    ],
    "languages": [
      "Portuguese"
    ],
    "currency": "AOA",
    "population": 31825295
  },
  {
    "code": "BW",
    "code3": "BWA",
    "name": "Botswana",
    "nameEn": "Botswana",
    "capital": "Gaborone",
    "subregion": "AUSTRALE",
    "center": [
      -22.3285,
      24.6849
    ],
    "zoom": 5,
    "bounds": [
      [
        -26.854,
        19.977
      ],
      [
        -17.794,
        29.365
      ]
    ],
    "languages": [
      "English",
      "Setswana"
    ],
    "currency": "BWP",
    "population": 2303697
  },
  {
    "code": "BF",
    "code3": "BFA",
    "name": "Burkina Faso",
    "nameEn": "Burkina Faso",
    "capital": "Ouagadougou",
    "subregion": "OUEST",
    "center": [
      12.2383,
      -1.5616
    ],
    "zoom": 6,
    "bounds": [
      [
        9.426,
        -5.524
      ],
      [
        15.078,
        2.389
      ]
    ],
    "languages": [
      "French"
    ],
    "currency": "XOF",
    "population": 20321378
  },
  {
    "code": "BI",
    "code3": "BDI",
    "name": "Burundi",
    "nameEn": "Burundi",
    "capital": "Gitega",
    "subregion": "EST",
    "center": [
      -3.3731,
      29.9189
    ],
    "zoom": 7,
    "bounds": [
      [
        -4.456,
        29.014
      ],
      [
        -2.313,
        30.79
      ]
    ],
    "languages": [
      "Kirundi",
      "French",
      "English"
    ],
    "currency": "BIF",
    "population": 11530580
  },
  {
    "code": "BJ",
    "code3": "BEN",
    "name": "Bénin",
    "nameEn": "Benin",
    "capital": "Porto-Novo",
    "subregion": "OUEST",
    "center": [
      9.3077,
      2.3158
    ],
    "zoom": 6,
    "bounds": [
      [
        6.217,
        0.78
      ],
      [
        12.368,
        3.834
      ]
    ],
    "languages": [
      "French"
    ],
    "currency": "XOF",
    "population": 11801151
  },
  {
    "code": "CM",
    "code3": "CMR",
    "name": "Cameroun",
    "nameEn": "Cameroon",
    "capital": "Yaoundé",
    "subregion": "CENTRE",
    "center": [
      7.3697,
      12.3547
    ],
    "zoom": 5,
    "bounds": [
      [
        1.676,
        8.533
      ],
      [
        13.079,
        16.183
      ]
    ],
    "languages": [
      "French",
      "English"
    ],
    "currency": "XAF",
    "population": 25876380
  },
  {
    "code": "CV",
    "code3": "CPV",
    "name": "Cap-Vert",
    "nameEn": "Cape Verde",
    "capital": "Praia",
    "subregion": "OUEST",
    "center": [
      15.1201,
      -23.6052
    ],
    "zoom": 7,
    "bounds": [
      [
        14.916,
        -25.337
      ],
      [
        17.194,
        -22.71
      ]
    ],
    "languages": [
      "Portuguese",
      "Cape Verdean Creole"
    ],
    "currency": "CVE",
    "population": 549935
  },
  {
    "code": "KM",
    "code3": "COM",
    "name": "Comores",
    "nameEn": "Comoros",
    "capital": "Moroni",
    "subregion": "EST",
    "center": [
      -11.6455,
      43.8722
    ],
    "zoom": 8,
    "bounds": [
      [
        -11.901,
        43.227
      ],
      [
        -11.409,
        43.466
      ]
    ],
    "languages": [
      "Comorian",
      "Arabic",
      "French"
    ],
    "currency": "KMF",
    "population": 850886
  },
  {
    "code": "CI",
    "code3": "CIV",
    "name": "Côte d'Ivoire",
    "nameEn": "Ivory Coast",
    "capital": "Yamoussoukro",
    "subregion": "OUEST",
    "center": [
      7.54,
      -5.5471
    ],
    "zoom": 6,
    "bounds": [
      [
        4.351,
        -8.604
      ],
      [
        10.724,
        -2.506
      ]
    ],
    "languages": [
      "French"
    ],
    "currency": "XOF",
    "population": 25716544
  },
  {
    "code": "DJ",
    "code3": "DJI",
    "name": "Djibouti",
    "nameEn": "Djibouti",
    "capital": "Djibouti",
    "subregion": "EST",
    "center": [
      11.8251,
      42.5903
    ],
    "zoom": 8,
    "bounds": [
      [
        10.941,
        41.767
      ],
      [
        12.709,
        43.41
      ]
    ],
    "languages": [
      "French",
      "Arabic",
      "Somali",
      "Afar"
    ],
    "currency": "DJF",
    "population": 973560
  },
  {
    "code": "SZ",
    "code3": "SWZ",
    "name": "Eswatini",
    "nameEn": "Eswatini",
    "capital": "Mbabane",
    "subregion": "AUSTRALE",
    "center": [
      -26.5225,
      31.4659
    ],
    "zoom": 8,
    "bounds": [
      [
        -27.306,
        30.794
      ],
      [
        -25.747,
        32.113
      ]
    ],
    "languages": [
      "Swazi",
      "English"
    ],
    "currency": "SZL",
    "population": 1148130
  },
  {
    "code": "GA",
    "code3": "GAB",
    "name": "Gabon",
    "nameEn": "Gabon",
    "capital": "Libreville",
    "subregion": "CENTRE",
    "center": [
      -0.8037,
      11.6094
    ],
    "zoom": 6,
    "bounds": [
      [
        -3.916,
        8.821
      ],
      [
        2.3,
        14.481
      ]
    ],
    "languages": [
      "French"
    ],
    "currency": "XAF",
    "population": 2172579
  },
  {
    "code": "GM",
    "code3": "GMB",
    "name": "Gambie",
    "nameEn": "The Gambia",
    "capital": "Banjul",
    "subregion": "OUEST",
    "center": [
      13.4432,
      -15.3101
    ],
    "zoom": 7,
    "bounds": [
      [
        13.064,
        -16.825
      ],
      [
        13.812,
        -13.848
      ]
    ],
    "languages": [
      "English"
    ],
    "currency": "GMD",
    "population": 2347706
  },
  {
    "code": "GH",
    "code3": "GHA",
    "name": "Ghana",
    "nameEn": "Ghana",
    "capital": "Accra",
    "subregion": "OUEST",
    "center": [
      7.9465,
      -1.0232
    ],
    "zoom": 6,
    "bounds": [
      [
        4.762,
        -3.236
      ],
      [
        11.167,
        1.187
      ]
    ],
    "languages": [
      "English"
    ],
    "currency": "GHS",
    "population": 30417856
  },
  {
    "code": "GN",
    "code3": "GIN",
    "name": "Guinée",
    "nameEn": "Guinea",
    "capital": "Conakry",
    "subregion": "OUEST",
    "center": [
      9.9456,
      -9.6966
    ],
    "zoom": 6,
    "bounds": [
      [
        7.216,
        -15.043
      ],
      [
        12.674,
        -7.691
      ]
    ],
    "languages": [
      "French"
    ],
    "currency": "GNF",
    "population": 12771246
  },
  {
    "code": "GQ",
    "code3": "GNQ",
    "name": "Guinée équatoriale",
    "nameEn": "Equatorial Guinea",
    "capital": "Malabo",
    "subregion": "CENTRE",
    "center": [
      1.6508,
      10.2679
    ],
    "zoom": 7,
    "bounds": [
      [
        0.96,
        8.465
      ],
      [
        3.758,
        11.335
      ]
    ],
    "languages": [
      "Spanish",
      "French",
      "Portuguese"
    ],
    "currency": "XAF",
    "population": 1355986
  },
  {
    "code": "GW",
    "code3": "GNB",
    "name": "Guinée-Bissau",
    "nameEn": "Guinea-Bissau",
    "capital": "Bissau",
    "subregion": "OUEST",
    "center": [
      11.8037,
      -15.1804
    ],
    "zoom": 7,
    "bounds": [
      [
        10.94,
        -16.712
      ],
      [
        12.68,
        -13.674
      ]
    ],
    "languages": [
      "Portuguese",
      "Crioulo"
    ],
    "currency": "XOF",
    "population": 1920922
  },
  {
    "code": "KE",
    "code3": "KEN",
    "name": "Kenya",
    "nameEn": "Kenya",
    "capital": "Nairobi",
    "subregion": "EST",
    "center": [
      -0.0236,
      37.9062
    ],
    "zoom": 5,
    "bounds": [
      [
        -4.692,
        33.903
      ],
      [
        5.492,
        41.884
      ]
    ],
    "languages": [
      "English",
      "Swahili"
    ],
    "currency": "KES",
    "population": 52573973
  },
  {
    "code": "LS",
    "code3": "LSO",
    "name": "Lesotho",
    "nameEn": "Lesotho",
    "capital": "Maseru",
    "subregion": "AUSTRALE",
    "center": [
      -29.61,
      28.2336
    ],
    "zoom": 7,
    "bounds": [
      [
        -30.642,
        27.052
      ],
      [
        -28.582,
        29.391
      ]
    ],
    "languages": [
      "Sesotho",
      "English"
    ],
    "currency": "LSL",
    "population": 2125268
  },
  {
    "code": "LR",
    "code3": "LBR",
    "name": "Liberia",
    "nameEn": "Liberia",
    "capital": "Monrovia",
    "subregion": "OUEST",
    "center": [
      6.4281,
      -9.4295
    ],
    "zoom": 6,
    "bounds": [
      [
        4.351,
        -11.508
      ],
      [
        8.535,
        -7.4
      ]
    ],
    "languages": [
      "English"
    ],
    "currency": "LRD",
    "population": 4937374
  },
  {
    "code": "LY",
    "code3": "LBY",
    "name": "Libye",
    "nameEn": "Libya",
    "capital": "Tripoli",
    "subregion": "NORD",
    "center": [
      26.3351,
      17.2283
    ],
    "zoom": 5,
    "bounds": [
      [
        19.497,
        9.31
      ],
      [
        33.182,
        25.15
      ]
    ],
    "languages": [
      "Arabic"
    ],
    "currency": "LYD",
    "population": 6777452
  },
  {
    "code": "MG",
    "code3": "MDG",
    "name": "Madagascar",
    "nameEn": "Madagascar",
    "capital": "Antananarivo",
    "subregion": "EST",
    "center": [
      -18.7669,
      46.8691
    ],
    "zoom": 5,
    "bounds": [
      [
        -25.563,
        43.265
      ],
      [
        -12.08,
        50.483
      ]
    ],
    "languages": [
      "Malagasy",
      "French"
    ],
    "currency": "MGA",
    "population": 26969307
  },
  {
    "code": "MW",
    "code3": "MWI",
    "name": "Malawi",
    "nameEn": "Malawi",
    "capital": "Lilongwe",
    "subregion": "EST",
    "center": [
      -13.2543,
      34.3015
    ],
    "zoom": 6,
    "bounds": [
      [
        -17.127,
        32.672
      ],
      [
        -9.407,
        35.867
      ]
    ],
    "languages": [
      "English",
      "Chichewa"
    ],
    "currency": "MWK",
    "population": 18628747
  },
  {
    "code": "ML",
    "code3": "MLI",
    "name": "Mali",
    "nameEn": "Mali",
    "capital": "Bamako",
    "subregion": "OUEST",
    "center": [
      17.5707,
      -3.9962
    ],
    "zoom": 5,
    "bounds": [
      [
        10.163,
        -12.281
      ],
      [
        24.996,
        4.235
      ]
    ],
    "languages": [
      "French",
      "Bambara"
    ],
    "currency": "XOF",
    "population": 19658031
  },
  {
    "code": "MA",
    "code3": "MAR",
    "name": "Maroc",
    "nameEn": "Morocco",
    "capital": "Rabat",
    "subregion": "NORD",
    "center": [
      31.7917,
      -7.0926
    ],
    "zoom": 5,
    "bounds": [
      [
        21.421,
        -17.003
      ],
      [
        35.93,
        -1.066
      ]
    ],
    "languages": [
      "Arabic",
      "Berber",
      "French"
    ],
    "currency": "MAD",
    "population": 36471769
  },
  {
    "code": "MU",
    "code3": "MUS",
    "name": "Maurice",
    "nameEn": "Mauritius",
    "capital": "Port-Louis",
    "subregion": "EST",
    "center": [
      -20.3484,
      57.5522
    ],
    "zoom": 8,
    "bounds": [
      [
        -20.504,
        57.383
      ],
      [
        -19.99,
        57.792
      ]
    ],
    "languages": [
      "English",
      "French",
      "Mauritian Creole"
    ],
    "currency": "MUR",
    "population": 1265711
  },
  {
    "code": "MR",
    "code3": "MRT",
    "name": "Mauritanie",
    "nameEn": "Mauritania",
    "capital": "Nouakchott",
    "subregion": "OUEST",
    "center": [
      21.0079,
      -10.9408
    ],
    "zoom": 5,
    "bounds": [
      [
        14.745,
        -17.064
      ],
      [
        27.286,
        -4.823
      ]
    ],
    "languages": [
      "Arabic",
      "French"
    ],
    "currency": "MRU",
    "population": 4525696
  },
  {
    "code": "MZ",
    "code3": "MOZ",
    "name": "Mozambique",
    "nameEn": "Mozambique",
    "capital": "Maputo",
    "subregion": "EST",
    "center": [
      -18.6657,
      35.5296
    ],
    "zoom": 5,
    "bounds": [
      [
        -26.862,
        30.232
      ],
      [
        -10.464,
        40.835
      ]
    ],
    "languages": [
      "Portuguese"
    ],
    "currency": "MZN",
    "population": 30366036
  },
  {
    "code": "NA",
    "code3": "NAM",
    "name": "Namibie",
    "nameEn": "Namibia",
    "capital": "Windhoek",
    "subregion": "AUSTRALE",
    "center": [
      -22.9576,
      18.4904
    ],
    "zoom": 5,
    "bounds": [
      [
        -28.928,
        11.733
      ],
      [
        -16.968,
        25.259
      ]
    ],
    "languages": [
      "English",
      "Afrikaans",
      "German"
    ],
    "currency": "NAD",
    "population": 2494530
  },
  {
    "code": "NE",
    "code3": "NER",
    "name": "Niger",
    "nameEn": "Niger",
    "capital": "Niamey",
    "subregion": "OUEST",
    "center": [
      17.6078,
      8.0817
    ],
    "zoom": 5,
    "bounds": [
      [
        11.696,
        0.164
      ],
      [
        23.518,
        15.949
      ]
    ],
    "languages": [
      "French",
      "Hausa",
      "Zarma"
    ],
    "currency": "XOF",
    "population": 23310715
  },
  {
    "code": "NG",
    "code3": "NGA",
    "name": "Nigeria",
    "nameEn": "Nigeria",
    "capital": "Abuja",
    "subregion": "OUEST",
    "center": [
      9.082,
      8.6753
    ],
    "zoom": 5,
    "bounds": [
      [
        4.291,
        2.686
      ],
      [
        13.873,
        14.627
      ]
    ],
    "languages": [
      "English",
      "Hausa",
      "Yoruba",
      "Igbo"
    ],
    "currency": "NGN",
    "population": 200963599
  },
  {
    "code": "UG",
    "code3": "UGA",
    "name": "Ouganda",
    "nameEn": "Uganda",
    "capital": "Kampala",
    "subregion": "EST",
    "center": [
      1.3733,
      32.2903
    ],
    "zoom": 6,
    "bounds": [
      [
        -1.452,
        29.562
      ],
      [
        4.22,
        34.965
      ]
    ],
    "languages": [
      "English",
      "Swahili",
      "Luganda"
    ],
    "currency": "UGX",
    "population": 44269594
  },
  {
    "code": "RW",
    "code3": "RWA",
    "name": "Rwanda",
    "nameEn": "Rwanda",
    "capital": "Kigali",
    "subregion": "EST",
    "center": [
      -1.9403,
      29.8739
    ],
    "zoom": 7,
    "bounds": [
      [
        -2.809,
        28.876
      ],
      [
        -1.067,
        30.877
      ]
    ],
    "languages": [
      "Kinyarwanda",
      "French",
      "English",
      "Swahili"
    ],
    "currency": "RWF",
    "population": 12626950
  },
  {
    "code": "CF",
    "code3": "CAF",
    "name": "République centrafricaine",
    "nameEn": "Central African Republic",
    "capital": "Bangui",
    "subregion": "CENTRE",
    "center": [
      6.6111,
      20.9394
    ],
    "zoom": 5,
    "bounds": [
      [
        2.27,
        14.431
      ],
      [
        10.996,
        27.403
      ]
    ],
    "languages": [
      "French",
      "Sango"
    ],
    "currency": "XAF",
    "population": 4745185
  },
  {
    "code": "CG",
    "code3": "COG",
    "name": "République du Congo",
    "nameEn": "Republic of the Congo",
    "capital": "Brazzaville",
    "subregion": "CENTRE",
    "center": [
      -0.228,
      15.8277
    ],
    "zoom": 6,
    "bounds": [
      [
        -5.004,
        11.13
      ],
      [
        3.685,
        18.622
      ]
    ],
    "languages": [
      "French",
      "Lingala",
      "Kituba"
    ],
    "currency": "XAF",
    "population": 5380508
  },
  {
    "code": "CD",
    "code3": "COD",
    "name": "République démocratique du Congo",
    "nameEn": "Democratic Republic of the Congo",
    "capital": "Kinshasa",
    "subregion": "CENTRE",
    "center": [
      -4.0383,
      21.7587
    ],
    "zoom": 4,
    "bounds": [
      [
        -13.414,
        12.214
      ],
      [
        5.312,
        31.253
      ]
    ],
    "languages": [
      "French",
      "Lingala",
      "Swahili",
      "Kikongo",
      "Tshiluba"
    ],
    "currency": "CDF",
    "population": 86790567
  },
  {
    "code": "EH",
    "code3": "ESH",
    "name": "Sahara occidental",
    "nameEn": "Western Sahara",
    "capital": "",
    "subregion": "NORD",
    "center": [
      24.231,
      -12.8905
    ],
    "zoom": 6,
    "bounds": [
      [
        20.806,
        -17.099
      ],
      [
        27.656,
        -8.682
      ]
    ],
    "languages": [],
    "currency": "",
    "population": 603253
  },
  {
    "code": "ST",
    "code3": "STP",
    "name": "Sao Tomé-et-Principe",
    "nameEn": "São Tomé and Príncipe",
    "capital": "São Tomé",
    "subregion": "CENTRE",
    "center": [
      0.1864,
      6.6131
    ],
    "zoom": 8,
    "bounds": [
      [
        0.066,
        6.468
      ],
      [
        0.404,
        6.75
      ]
    ],
    "languages": [
      "Portuguese"
    ],
    "currency": "STN",
    "population": 215056
  },
  {
    "code": "SC",
    "code3": "SYC",
    "name": "Seychelles",
    "nameEn": "Seychelles",
    "capital": "Victoria",
    "subregion": "EST",
    "center": [
      -4.6796,
      55.492
    ],
    "zoom": 8,
    "bounds": [
      [
        -4.693,
        55.383
      ],
      [
        -4.559,
        55.54
      ]
    ],
    "languages": [
      "Seychellois Creole",
      "English",
      "French"
    ],
    "currency": "SCR",
    "population": 97625
  },
  {
    "code": "SL",
    "code3": "SLE",
    "name": "Sierra Leone",
    "nameEn": "Sierra Leone",
    "capital": "Freetown",
    "subregion": "OUEST",
    "center": [
      8.4606,
      -11.7799
    ],
    "zoom": 7,
    "bounds": [
      [
        6.907,
        -13.293
      ],
      [
        9.997,
        -10.283
      ]
    ],
    "languages": [
      "English",
      "Krio"
    ],
    "currency": "SLL",
    "population": 7813215
  },
  {
    "code": "SO",
    "code3": "SOM",
    "name": "Somalie",
    "nameEn": "Somalia",
    "capital": "Mogadiscio",
    "subregion": "EST",
    "center": [
      5.1521,
      46.1996
    ],
    "zoom": 5,
    "bounds": [
      [
        -1.695,
        40.964
      ],
      [
        11.984,
        51.255
      ]
    ],
    "languages": [
      "Somali",
      "Arabic"
    ],
    "currency": "SOS",
    "population": 10192317.3
  },
  {
    "code": "SD",
    "code3": "SDN",
    "name": "Soudan",
    "nameEn": "Sudan",
    "capital": "Khartoum",
    "subregion": "NORD",
    "center": [
      12.8628,
      30.2176
    ],
    "zoom": 5,
    "bounds": [
      [
        8.666,
        21.825
      ],
      [
        22.189,
        38.609
      ]
    ],
    "languages": [
      "Arabic",
      "English"
    ],
    "currency": "SDG",
    "population": 42813238
  },
  {
    "code": "SS",
    "code3": "SSD",
    "name": "Soudan du Sud",
    "nameEn": "South Sudan",
    "capital": "Djouba",
    "subregion": "EST",
    "center": [
      6.877,
      31.307
    ],
    "zoom": 5,
    "bounds": [
      [
        3.491,
        24.147
      ],
      [
        12.223,
        35.268
      ]
    ],
    "languages": [
      "English",
      "Arabic"
    ],
    "currency": "SSP",
    "population": 11062113
  },
  {
    "code": "SN",
    "code3": "SEN",
    "name": "Sénégal",
    "nameEn": "Senegal",
    "capital": "Dakar",
    "subregion": "OUEST",
    "center": [
      14.4974,
      -14.4524
    ],
    "zoom": 6,
    "bounds": [
      [
        12.328,
        -17.412
      ],
      [
        16.656,
        -11.389
      ]
    ],
    "languages": [
      "French",
      "Wolof"
    ],
    "currency": "XOF",
    "population": 16296364
  },
  {
    "code": "TZ",
    "code3": "TZA",
    "name": "Tanzanie",
    "nameEn": "Tanzania",
    "capital": "Dodoma",
    "subregion": "EST",
    "center": [
      -6.369,
      34.8888
    ],
    "zoom": 5,
    "bounds": [
      [
        -11.716,
        29.326
      ],
      [
        -1.002,
        40.464
      ]
    ],
    "languages": [
      "Swahili",
      "English"
    ],
    "currency": "TZS",
    "population": 58005463
  },
  {
    "code": "TD",
    "code3": "TCD",
    "name": "Tchad",
    "nameEn": "Chad",
    "capital": "N'Djaména",
    "subregion": "CENTRE",
    "center": [
      15.4542,
      18.7322
    ],
    "zoom": 5,
    "bounds": [
      [
        7.475,
        13.448
      ],
      [
        23.445,
        23.983
      ]
    ],
    "languages": [
      "French",
      "Arabic"
    ],
    "currency": "XAF",
    "population": 15946876
  },
  {
    "code": "TG",
    "code3": "TGO",
    "name": "Togo",
    "nameEn": "Togo",
    "capital": "Lomé",
    "subregion": "OUEST",
    "center": [
      8.6195,
      0.8248
    ],
    "zoom": 6,
    "bounds": [
      [
        6.089,
        -0.09
      ],
      [
        11.116,
        1.778
      ]
    ],
    "languages": [
      "French",
      "Ewe",
      "Kabye"
    ],
    "currency": "XOF",
    "population": 8082366
  },
  {
    "code": "TN",
    "code3": "TUN",
    "name": "Tunisie",
    "nameEn": "Tunisia",
    "capital": "Tunis",
    "subregion": "NORD",
    "center": [
      33.8869,
      9.5375
    ],
    "zoom": 6,
    "bounds": [
      [
        30.229,
        7.5
      ],
      [
        37.34,
        11.505
      ]
    ],
    "languages": [
      "Arabic",
      "French"
    ],
    "currency": "TND",
    "population": 11694719
  },
  {
    "code": "ZM",
    "code3": "ZMB",
    "name": "Zambie",
    "nameEn": "Zambia",
    "capital": "Lusaka",
    "subregion": "EST",
    "center": [
      -13.1339,
      27.8493
    ],
    "zoom": 5,
    "bounds": [
      [
        -18.042,
        21.979
      ],
      [
        -8.194,
        33.659
      ]
    ],
    "languages": [
      "English"
    ],
    "currency": "ZMW",
    "population": 17861030
  },
  {
    "code": "ZW",
    "code3": "ZWE",
    "name": "Zimbabwe",
    "nameEn": "Zimbabwe",
    "capital": "Harare",
    "subregion": "EST",
    "center": [
      -19.0154,
      29.1549
    ],
    "zoom": 6,
    "bounds": [
      [
        -22.402,
        25.224
      ],
      [
        -15.643,
        33.007
      ]
    ],
    "languages": [
      "English",
      "Shona",
      "Ndebele"
    ],
    "currency": "ZWL",
    "population": 14645468
  },
  {
    "code": "EG",
    "code3": "EGY",
    "name": "Égypte",
    "nameEn": "Egypt",
    "capital": "Le Caire",
    "subregion": "NORD",
    "center": [
      26.8206,
      29.82
    ],
    "zoom": 5,
    "bounds": [
      [
        21.995,
        24.712
      ],
      [
        31.655,
        36.871
      ]
    ],
    "languages": [
      "Arabic"
    ],
    "currency": "EGP",
    "population": 100388073
  },
  {
    "code": "ER",
    "code3": "ERI",
    "name": "Érythrée",
    "nameEn": "Eritrea",
    "capital": "Asmara",
    "subregion": "EST",
    "center": [
      15.1794,
      39.7823
    ],
    "zoom": 6,
    "bounds": [
      [
        12.377,
        36.427
      ],
      [
        18.005,
        43.117
      ]
    ],
    "languages": [
      "Tigrinya",
      "Arabic",
      "English"
    ],
    "currency": "ERN",
    "population": 6081196
  },
  {
    "code": "ET",
    "code3": "ETH",
    "name": "Éthiopie",
    "nameEn": "Ethiopia",
    "capital": "Addis-Abeba",
    "subregion": "EST",
    "center": [
      9.145,
      40.4897
    ],
    "zoom": 5,
    "bounds": [
      [
        3.456,
        33.013
      ],
      [
        14.852,
        47.978
      ]
    ],
    "languages": [
      "Amharic",
      "Oromo",
      "Tigrinya",
      "Somali"
    ],
    "currency": "ETB",
    "population": 112078730
  }
];

const WAMM_REGIONS = [
  {
    "id": "OUEST",
    "kind": "subregion",
    "name": "Afrique de l'Ouest",
    "nameEn": "West Africa",
    "color": "#C8792B",
    "countries": [
      "BF",
      "BJ",
      "CV",
      "CI",
      "GM",
      "GH",
      "GN",
      "GW",
      "LR",
      "ML",
      "MR",
      "NE",
      "NG",
      "SL",
      "SN",
      "TG"
    ],
    "description": ""
  },
  {
    "id": "CENTRE",
    "kind": "subregion",
    "name": "Afrique centrale",
    "nameEn": "Central Africa",
    "color": "#2F7D5B",
    "countries": [
      "AO",
      "CM",
      "GA",
      "GQ",
      "CF",
      "CG",
      "CD",
      "ST",
      "TD"
    ],
    "description": ""
  },
  {
    "id": "EST",
    "kind": "subregion",
    "name": "Afrique de l'Est",
    "nameEn": "East Africa",
    "color": "#3F6FA8",
    "countries": [
      "BI",
      "KM",
      "DJ",
      "KE",
      "MG",
      "MW",
      "MU",
      "MZ",
      "UG",
      "RW",
      "SC",
      "SO",
      "SS",
      "TZ",
      "ZM",
      "ZW",
      "ER",
      "ET"
    ],
    "description": ""
  },
  {
    "id": "AUSTRALE",
    "kind": "subregion",
    "name": "Afrique australe",
    "nameEn": "Southern Africa",
    "color": "#8A5A9E",
    "countries": [
      "ZA",
      "BW",
      "SZ",
      "LS",
      "NA"
    ],
    "description": ""
  },
  {
    "id": "NORD",
    "kind": "subregion",
    "name": "Afrique du Nord",
    "nameEn": "North Africa",
    "color": "#B5544A",
    "countries": [
      "DZ",
      "LY",
      "MA",
      "EH",
      "SD",
      "TN",
      "EG"
    ],
    "description": ""
  },
  {
    "id": "CEINTURE",
    "kind": "belt",
    "name": "Ceinture sahélienne de sécurité",
    "nameEn": "Sahel Security Belt",
    "color": "#D9A441",
    "description": "Pays cités dans la projection globale WAMM 2024-2030 : nord de la Guinée et de la Côte d'Ivoire, nord du Ghana-Togo-Bénin, pôle Tchad-Cameroun, axes vers Saint-Louis (Sénégal) et le Burkina Faso.",
    "countries": [
      "GN",
      "CI",
      "GH",
      "TG",
      "BJ",
      "BF",
      "TD",
      "CM",
      "SN"
    ]
  },
  {
    "id": "FRONT-CI",
    "kind": "front",
    "name": "Front Côte d'Ivoire",
    "nameEn": "Côte d'Ivoire front",
    "color": "#E07A1F",
    "description": "Le pôle historique : seul pays où WAMM a déjà des centres d'équipement en fonctionnement, avec cinq partenaires engagés.",
    "countries": [
      "CI"
    ]
  },
  {
    "id": "FRONT-GN",
    "kind": "front",
    "name": "Front Guinée Conakry",
    "nameEn": "Guinea Conakry front",
    "color": "#1D7A8C",
    "description": "Section la plus à l'ouest de la ceinture : 42 peuples, dont 28 non atteints, et un panier de dix peuples prioritaires à adopter.",
    "countries": [
      "GN"
    ]
  },
  {
    "id": "FRONT-GTB",
    "kind": "front",
    "name": "Corridor Ghana-Togo-Bénin",
    "nameEn": "Ghana-Togo-Benin corridor",
    "color": "#6B4FA0",
    "description": "Réseau triangulaire et déploiement en chaîne, fondé sur les liens ethniques transfrontaliers (Gouchegoun, Kara, Parakou).",
    "countries": [
      "GH",
      "TG",
      "BJ",
      "BF"
    ]
  },
  {
    "id": "FRONT-PEUL",
    "kind": "front",
    "name": "Front peul Togo-Bénin-Tchad",
    "nameEn": "Togo-Benin-Chad Fulani front",
    "color": "#A0522D",
    "description": "Programme peul avec Mergon : cinq centres dédiés aux Peuls/Fulfulde (projet en cours de validation).",
    "countries": [
      "TG",
      "BJ",
      "TD"
    ]
  },
  {
    "id": "FRONT-OI",
    "kind": "front",
    "name": "Îles de l'océan Indien",
    "nameEn": "Indian Ocean islands",
    "color": "#0E7490",
    "description": "Destination annoncée par WAMM : « le Sahel et les îles de l'océan Indien », avec une expansion prévue sur 15 pays incluant Madagascar.",
    "countries": [
      "MG",
      "KM",
      "MU",
      "SC"
    ]
  }
];

const WAMM_COUNTRY_STATUS = {
  "CI": "active",
  "GN": "launch",
  "TG": "launch",
  "GH": "launch",
  "BJ": "outlook",
  "TD": "outlook",
  "BF": "axis",
  "SN": "axis",
  "CM": "axis",
  "MG": "outlook"
};

const WAMM_STATUS_LABELS = {
  "active": {
    "fr": "Actif (centres en fonctionnement)",
    "en": "Active (centres running)",
    "color": "#1F7A4D"
  },
  "launch": {
    "fr": "Lancement / adoption des peuples",
    "en": "Launch / people adoption",
    "color": "#D98E04"
  },
  "outlook": {
    "fr": "Perspective (programme peul, Madagascar)",
    "en": "Outlook (Fulani programme, Madagascar)",
    "color": "#B5544A"
  },
  "axis": {
    "fr": "Axe d'envoi / pays voisin",
    "en": "Sending axis / neighbour",
    "color": "#7C8DA6"
  },
  "none": {
    "fr": "Pas encore de présence WAMM",
    "en": "No WAMM presence yet",
    "color": "#E5E1D8"
  }
};

const COUNTRY_BY_CODE = Object.fromEntries(AFRICA_COUNTRIES.map((c) => [c.code, c]));
const COUNTRY_BY_CODE3 = Object.fromEntries(AFRICA_COUNTRIES.map((c) => [c.code3, c]));
const REGION_BY_ID = Object.fromEntries(WAMM_REGIONS.map((r) => [r.id, r]));

/** Pays (alpha-2) d'une région/front, ou [] si inconnu. */
function regionCountryCodes(id) {
  const r = REGION_BY_ID[String(id || '').toUpperCase()];
  return r ? r.countries.slice() : [];
}

/** Résout un code alpha-2 OU alpha-3 vers la fiche pays. */
function getCountry(code) {
  const k = String(code || '').toUpperCase();
  return COUNTRY_BY_CODE[k] || COUNTRY_BY_CODE3[k] || null;
}

/** Régions (sous-région + fronts) auxquelles appartient un pays. */
function regionsOfCountry(code) {
  const c = getCountry(code);
  if (!c) return [];
  return WAMM_REGIONS.filter((r) => r.countries.includes(c.code));
}

function wammStatusOf(code) {
  const c = getCountry(code);
  return (c && WAMM_COUNTRY_STATUS[c.code]) || 'none';
}

module.exports = {
  AFRICA_COUNTRIES,
  WAMM_REGIONS,
  WAMM_COUNTRY_STATUS,
  WAMM_STATUS_LABELS,
  COUNTRY_BY_CODE,
  COUNTRY_BY_CODE3,
  REGION_BY_ID,
  regionCountryCodes,
  getCountry,
  regionsOfCountry,
  wammStatusOf,
};
