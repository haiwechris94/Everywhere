/**
 * Countries API Routes
 * 
 * Provides endpoints for country data:
 * - GET /api/countries - List all available countries
 * - GET /api/countries/:code - Get specific country details
 * - GET /api/countries/:code/stats - Get country statistics
 * 
 * @author Church Planting Map Team
 * @version 1.0.0
 */

const express = require('express');
const router = express.Router();
const { optionalAuth } = require('../middleware/auth');

// Country configuration — toute l'Afrique (source : config/wammGeography.js).
// `region` = libellé anglais de la sous-région WAMM, `subregion` = id WAMM.
const { AFRICA_COUNTRIES, REGION_BY_ID } = require('../config/wammGeography');
const COUNTRY_CONFIG = Object.fromEntries(
  AFRICA_COUNTRIES.map((c) => [
    c.code,
    { ...c, region: REGION_BY_ID[c.subregion] ? REGION_BY_ID[c.subregion].nameEn : '' },
  ])
);

// Helper function to convert country code to database name
const countryCodeToDbName = (code) => {
  const config = COUNTRY_CONFIG[code?.toUpperCase()];
  return config?.name || null;
};

/**
 * GET /api/countries
 * List all available countries
 */
router.get('/', optionalAuth, async (req, res) => {
  try {
    const { region } = req.query;
    
    let countries = Object.values(COUNTRY_CONFIG);
    
    // Filter by region if specified
    if (region) {
      countries = countries.filter(c => 
        c.region.toLowerCase() === region.toLowerCase()
      );
    }
    
    // Sort by name
    countries.sort((a, b) => a.name.localeCompare(b.name));
    
    res.json({
      success: true,
      count: countries.length,
      countries: countries.map(c => ({
        code: c.code,
        code3: c.code3,
        name: c.name,
        nameEn: c.nameEn,
        capital: c.capital,
        region: c.region,
        center: c.center,
        zoom: c.zoom,
        bounds: c.bounds,
      })),
    });
  } catch (error) {
    console.error('Error fetching countries:', error);
    res.status(500).json({
      success: false,
      error: 'Server error',
      message: error.message,
    });
  }
});

/**
 * GET /api/countries/:code
 * Get specific country details
 */
router.get('/:code', optionalAuth, async (req, res) => {
  try {
    const { code } = req.params;
    const upperCode = code.toUpperCase();
    
    // Try direct match
    let country = COUNTRY_CONFIG[upperCode];
    
    // Try alpha-3 match
    if (!country) {
      country = Object.values(COUNTRY_CONFIG).find(c => c.code3 === upperCode);
    }
    
    if (!country) {
      return res.status(404).json({
        success: false,
        error: 'Country not found',
        message: `No country found with code: ${code}`,
      });
    }
    
    res.json({
      success: true,
      country,
    });
  } catch (error) {
    console.error('Error fetching country:', error);
    res.status(500).json({
      success: false,
      error: 'Server error',
      message: error.message,
    });
  }
});

/**
 * GET /api/countries/:code/bounds
 * Get country bounding box for map fitting
 */
router.get('/:code/bounds', optionalAuth, async (req, res) => {
  try {
    const { code } = req.params;
    const upperCode = code.toUpperCase();
    
    const country = COUNTRY_CONFIG[upperCode];
    
    if (!country) {
      return res.status(404).json({
        success: false,
        error: 'Country not found',
      });
    }
    
    res.json({
      success: true,
      code: country.code,
      bounds: country.bounds,
      center: country.center,
      zoom: country.zoom,
    });
  } catch (error) {
    console.error('Error fetching country bounds:', error);
    res.status(500).json({
      success: false,
      error: 'Server error',
      message: error.message,
    });
  }
});

// Export helper function for use in other routes
module.exports = router;
module.exports.countryCodeToDbName = countryCodeToDbName;
module.exports.COUNTRY_CONFIG = COUNTRY_CONFIG;
