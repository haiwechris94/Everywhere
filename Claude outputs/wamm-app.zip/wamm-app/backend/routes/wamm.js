/**
 * Routes WAMM — fonctionnement interne de WAMM.
 * Monté sur /api/wamm.
 *
 * Ressources (CRUD) :
 *   /partners        partenaires (églises, missions, organisations)
 *   /centers         centres : IFM, CEIMP, alphabétisation, santé, agriculture, radio, pivots
 *   /focus-peoples   peuples prioritaires (panier d'adoption, lots, ouvriers nécessaires)
 *   /adoptions       adoptions d'un peuple par un partenaire
 *   /programmes      programmes WAMM (Peuls-Mergon, adoption, compassion, prière)
 *   /targets         objectifs chiffrés (2026-2030, cibles annuelles)
 *   /axes            axes d'envoi / corridors
 *
 * Résultats DMM d'un centre ou d'un programme :
 *   POST   /centers/:id/results            PUT/DELETE /centers/:id/results/:resultId
 *   POST   /programmes/:id/results         PUT/DELETE /programmes/:id/results/:resultId
 *
 * Vues agrégées :
 *   GET /meta                 listes de valeurs (types, statuts, indicateurs)
 *   GET /overview             tableau de bord : indicateurs, objectifs vs réalisé, pays
 *   GET /map                  données de la carte WAMM
 *   GET /reports/mec          bilan M.E.C. d'une période (?from=&to=)
 *
 * Lecture : utilisateur connecté. Écriture : superviseur ou admin.
 * Suppression : admin.
 */
const express = require('express');
const mongoose = require('mongoose');
const router = express.Router();

const { auth } = require('../middleware/auth');
const { isAdmin, isSupervisorOrAdmin } = require('../middleware/roles');
const { Partner, Center, FocusPeople, Adoption, Programme, Target, SendingAxis } = require('../models/wamm');
const { RESULT_FIELDS, sumResults } = require('../models/wamm/_shared');
const Activity = require('../models/Activity');
const {
  AFRICA_COUNTRIES,
  WAMM_REGIONS,
  WAMM_COUNTRY_STATUS,
  WAMM_STATUS_LABELS,
  getCountry,
} = require('../config/wammGeography');

const isId = (v) => mongoose.Types.ObjectId.isValid(String(v || ''));
const bad = (res, message, status = 400) => res.status(status).json({ error: 'Requête invalide', message });
const fail = (res, err) => {
  if (err && err.name === 'ValidationError') return bad(res, err.message);
  if (err && err.code === 11000) return bad(res, 'Un élément identique existe déjà.', 409);
  console.error('[wamm]', err);
  return res.status(500).json({ error: 'Erreur serveur', message: err.message });
};

// Champs jamais modifiables par le client.
const PROTECTED = ['_id', 'createdBy', 'createdAt', 'updatedAt', '__v', 'results'];
const clean = (body = {}) => {
  const out = { ...body };
  PROTECTED.forEach((k) => delete out[k]);
  ['countryCode'].forEach((k) => { if (typeof out[k] === 'string') out[k] = out[k].toUpperCase(); });
  ['countryCodes', 'otherCountryCodes'].forEach((k) => {
    if (Array.isArray(out[k])) out[k] = out[k].map((c) => String(c).toUpperCase());
  });
  // Coordonnées : accepter { lat, lng } en plus du GeoJSON
  ['location', 'from', 'to'].forEach((k) => {
    const v = out[k];
    if (v && v.lat !== undefined && v.lng !== undefined) {
      const lat = Number(v.lat); const lng = Number(v.lng);
      out[k] = Number.isFinite(lat) && Number.isFinite(lng) ? { type: 'Point', coordinates: [lng, lat] } : undefined;
    }
    if (v === null || v === '') out[k] = undefined;
  });
  return out;
};

/**
 * Fabrique de routes CRUD.
 * @param {string} path      segment d'URL
 * @param {Model}  Model     modèle Mongoose
 * @param {object} opts      { populate, filters(query) -> mongoFilter, sort }
 */
function crud(path, Model, opts = {}) {
  const populate = opts.populate || [];
  const applyPopulate = (q) => populate.reduce((acc, p) => acc.populate(p), q);

  router.get(`/${path}`, auth, async (req, res) => {
    try {
      const filter = opts.filters ? opts.filters(req.query) : {};
      if (req.query.q) filter.name = { $regex: String(req.query.q).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i' };
      const docs = await applyPopulate(Model.find(filter).sort(opts.sort || { name: 1 })).lean();
      docs.forEach((d) => { if (Array.isArray(d.results)) d.totals = sumResults(d.results); });
      res.json({ data: docs, count: docs.length });
    } catch (err) { fail(res, err); }
  });

  router.get(`/${path}/:id`, auth, async (req, res) => {
    try {
      if (!isId(req.params.id)) return bad(res, 'Identifiant invalide');
      const doc = await applyPopulate(Model.findById(req.params.id));
      if (!doc) return bad(res, 'Introuvable', 404);
      const json = doc.toJSON();
      if (opts.detail) Object.assign(json, await opts.detail(doc));
      res.json({ data: json });
    } catch (err) { fail(res, err); }
  });

  router.post(`/${path}`, auth, isSupervisorOrAdmin, async (req, res) => {
    try {
      const doc = await Model.create({ ...clean(req.body), createdBy: req.user._id });
      res.status(201).json({ data: doc });
    } catch (err) { fail(res, err); }
  });

  router.put(`/${path}/:id`, auth, isSupervisorOrAdmin, async (req, res) => {
    try {
      if (!isId(req.params.id)) return bad(res, 'Identifiant invalide');
      const doc = await Model.findById(req.params.id);
      if (!doc) return bad(res, 'Introuvable', 404);
      doc.set(clean(req.body));
      await doc.save();
      res.json({ data: doc });
    } catch (err) { fail(res, err); }
  });

  router.delete(`/${path}/:id`, auth, isAdmin, async (req, res) => {
    try {
      if (!isId(req.params.id)) return bad(res, 'Identifiant invalide');
      const doc = await Model.findByIdAndDelete(req.params.id);
      if (!doc) return bad(res, 'Introuvable', 404);
      if (opts.onDelete) await opts.onDelete(doc);
      res.json({ message: 'Supprimé', id: req.params.id });
    } catch (err) { fail(res, err); }
  });
}

/** Routes de saisie des résultats DMM (sous-documents `results`). */
function resultsRoutes(path, Model) {
  router.post(`/${path}/:id/results`, auth, isSupervisorOrAdmin, async (req, res) => {
    try {
      if (!isId(req.params.id)) return bad(res, 'Identifiant invalide');
      const doc = await Model.findById(req.params.id);
      if (!doc) return bad(res, 'Introuvable', 404);
      doc.results.push(req.body);
      await doc.save();
      res.status(201).json({ data: doc });
    } catch (err) { fail(res, err); }
  });
  router.put(`/${path}/:id/results/:resultId`, auth, isSupervisorOrAdmin, async (req, res) => {
    try {
      const doc = isId(req.params.id) ? await Model.findById(req.params.id) : null;
      const r = doc && doc.results.id(req.params.resultId);
      if (!r) return bad(res, 'Introuvable', 404);
      r.set(req.body);
      await doc.save();
      res.json({ data: doc });
    } catch (err) { fail(res, err); }
  });
  router.delete(`/${path}/:id/results/:resultId`, auth, isSupervisorOrAdmin, async (req, res) => {
    try {
      const doc = isId(req.params.id) ? await Model.findById(req.params.id) : null;
      const r = doc && doc.results.id(req.params.resultId);
      if (!r) return bad(res, 'Introuvable', 404);
      r.deleteOne();
      await doc.save();
      res.json({ data: doc });
    } catch (err) { fail(res, err); }
  });
}

const byCountry = (field = 'countryCode') => (q) => {
  const f = {};
  if (q.countryCode) f[field] = String(q.countryCode).toUpperCase();
  return f;
};

// ── Ressources ──────────────────────────────────────────────────────────────
crud('partners', Partner, {
  filters: (q) => {
    const f = {};
    if (q.countryCode) f.countryCodes = String(q.countryCode).toUpperCase();
    if (q.type) f.type = q.type;
    if (q.status) f.status = q.status;
    return f;
  },
  detail: async (doc) => {
    const [centers, adoptions, activities] = await Promise.all([
      Center.find({ partner: doc._id }).sort({ name: 1 }).lean(),
      Adoption.find({ partner: doc._id }).populate('focusPeople', 'name countryCode population reachStatus').lean(),
      Activity.find({ partners: doc._id }).sort({ date: -1 }).limit(30).lean(),
    ]);
    return { centers, adoptions, activities };
  },
  onDelete: async (doc) => {
    await Promise.all([
      Center.updateMany({ partner: doc._id }, { $unset: { partner: 1 } }),
      Adoption.updateMany({ partner: doc._id }, { $unset: { partner: 1 }, $set: { adopterName: doc.name } }),
    ]);
  },
});

crud('centers', Center, {
  populate: [{ path: 'partner', select: 'name acronym' }, { path: 'programme', select: 'key name' }],
  filters: (q) => {
    const f = byCountry()(q);
    if (q.type) f.type = q.type;
    if (q.status) f.status = q.status;
    if (q.partner && isId(q.partner)) f.partner = q.partner;
    if (q.programme && isId(q.programme)) f.programme = q.programme;
    return f;
  },
  detail: async (doc) => ({
    activities: await Activity.find({ center: doc._id }).sort({ date: -1 }).limit(30).lean(),
  }),
});
resultsRoutes('centers', Center);

crud('focus-peoples', FocusPeople, {
  populate: [{ path: 'programme', select: 'key name' }],
  filters: (q) => {
    const f = {};
    if (q.countryCode) {
      const c = String(q.countryCode).toUpperCase();
      f.$or = [{ countryCode: c }, { otherCountryCodes: c }];
    }
    if (q.lot) f.lot = q.lot;
    if (q.stage) f.stage = q.stage;
    return f;
  },
  sort: { countryCode: 1, population: -1 },
  detail: async (doc) => ({
    adoptions: await Adoption.find({ focusPeople: doc._id }).populate('partner', 'name acronym').sort({ date: 1 }).lean(),
    centers: await Center.find({ focusPeoples: doc._id }).select('name type countryCode city').lean(),
  }),
  onDelete: async (doc) => { await Adoption.deleteMany({ focusPeople: doc._id }); },
});

crud('adoptions', Adoption, {
  populate: [
    { path: 'focusPeople', select: 'name countryCode population reachStatus lot' },
    { path: 'partner', select: 'name acronym' },
  ],
  filters: (q) => {
    const f = {};
    if (q.focusPeople && isId(q.focusPeople)) f.focusPeople = q.focusPeople;
    if (q.partner && isId(q.partner)) f.partner = q.partner;
    return f;
  },
  sort: { date: -1, createdAt: -1 },
});

crud('programmes', Programme, {
  populate: [{ path: 'partners', select: 'name acronym' }],
  sort: { startYear: 1, name: 1 },
  detail: async (doc) => {
    const [centers, focusPeoples, activities] = await Promise.all([
      Center.find({ programme: doc._id }).lean(),
      FocusPeople.find({ programme: doc._id }).lean(),
      Activity.find({ programme: doc._id }).sort({ date: -1 }).limit(30).lean(),
    ]);
    return { centers, focusPeoples, activities };
  },
});
resultsRoutes('programmes', Programme);

crud('targets', Target, {
  populate: [{ path: 'programme', select: 'key name' }],
  filters: (q) => {
    const f = {};
    if (q.scope) f.scope = q.scope;
    if (q.periodLabel) f.periodLabel = q.periodLabel;
    return f;
  },
  sort: { scope: 1, indicator: 1 },
});

crud('axes', SendingAxis, {
  populate: [{ path: 'fromCenter', select: 'name type countryCode' }],
  sort: { regionId: 1, label: 1 },
});

// ── Meta ────────────────────────────────────────────────────────────────────
router.get('/meta', auth, (req, res) => {
  res.json({
    data: {
      partnerTypes: Partner.TYPES,
      partnershipLevels: Partner.LEVELS,
      centerTypes: Center.TYPES,
      centerStatuses: Center.STATUSES,
      reachStatuses: FocusPeople.REACH_STATUSES,
      peopleStages: FocusPeople.STAGES,
      commitments: Adoption.COMMITMENTS,
      pillars: Programme.PILLARS,
      indicators: Target.INDICATORS,
      resultFields: RESULT_FIELDS,
      regions: WAMM_REGIONS,
      countryStatus: WAMM_COUNTRY_STATUS,
      statusLabels: WAMM_STATUS_LABELS,
    },
  });
});

// ── Calcul des « réalisés » ─────────────────────────────────────────────────
async function computeActuals({ countryCode = null, programmeId = null } = {}) {
  const cf = countryCode ? { countryCode } : {};
  const pf = programmeId ? { programme: programmeId } : {};
  const [centers, focusPeoples, partnersCount, programmes] = await Promise.all([
    Center.find({ ...cf, ...pf, status: { $in: ['existing', 'new'] } }).lean(),
    FocusPeople.find({ ...(countryCode ? { $or: [{ countryCode }, { otherCountryCodes: countryCode }] } : {}), ...pf }).lean(),
    Partner.countDocuments({ status: 'active', ...(countryCode ? { countryCodes: countryCode } : {}) }),
    programmeId ? Programme.find({ _id: programmeId }).lean() : (countryCode ? [] : Programme.find({}).lean()),
  ]);
  const centerTotals = sumResults(centers.flatMap((c) => c.results || []));
  const progTotals = sumResults(programmes.flatMap((p) => p.results || []));
  const totals = Object.fromEntries(RESULT_FIELDS.map((k) => [k, (centerTotals[k] || 0) + (progTotals[k] || 0)]));
  const engagedStages = ['workers_sent', 'engaged', 'movement'];
  const countriesActive = new Set(centers.map((c) => c.countryCode));
  focusPeoples.filter((p) => engagedStages.includes(p.stage)).forEach((p) => countriesActive.add(p.countryCode));
  return {
    ifm: centers.filter((c) => c.type === 'ifm').length,
    ceimp: centers.filter((c) => c.type === 'ceimp').length,
    peoplesEngaged: focusPeoples.filter((p) => engagedStages.includes(p.stage)).length,
    countries: countriesActive.size,
    partners: partnersCount,
    workers: focusPeoples.reduce((s, p) => s + (p.workersInPlace || 0), 0),
    ...totals,
  };
}

// ── Tableau de bord ─────────────────────────────────────────────────────────
router.get('/overview', auth, async (req, res) => {
  try {
    const [actuals, targets, centers, focusPeoples, adoptions, partners, programmes, recentActivities] = await Promise.all([
      computeActuals(),
      Target.find({}).populate('programme', 'key name').lean(),
      Center.find({}).populate('partner', 'name acronym').lean(),
      FocusPeople.find({}).lean(),
      Adoption.find({}).lean(),
      Partner.find({}).select('name acronym status countryCodes type').lean(),
      Programme.find({}).select('key name status pillar countryCodes annualTargets').lean(),
      Activity.find({ archived: { $ne: true } }).sort({ date: -1 }).limit(8).populate('partners', 'name acronym').lean(),
    ]);

    // Objectifs : réalisé calculé (ou forcé manuellement)
    const actualCache = {};
    const targetRows = [];
    for (const t of targets) {
      let actual;
      if (t.manualActual !== null && t.manualActual !== undefined) actual = t.manualActual;
      else if (t.scope === 'global') actual = actuals[t.indicator] ?? 0;
      else {
        const key = `${t.scope}:${t.countryCode}:${t.programme && t.programme._id}`;
        if (!actualCache[key]) {
          actualCache[key] = await computeActuals({
            countryCode: t.scope === 'country' ? t.countryCode : null,
            programmeId: t.scope === 'programme' && t.programme ? t.programme._id : null,
          });
        }
        actual = actualCache[key][t.indicator] ?? 0;
      }
      targetRows.push({
        ...t,
        label: (Target.INDICATORS[t.indicator] || {}).fr || t.indicator,
        labelEn: (Target.INDICATORS[t.indicator] || {}).en || t.indicator,
        actual,
        progress: t.value > 0 ? Math.min(100, Math.round((actual / t.value) * 100)) : 0,
        manual: t.manualActual !== null && t.manualActual !== undefined,
      });
    }

    // Synthèse par pays
    const countries = {};
    const touch = (code) => {
      const c = getCountry(code);
      if (!c) return null;
      if (!countries[c.code]) {
        countries[c.code] = {
          code: c.code, code3: c.code3, name: c.name, nameEn: c.nameEn,
          status: WAMM_COUNTRY_STATUS[c.code] || 'none',
          centers: 0, focusPeoples: 0, adoptions: 0, partners: 0, churchesPlanted: 0, baptisms: 0, personsOfPeace: 0,
        };
      }
      return countries[c.code];
    };
    Object.keys(WAMM_COUNTRY_STATUS).forEach(touch);
    centers.forEach((c) => {
      const row = touch(c.countryCode); if (!row) return;
      row.centers += 1;
      const t = sumResults(c.results);
      row.churchesPlanted += t.churchesPlanted; row.baptisms += t.baptisms; row.personsOfPeace += t.personsOfPeace;
    });
    const recordsByPeople = {};
    adoptions.forEach((a) => { const k = String(a.focusPeople); recordsByPeople[k] = (recordsByPeople[k] || 0) + 1; });
    focusPeoples.forEach((p) => {
      const row = touch(p.countryCode); if (!row) return;
      row.focusPeoples += 1;
      row.adoptions += Math.max(recordsByPeople[String(p._id)] || 0, p.declaredAdopters || 0);
    });
    partners.forEach((p) => (p.countryCodes || []).forEach((cc) => { const row = touch(cc); if (row) row.partners += 1; }));

    // Résultats par centre (graphique « églises implantées par centre »)
    const centerResults = centers
      .map((c) => ({ _id: c._id, name: c.name, city: c.city, countryCode: c.countryCode, partner: c.partner, type: c.type, ...sumResults(c.results) }))
      .filter((c) => c.churchesPlanted || c.personsOfPeace || c.baptisms || c.discoveryGroups)
      .sort((a, b) => b.churchesPlanted - a.churchesPlanted);

    res.json({
      data: {
        actuals,
        targets: targetRows,
        counts: {
          partners: partners.length,
          activePartners: partners.filter((p) => p.status === 'active').length,
          centers: centers.length,
          centersByType: centers.reduce((acc, c) => { acc[c.type] = (acc[c.type] || 0) + 1; return acc; }, {}),
          focusPeoples: focusPeoples.length,
          adoptions: focusPeoples.reduce((s, p) => s + Math.max(adoptions.filter((a) => String(a.focusPeople) === String(p._id)).length, p.declaredAdopters || 0), 0),
          unadoptedPeoples: focusPeoples.filter((p) => !(p.declaredAdopters > 0) && !adoptions.some((a) => String(a.focusPeople) === String(p._id))).length,
          programmes: programmes.length,
          workersNeeded: focusPeoples.reduce((s, p) => s + (p.workersNeeded || 0), 0),
          workersInPlace: focusPeoples.reduce((s, p) => s + (p.workersInPlace || 0), 0),
        },
        countries: Object.values(countries).sort((a, b) => a.name.localeCompare(b.name, 'fr')),
        centerResults,
        programmes,
        recentActivities,
      },
    });
  } catch (err) { fail(res, err); }
});

// ── Carte ───────────────────────────────────────────────────────────────────
router.get('/map', auth, async (req, res) => {
  try {
    const [centers, focusPeoples, adoptions, axes, partners] = await Promise.all([
      Center.find({}).populate('partner', 'name acronym').populate('programme', 'key name').lean(),
      FocusPeople.find({}).populate('programme', 'key name').lean(),
      Adoption.find({}).populate('partner', 'name acronym').lean(),
      SendingAxis.find({}).populate('fromCenter', 'name').lean(),
      Partner.find({ status: { $ne: 'ended' } }).select('name acronym countryCodes type levels').lean(),
    ]);
    const adoptersByPeople = {};
    adoptions.forEach((a) => {
      const k = String(a.focusPeople);
      (adoptersByPeople[k] = adoptersByPeople[k] || []).push(a.partner ? (a.partner.acronym || a.partner.name) : a.adopterName);
    });
    res.json({
      data: {
        centers: centers.map((c) => ({ ...c, totals: sumResults(c.results), results: undefined })),
        focusPeoples: focusPeoples.map((p) => ({
          ...p,
          adoptionCount: Math.max((adoptersByPeople[String(p._id)] || []).length, p.declaredAdopters || 0),
          adopters: adoptersByPeople[String(p._id)] || [],
        })),
        axes,
        partners,
        countryStatus: WAMM_COUNTRY_STATUS,
        statusLabels: WAMM_STATUS_LABELS,
        regions: WAMM_REGIONS,
      },
    });
  } catch (err) { fail(res, err); }
});

// ── Bilan M.E.C. ────────────────────────────────────────────────────────────
router.get('/reports/mec', auth, async (req, res) => {
  try {
    const now = new Date();
    const from = req.query.from ? new Date(req.query.from) : new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() < 6 ? 0 : 6, 1));
    const to = req.query.to ? new Date(req.query.to) : new Date(Date.UTC(from.getUTCFullYear(), from.getUTCMonth() + 6, 0, 23, 59, 59));
    if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime())) return bad(res, 'Dates invalides');

    const filter = { archived: { $ne: true }, date: { $lte: to }, $or: [{ endDate: { $gte: from } }, { endDate: null, date: { $gte: from } }, { endDate: { $exists: false }, date: { $gte: from } }] };
    if (req.query.countryCode) filter.countryCode = String(req.query.countryCode).toUpperCase();
    const activities = await Activity.find(filter).sort({ date: 1 }).populate('partners', 'name acronym').lean();

    const partnerMap = {};
    activities.forEach((a) => {
      (a.partners || []).forEach((p) => {
        const k = String(p._id);
        partnerMap[k] = partnerMap[k] || { _id: p._id, name: p.name, acronym: p.acronym, activities: [] };
        partnerMap[k].activities.push(a.title || a.description);
      });
      (a.partnerNames || []).forEach((n) => {
        const k = `name:${n}`;
        partnerMap[k] = partnerMap[k] || { name: n, activities: [] };
        partnerMap[k].activities.push(a.title || a.description);
      });
    });
    const peoples = new Set(); const countries = new Set();
    activities.forEach((a) => { (a.peoples || []).forEach((p) => peoples.add(p)); if (a.countryCode) countries.add(a.countryCode); });
    const trainingTypes = ['training', 'leader-training', 'coaching-igrow', 'course', 'forum', 'internship'];
    const fieldTypes = ['field-assessment', 'scouting-trip', 'visit'];

    res.json({
      data: {
        from, to,
        summary: {
          activities: activities.length,
          partnersSupported: Object.keys(partnerMap).length,
          trainingSessions: activities.filter((a) => trainingTypes.includes(a.type)).reduce((s, a) => s + Math.max(1, a.sessionsCount || 0), 0),
          peoplesReached: peoples.size,
          fieldsAssessed: activities.filter((a) => fieldTypes.includes(a.type)).length,
          countries: countries.size,
          participants: activities.reduce((s, a) => s + (a.participants || 0), 0),
        },
        byPillar: ['mobilisation', 'equipement', 'coaching', ''].map((k) => ({ pillar: k || 'unclassified', count: activities.filter((a) => (a.mecPillar || '') === k).length })),
        countries: [...countries].map((c) => { const x = getCountry(c); return { code: c, name: x ? x.name : c }; }),
        peoples: [...peoples].sort((a, b) => a.localeCompare(b, 'fr')),
        partners: Object.values(partnerMap).sort((a, b) => b.activities.length - a.activities.length),
        timeline: activities.map((a) => ({
          _id: a._id, date: a.date, endDate: a.endDate, title: a.title || a.description, type: a.type,
          mecPillar: a.mecPillar, place: a.place, countryCode: a.countryCode, peoples: a.peoples,
          partners: [...(a.partners || []).map((p) => p.acronym || p.name), ...(a.partnerNames || [])],
        })),
      },
    });
  } catch (err) { fail(res, err); }
});

// Utilisé par le seed et les tests
router.computeActuals = computeActuals;
module.exports = router;
module.exports.AFRICA_COUNT = AFRICA_COUNTRIES.length;
