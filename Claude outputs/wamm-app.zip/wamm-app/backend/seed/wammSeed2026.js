/**
 * Données de démarrage WAMM — source : « Sahel Security Belt — WAMM Global
 * Projection 2024-2030 » (présentation, version EN).
 *
 * Règles suivies :
 *  - seules les informations présentes dans la présentation sont saisies ;
 *  - les coordonnées sont celles de la ville citée ; quand elles ne désignent
 *    qu'une zone (aire d'un peuple, axe d'envoi), `locationApprox: true` ;
 *  - positions lues sur les cartes WAMM incluses dans la présentation (carte
 *    murale du réseau en Côte d'Ivoire, carte de la Guinée, carte du corridor
 *    Ghana-Togo-Bénin) : `locationApprox: true` ;
 *  - un lieu qu'on ne peut pas situer avec certitude (Miani, Amanikro, Boko,
 *    Liabo, Kounongou, Bambara…) est créé SANS coordonnées :
 *    la carte le liste « à géolocaliser ».
 *  - les résultats d'avril-mai ne sont ventilés par centre que pour les
 *    églises ; les autres indicateurs (151 personnes de paix, 89 groupes,
 *    67 baptêmes, 89 nouveaux croyants) sont saisis au niveau du programme
 *    « Centres d'équipement Côte d'Ivoire ».
 */
const pt = (lat, lng) => ({ type: 'Point', coordinates: [lng, lat] });

const APRIL_MAY = { periodLabel: 'Avril-Mai 2026', from: new Date('2026-04-01'), to: new Date('2026-05-31') };

module.exports = {
  partners: [
    { key: 'VINEYARD-CI', name: "Vineyard Côte d'Ivoire", acronym: 'Vineyard CI', type: 'church', levels: ['field'], countryCodes: ['CI'],
      supportTypes: ['Formation des leaders', 'Préparation des centres', 'Évaluations de terrain'],
      description: 'Peuples : Koro, Worodougou, Nyabwa, Koulango (Bondoukou).' },
    { key: 'EWM', name: 'Emmanuel World Mission', acronym: 'MME', type: 'mission', levels: ['field'], countryCodes: ['CI'],
      supportTypes: ['Deuxième cohorte de missionnaires à Briehoa'], description: 'Peuple : Néyo.' },
    { key: 'MIDJ', name: 'MIDJ', acronym: 'MIDJ', type: 'mission', levels: ['field'], countryCodes: ['CI'],
      description: 'Peuples : Koulango (Bouna), Lohoron. Deux centres (Banvayo/Doropo et Bondoukou) totalisent 41 des 68 églises et 60 des 67 baptêmes d’avril-mai 2026.' },
    { key: 'ELIM', name: 'Elim', acronym: 'Elim', type: 'church', levels: ['field'], countryCodes: ['CI'], description: 'Peuple : Sénoufo Tagwana.' },
    { key: 'WOG', name: 'Word of God Church', acronym: 'Word of God', type: 'church', levels: ['field'], countryCodes: ['CI'],
      supportTypes: ['Formation et coaching des leaders à Man'], description: 'Appelée aussi « Word of God Mission ». Peuples : Kla, Toura.' },
    { key: 'VINEYARD-GN', name: 'Vineyard Guinée', acronym: 'Vineyard GN', type: 'church', levels: ['field'], countryCodes: ['GN'],
      supportTypes: ["Formation et transfert d'expérience"] },
    { key: 'WESLEYAN', name: 'Église Wesleyenne', acronym: 'Wesleyan', type: 'church', levels: ['field'], countryCodes: ['CI'],
      supportTypes: ['Partage de vision à Sassandra'] },
    { key: 'CFA', name: 'Mission Évangélique Christ pour Tous', acronym: 'Christ for All', type: 'mission', levels: ['field'], countryCodes: ['CI'],
      supportTypes: ['Film Jésus chez les Néyo'] },
    { key: 'MERGON', name: 'Mergon', acronym: 'Mergon', type: 'foundation', levels: ['strategic', 'financial'], countryCodes: ['TG', 'BJ', 'TD'],
      status: 'prospect', description: 'Programme peul Togo-Bénin-Tchad (projet en cours de validation).' },
  ],

  programmes: [
    { key: 'CI-CENTRES', name: "Centres d'équipement Côte d'Ivoire", pillar: 'dmm', status: 'active', regionId: 'FRONT-CI', countryCodes: ['CI'],
      startYear: 2024, endYear: 2030, partnerKeys: ['VINEYARD-CI', 'EWM', 'MIDJ', 'ELIM', 'WOG'],
      description: "Le pôle historique : depuis Abidjan, 5 instituts, 10 centres d'équipement et deux axes de rayonnement vers Saint-Louis (Sénégal) et Kara (Togo). Année 1 : formation et mise en place, lancement des instituts de Doropo, Boundiali et Fakobli.",
      results: [{ ...APRIL_MAY, personsOfPeace: 151, discoveryGroups: 89, baptisms: 67, newBelievers: 89,
        notes: 'Totaux des centres d’équipement non ventilés par centre dans la présentation (les églises sont saisies par centre).' }] },
    { key: 'GN-ADOPTION', name: 'Guinée : dix peuples à adopter', pillar: 'dmm', status: 'active', regionId: 'FRONT-GN', countryCodes: ['GN'],
      startYear: 2026, endYear: 2030, partnerKeys: ['VINEYARD-GN'],
      description: '42 peuples recensés (99 % de la population), dont 28 non atteints ; aucun n’est classé « atteint ». Panier de dix peuples prioritaires en 4 lots : plus de 5 millions de personnes et au moins 98 ouvriers pionniers nécessaires.' },
    { key: 'GTB-CORRIDOR', name: 'Corridor Ghana-Togo-Bénin', pillar: 'dmm', status: 'active', regionId: 'FRONT-GTB', countryCodes: ['GH', 'TG', 'BJ', 'BF'],
      startYear: 2026, endYear: 2030,
      description: "Trois centres pivots (Gouchegoun, Kara, Parakou) forment des implanteurs d'églises et les envoient vers les peuples voisins. Conférence de vision de Lomé (18 juillet 2026) : 27 églises et organisations ont adopté un peuple." },
    { key: 'FULANI-MERGON', name: 'Programme peul Togo-Bénin-Tchad', pillar: 'dmm', status: 'validation', regionId: 'FRONT-PEUL', countryCodes: ['TG', 'BJ', 'TD'],
      startYear: 2027, partnerKeys: ['MERGON'], targetPeoples: ['Peuls (Fulfulde)'],
      description: 'Un peuple pastoral peu atteint dont les routes traversent le nord des pays de la ceinture. Cinq centres dédiés : Kara et Parakou (existants), Kounongou, Djougou et Dourbali (nouveaux). Projet en cours de validation avec Mergon.',
      annualTargets: [
        { indicator: 'leadersTrained', value: 50 }, { indicator: 'discoveryGroups', value: 250 },
        { indicator: 'personsOfPeace', value: 1250 }, { indicator: 'churchesPlanted', value: 25 },
        { indicator: 'baptisms', value: 125 }, { indicator: 'secondGenLeaders', value: 50 },
      ] },
    { key: 'COMPASSION', name: 'Ministère de compassion', pillar: 'compassion', status: 'active', regionId: 'CEINTURE',
      description: "Répondre aux besoins vitaux (eau, santé, éducation) pour combler le vide social par l'amour en action." },
    { key: 'PRIERE', name: 'Mouvement de prière', pillar: 'prayer', status: 'active', regionId: 'CEINTURE',
      description: 'Mobiliser les églises pour intercéder pour les peuples non atteints : le fondement spirituel des deux autres piliers.' },
  ],

  centers: [
    // ── Côte d'Ivoire : bureau et centres d'équipement (résultats avril-mai 2026, églises) ──
    { name: 'Bureau WAMM Abidjan', type: 'office', status: 'existing', countryCode: 'CI', city: 'Abidjan', location: pt(5.336, -4.027), programmeKey: 'CI-CENTRES' },
    { name: 'Banvayo/Doropo', type: 'ceimp', status: 'existing', countryCode: 'CI', city: 'Doropo', zone: 'Zone 1 : Nord-Est', partnerKey: 'MIDJ', programmeKey: 'CI-CENTRES', location: pt(9.81, -3.345), locationApprox: true, peoplesServed: ['Lohoron'], churches: 25 },
    { name: 'Bondoukou (MIDJ)', type: 'ceimp', status: 'existing', countryCode: 'CI', city: 'Bondoukou', zone: 'Zone 1 : Nord-Est', partnerKey: 'MIDJ', programmeKey: 'CI-CENTRES', location: pt(8.04, -2.80), churches: 16 },
    { name: 'Miani', type: 'ceimp', status: 'existing', countryCode: 'CI', programmeKey: 'CI-CENTRES', churches: 5 },
    { name: 'Tiéningboué', type: 'ifm', status: 'existing', countryCode: 'CI', city: 'Tiéningboué', partnerKey: 'VINEYARD-CI', programmeKey: 'CI-CENTRES', location: pt(8.11, -5.71), locationApprox: true, churches: 4,
      description: 'Institut (carte murale du réseau WAMM) : envoie vers les Worodougou, Koro, Nyabwa et Koulango.' },
    { name: 'Amanikro', type: 'ceimp', status: 'existing', countryCode: 'CI', programmeKey: 'CI-CENTRES', churches: 4 },
    { name: 'Biankouman', type: 'ceimp', status: 'existing', countryCode: 'CI', city: 'Biankouma', programmeKey: 'CI-CENTRES', location: pt(7.739, -7.614), churches: 4 },
    { name: 'Abidjan (Dje Koffi)', type: 'ceimp', status: 'existing', countryCode: 'CI', city: 'Abidjan', programmeKey: 'CI-CENTRES', location: pt(5.36, -3.99), locationApprox: true, churches: 3 },
    { name: 'Abidjan (Akré)', type: 'ceimp', status: 'existing', countryCode: 'CI', city: 'Abidjan', programmeKey: 'CI-CENTRES', location: pt(5.31, -4.06), locationApprox: true, churches: 2 },
    { name: 'Goueïdié', type: 'ceimp', status: 'existing', countryCode: 'CI', partnerKey: 'WOG', programmeKey: 'CI-CENTRES', location: pt(7.86, -7.62), locationApprox: true, peoplesServed: ['Toura'], churches: 2 },
    { name: 'Santa', type: 'ceimp', status: 'existing', countryCode: 'CI', zone: 'Zone 3 : Ouest', partnerKey: 'WOG', programmeKey: 'CI-CENTRES', location: pt(7.95, -8.05), locationApprox: true, peoplesServed: ['Kla'], churches: 2 },
    { name: 'Bondoukou (Vineyard)', type: 'ceimp', status: 'existing', countryCode: 'CI', city: 'Bondoukou', zone: 'Zone 1 : Nord-Est', partnerKey: 'VINEYARD-CI', programmeKey: 'CI-CENTRES', location: pt(8.03, -2.79), locationApprox: true, churches: 1 },
    { name: 'Boko', type: 'ceimp', status: 'existing', countryCode: 'CI', programmeKey: 'CI-CENTRES', churches: 0 },
    { name: 'Liabo', type: 'ceimp', status: 'existing', countryCode: 'CI', programmeKey: 'CI-CENTRES', churches: 0 },
    // ── Côte d'Ivoire : autres instituts et centres de la carte murale du réseau ──
    { name: 'Institut de Man', type: 'ifm', status: 'existing', countryCode: 'CI', city: 'Man', partnerKey: 'WOG', programmeKey: 'CI-CENTRES', location: pt(7.412, -7.554) },
    { name: 'Institut de Briehoa', type: 'ifm', status: 'existing', countryCode: 'CI', city: 'Briehoa', partnerKey: 'EWM', programmeKey: 'CI-CENTRES', location: pt(6.32, -6.23), locationApprox: true },
    { name: "Institut d'Anyama", type: 'ifm', status: 'existing', countryCode: 'CI', city: 'Anyama', programmeKey: 'CI-CENTRES', location: pt(5.495, -4.052) },
    { name: 'Institut Elim', type: 'ifm', status: 'existing', countryCode: 'CI', city: 'Région de Ferkessédougou', partnerKey: 'ELIM', programmeKey: 'CI-CENTRES', location: pt(8.84, -4.56), locationApprox: true },
    { name: 'Centre Worodougou', type: 'ceimp', status: 'existing', countryCode: 'CI', partnerKey: 'VINEYARD-CI', programmeKey: 'CI-CENTRES', location: pt(8.84, -6.94), locationApprox: true, peoplesServed: ['Worodougou'] },
    { name: 'Centre Koro', type: 'ceimp', status: 'existing', countryCode: 'CI', partnerKey: 'VINEYARD-CI', programmeKey: 'CI-CENTRES', location: pt(8.62, -5.83), locationApprox: true, peoplesServed: ['Koro'] },
    { name: 'Centre Sénoufo Tagwana', type: 'ceimp', status: 'existing', countryCode: 'CI', city: 'Niakaramandougou', partnerKey: 'ELIM', programmeKey: 'CI-CENTRES', location: pt(8.66, -5.29), locationApprox: true, peoplesServed: ['Sénoufo Tagwana'] },
    { name: 'Centre de Bouna', type: 'ceimp', status: 'existing', countryCode: 'CI', city: 'Bouna', zone: 'Zone 1 : Nord-Est', partnerKey: 'MIDJ', programmeKey: 'CI-CENTRES', location: pt(9.27, -3.00), peoplesServed: ['Koulango (Bouna)'] },
    { name: 'Centre Nyabwa', type: 'ceimp', status: 'existing', countryCode: 'CI', partnerKey: 'VINEYARD-CI', programmeKey: 'CI-CENTRES', location: pt(6.81, -7.09), locationApprox: true, peoplesServed: ['Nyabwa'] },
    { name: 'Centre de Sassandra', type: 'ceimp', status: 'existing', countryCode: 'CI', city: 'Sassandra', partnerKey: 'EWM', programmeKey: 'CI-CENTRES', location: pt(4.952, -6.085), peoplesServed: ['Néyo'] },
    { name: 'Centre Krahn (Guiglo)', type: 'ceimp', status: 'planned', countryCode: 'CI', city: 'Guiglo', programmeKey: 'CI-CENTRES', location: pt(6.54, -7.49), peoplesServed: ['Krahn'], description: 'Centre en prospection (carte murale).' },
    // ── Côte d'Ivoire : instituts lancés en année 1 et projets par zone ──
    { name: 'Institut de Doropo', type: 'ifm', status: 'new', countryCode: 'CI', city: 'Doropo', zone: 'Zone 1 : Nord-Est', programmeKey: 'CI-CENTRES', location: pt(9.81, -3.345), openingYear: 2026,
      description: 'Zone 1 (Bondoukou, Doropo) : 2 centres actifs, 2 instituts, un centre d’alphabétisation fonctionnel.' },
    { name: 'Institut de Boundiali', type: 'ifm', status: 'new', countryCode: 'CI', city: 'Boundiali', zone: 'Zone 2 : Nord', programmeKey: 'CI-CENTRES', location: pt(9.52, -6.487), openingYear: 2026,
      description: 'Zone 2 (Boundiali, Ferkessédougou, Tengréla, Odienné) : institut et radio, 3 centres, centre de santé en année 2.' },
    { name: 'Radio de Boundiali', type: 'radio', status: 'planned', countryCode: 'CI', city: 'Boundiali', zone: 'Zone 2 : Nord', programmeKey: 'CI-CENTRES', location: pt(9.525, -6.48), locationApprox: true },
    { name: 'Institut de Fakobli', type: 'ifm', status: 'new', countryCode: 'CI', city: 'Fakobli (Man)', zone: 'Zone 3 : Ouest', programmeKey: 'CI-CENTRES', location: pt(7.39, -7.37), locationApprox: true, openingYear: 2026,
      description: 'Zone 3 (Fakobli, Santa, Toulepleu) : 2 instituts, un centre, 2 centres d’alphabétisation, un centre agricole.' },
    // ── Guinée : instituts et centres prévus ──
    ...[['Labé', 11.318, -12.283], ['Kamsar', 10.653, -14.611], ['Kankan', 10.385, -9.306], ["N'Zérékoré", 7.756, -8.818]].map(([n, la, lo]) => (
      { name: `Institut de ${n}`, type: 'ifm', status: 'planned', countryCode: 'GN', city: n, location: pt(la, lo), programmeKey: 'GN-ADOPTION' })),
    ...[['Koundara', 12.483, -13.296], ['Siguiri', 11.422, -9.168], ['Macenta', 8.543, -9.472], ['Lola', 7.802, -8.531]].map(([n, la, lo]) => (
      { name: `Centre de ${n}`, type: 'ceimp', status: 'planned', countryCode: 'GN', city: n, location: pt(la, lo), programmeKey: 'GN-ADOPTION' })),
    // ── Corridor Ghana-Togo-Bénin : centres pivots ──
    { name: 'Centre pivot de Gouchegoun', type: 'hub', status: 'existing', countryCode: 'GH', city: 'Gouchegoun', programmeKey: 'GTB-CORRIDOR', location: pt(9.78, 0.14), locationApprox: true, peoplesServed: ['Konkomba'],
      description: 'Les Konkomba vers les Mamprusi et les Nanumba ; les Anufo du Ghana vers ceux du Togo.' },
    { name: 'Centre pivot de Kara', type: 'hub', status: 'existing', countryCode: 'TG', city: 'Kara', programmeKey: 'GTB-CORRIDOR', location: pt(9.551, 1.186),
      description: 'Quatre axes : Anufo du Bénin, Mamprusi, Biali du Bénin et du Burkina Faso. Centre existant du programme peul.' },
    { name: 'Centre pivot de Parakou', type: 'hub', status: 'existing', countryCode: 'BJ', city: 'Parakou', programmeKey: 'GTB-CORRIDOR', location: pt(9.337, 2.630),
      description: 'Les étudiants convertis deviennent des implanteurs mobiles pour le Nord rural. Centre existant du programme peul.' },
    // ── Corridor : centres d'équipement en prospection (carte WAMM du corridor) ──
    { name: 'Centre Mamprusi (Togo)', type: 'ceimp', status: 'planned', countryCode: 'TG', programmeKey: 'GTB-CORRIDOR', location: pt(10.67, 0.14), locationApprox: true, peoplesServed: ['Mamprusi'] },
    { name: 'Centre Chokosi Anufo (Ghana)', type: 'ceimp', status: 'planned', countryCode: 'GH', programmeKey: 'GTB-CORRIDOR', location: pt(10.16, 0.22), locationApprox: true, peoplesServed: ['Anufo (Chokosi)'] },
    { name: 'Centre Chokosi Anufo (Bénin)', type: 'ceimp', status: 'planned', countryCode: 'BJ', programmeKey: 'GTB-CORRIDOR', location: pt(10.30, 1.01), locationApprox: true, peoplesServed: ['Anufo (Chokosi)'] },
    { name: 'Centre Biali (Bénin)', type: 'ceimp', status: 'planned', countryCode: 'BJ', programmeKey: 'GTB-CORRIDOR', location: pt(10.74, 1.13), locationApprox: true, peoplesServed: ['Biali'] },
    { name: 'Centre Biali (Burkina Faso)', type: 'ceimp', status: 'planned', countryCode: 'BF', programmeKey: 'GTB-CORRIDOR', location: pt(11.43, 1.09), locationApprox: true, peoplesServed: ['Biali'] },
    // ── Programme peul : nouveaux centres ──
    { name: 'Centre peul de Kounongou', type: 'ceimp', status: 'planned', countryCode: 'TG', city: 'Kounongou', programmeKey: 'FULANI-MERGON', peoplesServed: ['Peuls (Fulfulde)'] },
    { name: 'Centre peul de Djougou', type: 'ceimp', status: 'planned', countryCode: 'BJ', city: 'Djougou', programmeKey: 'FULANI-MERGON', location: pt(9.708, 1.666), peoplesServed: ['Peuls (Fulfulde)'] },
    { name: 'Centre peul de Dourbali', type: 'ceimp', status: 'planned', countryCode: 'TD', city: 'Dourbali', programmeKey: 'FULANI-MERGON', location: pt(11.81, 15.86), locationApprox: true, peoplesServed: ['Peuls (Fulfulde)'] },
  ],

  focusPeoples: [
    // ── Côte d'Ivoire : peuples engagés par les partenaires ──
    { name: 'Koro', countryCode: 'CI', stage: 'engaged', partnerKeys: ['VINEYARD-CI'], location: pt(8.65, -5.90) },
    { name: 'Worodougou', countryCode: 'CI', stage: 'engaged', partnerKeys: ['VINEYARD-CI'], location: pt(7.96, -6.67) },
    { name: 'Nyabwa', countryCode: 'CI', stage: 'engaged', partnerKeys: ['VINEYARD-CI'], area: 'Daloa', location: pt(6.88, -6.45) },
    { name: 'Koulango (Bondoukou)', countryCode: 'CI', stage: 'engaged', partnerKeys: ['VINEYARD-CI'], area: 'Bondoukou', location: pt(8.10, -2.90) },
    { name: 'Néyo', countryCode: 'CI', stage: 'engaged', partnerKeys: ['EWM', 'CFA'], area: 'Sassandra', location: pt(4.98, -6.15) },
    { name: 'Koulango (Bouna)', countryCode: 'CI', stage: 'engaged', partnerKeys: ['MIDJ'], area: 'Bouna', location: pt(9.27, -3.00) },
    { name: 'Lohoron', countryCode: 'CI', stage: 'engaged', partnerKeys: ['MIDJ'], area: 'Doropo', location: pt(9.75, -3.25) },
    { name: 'Sénoufo Tagwana', countryCode: 'CI', stage: 'engaged', partnerKeys: ['ELIM'], area: 'Niakaramandougou', location: pt(8.70, -5.20) },
    { name: 'Kla', countryCode: 'CI', stage: 'engaged', partnerKeys: ['WOG'], area: 'Santa', location: pt(7.98, -8.10) },
    { name: 'Toura', countryCode: 'CI', stage: 'engaged', partnerKeys: ['WOG'], area: 'Man', location: pt(7.70, -7.70) },
    // ── Guinée : les dix peuples à adopter ──
    { name: 'Maninka oriental', alternateNames: ['Eastern Maninka'], countryCode: 'GN', lot: '3', population: 3704000, reachStatus: 'frontier', workersNeeded: 74, area: 'Kankan', location: pt(10.37, -9.27) },
    { name: 'Konyanka', countryCode: 'GN', lot: '1', population: 715000, reachStatus: 'frontier', workersNeeded: 14, location: pt(8.78, -8.46) },
    { name: 'Kono', countryCode: 'GN', lot: '1', population: 198000, reachStatus: 'minimally_reached', location: pt(7.77, -8.30), notes: 'Ouvriers nécessaires : non précisé.' },
    { name: 'Kuranko', countryCode: 'GN', lot: '2', population: 132000, reachStatus: 'unreached', workersNeeded: 3, location: pt(9.35, -9.93) },
    { name: 'Maan (Mano)', alternateNames: ['Mano'], countryCode: 'GN', lot: '1', population: 125000, reachStatus: 'unreached', workersNeeded: 2, area: "N'Zérékoré", location: pt(7.36, -8.80) },
    { name: 'Manya', countryCode: 'GN', lot: '1', population: 97000, reachStatus: 'frontier', workersNeeded: 2, area: 'Macenta', location: pt(8.55, -9.45) },
    { name: 'Lele', countryCode: 'GN', lot: '2', population: 61000, reachStatus: 'unreached', workersNeeded: 1, location: pt(8.92, -10.40) },
    { name: 'Mandeni (Mmani)', alternateNames: ['Mmani'], countryCode: 'GN', lot: '7', population: 51000, reachStatus: 'unreached', workersNeeded: 1, location: pt(9.03, -13.28) },
    { name: 'Bandi', countryCode: 'GN', lot: '2', population: 15000, reachStatus: 'minimally_reached', location: pt(8.45, -10.11), notes: 'Ouvriers nécessaires : non précisé.' },
    { name: 'Bambara', countryCode: 'GN', lot: '3', population: 5500, reachStatus: 'unreached', workersNeeded: 1 },
    // ── Togo : peuples adoptés à la conférence de Lomé (18 juillet 2026) ──
    { name: 'Anufo (Chokosi)', alternateNames: ['Chokosi'], countryCode: 'TG', otherCountryCodes: ['GH', 'BJ'], population: 105000, religion: 'Islam 60 %', area: 'Oti, Mango',
      location: pt(10.39, 0.49), stage: 'adopted', declaredAdopters: 19, adoptionEvent: 'Conférence de vision de Lomé, 18 juillet 2026' },
    { name: 'Akasselem (Tchamba)', countryCode: 'TG', population: 82500, reachStatus: 'unreached', religion: 'Islam > 90 %', area: 'Tchamba',
      location: pt(8.82, 1.39), stage: 'adopted', declaredAdopters: 15, adoptionEvent: 'Conférence de vision de Lomé, 18 juillet 2026', notes: 'Population : 80 000 à 85 000.' },
    { name: 'Gourmantché', countryCode: 'TG', population: 351000, reachStatus: 'partially_reached', area: 'Kpendjal',
      location: pt(10.76, 0.59), stage: 'adopted', declaredAdopters: 10, adoptionEvent: 'Conférence de vision de Lomé, 18 juillet 2026' },
    { name: 'Peuls (Fulfulde)', alternateNames: ['Fulani'], countryCode: 'TG', otherCountryCodes: ['BJ', 'TD'], area: 'Nord du Togo, autour de Kounongou', isPastoral: true,
      reachStatus: 'unreached', programmeKey: 'FULANI-MERGON', location: pt(10.15, 0.55), notes: 'Peuple pastoral, cible du projet Mergon.' },
  ],

  axes: [
    { label: 'Abidjan → Saint-Louis', kind: 'outreach', fromName: 'Abidjan', from: pt(5.336, -4.027), toName: 'Saint-Louis (Sénégal)', to: pt(16.03, -16.49), countryCodes: ['CI', 'SN'], regionId: 'FRONT-CI', locationApprox: false },
    { label: 'Abidjan → Kara', kind: 'outreach', fromName: 'Abidjan', from: pt(5.336, -4.027), toName: 'Kara (Togo)', to: pt(9.551, 1.186), countryCodes: ['CI', 'TG'], regionId: 'FRONT-CI', locationApprox: false },
    { label: 'Konkomba → Mamprusi (Ghana)', fromHub: 'Centre pivot de Gouchegoun', from: pt(9.78, 0.14), toName: 'Mamprusi (Ghana)', to: pt(10.37, -0.71), targetPeoples: ['Mamprusi'], countryCodes: ['GH'], regionId: 'FRONT-GTB' },
    { label: 'Konkomba → Nanumba', fromHub: 'Centre pivot de Gouchegoun', from: pt(9.78, 0.14), toName: 'Nanumba', to: pt(9.63, -0.40), targetPeoples: ['Nanumba'], countryCodes: ['GH'], regionId: 'FRONT-GTB' },
    { label: 'Gouchegoun → Anufo du Ghana', fromHub: 'Centre pivot de Gouchegoun', from: pt(9.78, 0.14), toName: 'Chokosi Anufo (Ghana)', to: pt(10.16, 0.22), targetPeoples: ['Anufo (Chokosi)'], countryCodes: ['GH'], regionId: 'FRONT-GTB' },
    { label: 'Anufo du Ghana → Anufo du Togo', from: pt(10.16, 0.22), fromName: 'Chokosi Anufo (Ghana)', toName: 'Chokosi Anufo (Togo)', to: pt(10.39, 0.49), targetPeoples: ['Anufo (Chokosi)'], countryCodes: ['GH', 'TG'], regionId: 'FRONT-GTB' },
    { label: 'Anufo du Bénin → Anufo du Togo', from: pt(10.30, 1.01), fromName: 'Chokosi Anufo (Bénin)', toName: 'Chokosi Anufo (Togo)', to: pt(10.39, 0.49), targetPeoples: ['Anufo (Chokosi)'], countryCodes: ['BJ', 'TG'], regionId: 'FRONT-GTB' },
    { label: 'Kara → Mamprusi', fromHub: 'Centre pivot de Kara', from: pt(9.551, 1.186), toName: 'Mamprusi (Togo)', to: pt(10.67, 0.14), targetPeoples: ['Mamprusi'], countryCodes: ['TG'], regionId: 'FRONT-GTB' },
    { label: 'Kara → Anufo du Bénin', fromHub: 'Centre pivot de Kara', from: pt(9.551, 1.186), toName: 'Chokosi Anufo (Bénin)', to: pt(10.30, 1.01), targetPeoples: ['Anufo (Chokosi)'], countryCodes: ['TG', 'BJ'], regionId: 'FRONT-GTB' },
    { label: 'Kara → Biali du Bénin', fromHub: 'Centre pivot de Kara', from: pt(9.551, 1.186), toName: 'Biali (Bénin)', to: pt(10.74, 1.13), targetPeoples: ['Biali'], countryCodes: ['TG', 'BJ'], regionId: 'FRONT-GTB' },
    { label: 'Kara → Biali du Burkina Faso', fromHub: 'Centre pivot de Kara', from: pt(9.551, 1.186), toName: 'Biali (Burkina Faso)', to: pt(11.43, 1.09), targetPeoples: ['Biali'], countryCodes: ['TG', 'BF'], regionId: 'FRONT-GTB' },
    { label: 'Parakou → Nord rural du Bénin', fromHub: 'Centre pivot de Parakou', from: pt(9.337, 2.630), toName: 'Nord rural du Bénin', to: pt(11.13, 2.94), countryCodes: ['BJ'], regionId: 'FRONT-GTB' },
  ],

  // Objectifs cumulés 2026-2030 (« chaque leader formé implante au moins 5 églises de 15 disciples »)
  targets: [
    { indicator: 'ifm', value: 30 },
    { indicator: 'ceimp', value: 300 },
    { indicator: 'peoplesEngaged', value: 150 },
    { indicator: 'countries', value: 15 },
    { indicator: 'partners', value: 120 },
    { indicator: 'personsOfPeace', value: 600000 },
    { indicator: 'churchesPlanted', value: 3000 },
  ],

  // Bilan janvier-juin 2026 : les 18 activités du semestre
  activities: [
    ['2026-01-05', '2026-02-05', 'Formation de Vineyard Guinée au bureau d’Abidjan', 'training', 'equipement', 'CI', 'Abidjan', ['VINEYARD-GN']],
    ['2026-01-12', '2026-01-15', 'Formation des leaders de Vineyard CI', 'leader-training', 'equipement', 'CI', '', ['VINEYARD-CI']],
    ['2026-02-16', '2026-05-20', 'Stage du missionnaire Konan Frank', 'internship', 'equipement', 'CI', '', []],
    ['2026-02-17', '2026-02-21', 'Conférence de vision, Église Wesleyenne', 'vision-conference', 'mobilisation', 'CI', 'Sassandra', ['WESLEYAN']],
    ['2026-03-02', '2026-03-04', 'Forum DMM du groupe ATI', 'forum', 'equipement', 'CI', 'CEFCA', []],
    ['2026-03-09', '2026-03-21', 'MME 2e cohorte, contact 1', 'training', 'equipement', 'CI', 'Briehoa', ['EWM']],
    ['2026-03-20', '2026-03-30', 'Voyage de prospection du Dr Longa en Guinée', 'scouting-trip', 'mobilisation', 'GN', '', []],
    ['2026-04-01', '2026-04-05', 'Word of God Mission', 'leader-training', 'coaching', 'CI', 'Man', ['WOG']],
    ['2026-04-06', '2026-04-12', 'Évaluation de terrain Barala', 'field-assessment', 'mobilisation', 'CI', 'Booko', [], ['Barala']],
    ['2026-04-14', '2026-04-23', 'Cours Perspectives', 'course', 'mobilisation', 'CI', 'CEFCA', []],
    ['2026-04-16', '2026-04-19', 'Film Jésus chez les Néyo', 'jesus-film', 'mobilisation', 'CI', 'Sassandra', ['CFA'], ['Néyo']],
    ['2026-04-21', '2026-04-25', 'Vineyard CI, contact 3', 'training', 'equipement', 'CI', 'Tiéningboué', ['VINEYARD-CI']],
    ['2026-04-27', '2026-05-03', 'Évaluation de terrain Nyabwa', 'field-assessment', 'mobilisation', 'CI', 'Daloa', [], ['Nyabwa']],
    ['2026-05-04', '2026-05-16', 'MME, contact 2', 'training', 'equipement', 'CI', 'Briehoa', ['EWM']],
    ['2026-05-06', '2026-05-11', 'Tournée de terrain Koulango, Ébrié, Koro et Sénoufo', 'field-assessment', 'mobilisation', 'CI', '', [], ['Koulango', 'Ébrié', 'Koro', 'Sénoufo']],
    ['2026-05-12', '2026-05-15', 'Formation DMM urbaine', 'training', 'equipement', 'CI', 'Abidjan', []],
    ['2026-05-17', '2026-05-29', 'Cours Leadership Matters', 'course', 'equipement', 'GH', 'Ghana', []],
    ['2026-06-18', '2026-06-20', '2e formation DMM urbaine', 'training', 'equipement', 'CI', 'Abidjan', []],
  ],
};
