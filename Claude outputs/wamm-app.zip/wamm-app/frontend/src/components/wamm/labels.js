/**
 * Libellés FR/EN des listes de valeurs WAMM (types, statuts, piliers…).
 * L(map, key, isFrench) renvoie le libellé dans la bonne langue.
 */
export const PARTNER_TYPES = {
  church: ['Église', 'Church'], mission: ['Mission', 'Mission'], denomination: ['Dénomination', 'Denomination'],
  agency: ['Agence', 'Agency'], institute: ['Institut', 'Institute'], foundation: ['Fondation / bailleur', 'Foundation / donor'], other: ['Autre', 'Other'],
}
export const PARTNER_LEVELS = {
  strategic: ['Stratégique', 'Strategic'], field: ['Terrain', 'Field'], adopter: ['Adoptant', 'Adopter'],
  financial: ['Financier', 'Financial'], prayer: ['Prière', 'Prayer'],
}
export const PARTNER_STATUSES = {
  active: ['Actif', 'Active'], prospect: ['En discussion', 'Prospect'], paused: ['En pause', 'Paused'], ended: ['Terminé', 'Ended'],
}
export const CENTER_TYPES = {
  ifm: ['Institut de formation missionnaire (IFM)', 'Missionary Training Institute'],
  ceimp: ["Centre d'équipement (CEIMP)", 'Equipping centre'],
  literacy: ["Centre d'alphabétisation", 'Literacy centre'],
  health: ['Centre de santé', 'Health centre'],
  agricultural: ['Centre agricole', 'Agricultural centre'],
  radio: ['Radio', 'Radio'],
  hub: ['Centre pivot', 'Hub centre'],
  office: ['Bureau WAMM', 'WAMM office'],
}
export const CENTER_SHORT = {
  ifm: ['IFM', 'IFM'], ceimp: ['CEIMP', 'Centre'], literacy: ['Alpha.', 'Literacy'], health: ['Santé', 'Health'],
  agricultural: ['Agri.', 'Agri.'], radio: ['Radio', 'Radio'], hub: ['Pivot', 'Hub'], office: ['Bureau', 'Office'],
}
export const CENTER_COLORS = {
  ifm: '#1f6d44', ceimp: '#c8792b', literacy: '#3f6fa8', health: '#b5544a', agricultural: '#6b8e23', radio: '#6b4fa0', hub: '#0f766e', office: '#334155',
}
export const CENTER_STATUSES = {
  existing: ['En fonctionnement', 'Running'], new: ['Nouveau', 'New'], planned: ['Prévu', 'Planned'], paused: ['En pause', 'Paused'], closed: ['Fermé', 'Closed'],
}
export const REACH_STATUSES = {
  frontier: ['Frontière (non atteint, < 0,1 %)', 'Frontier'], unreached: ['Non atteint', 'Unreached'],
  minimally_reached: ['Peu atteint', 'Minimally reached'], partially_reached: ['Partiellement atteint', 'Partially reached'],
  reached: ['Atteint', 'Reached'], unknown: ['Non renseigné', 'Unknown'],
}
export const REACH_COLORS = {
  frontier: '#991b1b', unreached: '#dc2626', minimally_reached: '#f59e0b', partially_reached: '#eab308', reached: '#16a34a', unknown: '#94a3b8',
}
export const PEOPLE_STAGES = {
  identified: ['Identifié', 'Identified'], adopted: ['Adopté', 'Adopted'], workers_sent: ['Ouvriers envoyés', 'Workers sent'],
  engaged: ['Engagé (MFD en cours)', 'Engaged (DMM under way)'], movement: ['Mouvement', 'Movement'],
}
export const STAGE_COLORS = { identified: '#94a3b8', adopted: '#d98e04', workers_sent: '#3f6fa8', engaged: '#1f6d44', movement: '#7c3aed' }
export const COMMITMENTS = {
  prayer: ['Prière', 'Prayer'], workers: ['Ouvriers', 'Workers'], finance: ['Finances', 'Finance'],
  dmm: ['Engagement DMM', 'DMM engagement'], compassion: ['Compassion', 'Compassion'], research: ['Recherche', 'Research'],
}
export const PILLARS = {
  dmm: ['Mouvements de multiplication de disciples', 'Disciple multiplication movements'],
  compassion: ['Ministère de compassion', 'Compassion ministry'],
  prayer: ['Mouvement de prière', 'Prayer movement'],
}
export const PROGRAMME_STATUSES = {
  draft: ['Brouillon', 'Draft'], validation: ['En validation', 'Under validation'], active: ['Actif', 'Active'],
  completed: ['Terminé', 'Completed'], paused: ['En pause', 'Paused'],
}
export const MEC_PILLARS = {
  mobilisation: ['Mobilisation', 'Mobilisation'], equipement: ['Équipement', 'Equipping'], coaching: ['Coaching', 'Coaching'],
  unclassified: ['Non classé', 'Unclassified'],
}
export const MEC_COLORS = { mobilisation: '#c8792b', equipement: '#1f6d44', coaching: '#3f6fa8', unclassified: '#94a3b8' }
export const ACTIVITY_TYPES = {
  'field-assessment': ['Évaluation de terrain', 'Field assessment'], 'scouting-trip': ['Voyage de prospection', 'Scouting trip'],
  'vision-conference': ['Conférence de vision', 'Vision conference'], 'jesus-film': ['Film Jésus', 'Jesus film'],
  internship: ['Stage', 'Internship'], forum: ['Forum', 'Forum'], course: ['Cours', 'Course'],
  'leader-training': ['Formation de leaders', 'Leader training'], compassion: ['Action de compassion', 'Compassion action'],
  training: ['Formation', 'Training'], 'coaching-igrow': ['Coaching iGROW', 'iGROW coaching'], visit: ['Visite', 'Visit'],
  evangelism: ['Évangélisation', 'Evangelism'], baptism: ['Baptême', 'Baptism'], 'church-plant': ["Implantation d'église", 'Church plant'],
  meeting: ['Réunion', 'Meeting'], prayer: ['Prière', 'Prayer'], outreach: ['Rayonnement', 'Outreach'], 'follow-up': ['Suivi', 'Follow-up'], other: ['Autre', 'Other'],
}
export const RESULT_FIELDS = {
  personsOfPeace: ['Personnes de paix', 'Persons of Peace'], discoveryGroups: ['Groupes de découverte', 'Discovery groups'],
  churchesPlanted: ['Églises implantées', 'Churches planted'], baptisms: ['Baptêmes', 'Baptisms'],
  newBelievers: ['Nouveaux croyants', 'New believers'], leadersTrained: ['Leaders formés', 'Leaders trained'],
  secondGenLeaders: ['Leaders 2e génération', '2nd-gen leaders'],
}
export const AXIS_KINDS = { sending: ["Axe d'envoi", 'Sending axis'], outreach: ['Axe de rayonnement', 'Outreach axis'], corridor: ['Corridor', 'Corridor'] }

export const L = (map, key, isFrench = true) => {
  const v = map?.[key]
  if (!v) return key || '—'
  return isFrench ? v[0] : v[1]
}

export const options = (map, isFrench = true) => Object.keys(map).map((k) => ({ value: k, label: L(map, k, isFrench) }))

export const fmt = (n, isFrench = true) =>
  n === null || n === undefined || Number.isNaN(Number(n)) ? '—' : Number(n).toLocaleString(isFrench ? 'fr-FR' : 'en-GB')

export const fmtDate = (d, isFrench = true) => {
  if (!d) return '—'
  const x = new Date(d)
  return Number.isNaN(x.getTime()) ? '—' : x.toLocaleDateString(isFrench ? 'fr-FR' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
}

export const fmtRange = (a, b, isFrench = true) => {
  if (!a) return '—'
  if (!b || new Date(a).toDateString() === new Date(b).toDateString()) return fmtDate(a, isFrench)
  return `${fmtDate(a, isFrench)} → ${fmtDate(b, isFrench)}`
}
