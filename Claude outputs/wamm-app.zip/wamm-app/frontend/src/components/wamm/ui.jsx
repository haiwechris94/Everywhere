/**
 * Composants d'interface partagés par les pages WAMM.
 */
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { X } from 'lucide-react'
import { useAuth } from '../../context/AuthContext'
import { AFRICA_COUNTRIES, getCountry } from '../../config/wammGeography'

export const useCanEdit = () => {
  const { user } = useAuth()
  return { canEdit: user?.role === 'admin' || user?.role === 'supervisor', isAdmin: user?.role === 'admin' }
}

export const PageHeader = ({ eyebrow, title, subtitle, actions }) => (
  <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
    <div className="min-w-0">
      {eyebrow && <p className="text-xs font-bold uppercase tracking-[0.14em] text-accent-600">{eyebrow}</p>}
      <h1 className="mt-1 text-3xl font-bold text-slate-900 dark:text-slate-100 sm:text-4xl">{title}</h1>
      {subtitle && <p className="mt-2 max-w-3xl text-sm text-slate-600 dark:text-slate-300">{subtitle}</p>}
    </div>
    {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
  </div>
)

export const Card = ({ title, action, children, className = '', bodyClass = 'p-5' }) => (
  <section className={`rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-700 dark:bg-slate-800 ${className}`}>
    {(title || action) && (
      <div className="flex items-center justify-between gap-3 border-b border-slate-100 px-5 py-3 dark:border-slate-700">
        <h2 className="text-sm font-bold text-slate-800 dark:text-slate-100">{title}</h2>
        {action}
      </div>
    )}
    <div className={bodyClass}>{children}</div>
  </section>
)

export const Stat = ({ label, value, hint, tone = 'slate' }) => {
  const tones = {
    slate: 'text-slate-900 dark:text-slate-100',
    green: 'text-primary-700 dark:text-primary-300',
    ochre: 'text-accent-600 dark:text-accent-300',
  }
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-800">
      <p className={`text-3xl font-bold tabular-nums ${tones[tone] || tones.slate}`}>{value}</p>
      <p className="mt-1 text-xs font-semibold text-slate-600 dark:text-slate-300">{label}</p>
      {hint && <p className="mt-1 text-[11px] text-slate-400">{hint}</p>}
    </div>
  )
}

export const Badge = ({ color = '#64748b', children, title }) => (
  <span
    title={title}
    className="inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] font-semibold"
    style={{ backgroundColor: `${color}1a`, color }}
  >
    <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: color }} />
    {children}
  </span>
)

export const Progress = ({ value = 0, color = '#1f6d44' }) => (
  <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-700">
    <div className="h-full rounded-full transition-all" style={{ width: `${Math.max(0, Math.min(100, value))}%`, backgroundColor: color }} />
  </div>
)

export const Loading = ({ label = 'Chargement…' }) => (
  <div className="flex items-center justify-center gap-3 py-16 text-sm text-slate-500">
    <span className="h-6 w-6 animate-spin rounded-full border-2 border-primary-600 border-b-transparent" />
    {label}
  </div>
)

export const ErrorBox = ({ error, label }) => (
  <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
    {label}
    {error ? <span className="block text-xs opacity-80">{String(error?.response?.data?.message || error?.message || error)}</span> : null}
  </div>
)

export const Empty = ({ children }) => (
  <div className="rounded-xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-500 dark:border-slate-600">{children}</div>
)

export const Button = ({ variant = 'primary', className = '', ...props }) => {
  const v = {
    primary: 'bg-primary-700 text-white hover:bg-primary-800 disabled:opacity-60',
    ghost: 'border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200',
    danger: 'border border-red-300 bg-white text-red-600 hover:bg-red-50',
  }
  return <button type="button" className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-semibold transition-colors ${v[variant]} ${className}`} {...props} />
}

export const Modal = ({ open, title, onClose, children, wide = false }) => {
  useEffect(() => {
    if (!open) return undefined
    const onKey = (e) => e.key === 'Escape' && onClose?.()
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])
  if (!open) return null
  return (
    <div className="fixed inset-0 z-[1200] flex items-start justify-center overflow-y-auto bg-slate-900/50 p-4 sm:items-center" onMouseDown={onClose}>
      <div className={`w-full ${wide ? 'max-w-3xl' : 'max-w-xl'} rounded-2xl bg-white shadow-xl dark:bg-slate-800`} onMouseDown={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3 dark:border-slate-700">
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">{title}</h3>
          <button type="button" onClick={onClose} className="rounded p-1 text-slate-500 hover:bg-slate-100" aria-label="Fermer"><X size={18} /></button>
        </div>
        <div className="max-h-[75vh] overflow-y-auto p-5">{children}</div>
      </div>
    </div>
  )
}

export const CountryName = ({ code, isFrench = true, link = false }) => {
  const c = getCountry(code)
  const name = c ? (isFrench ? c.name : c.nameEn) : (code || '—')
  return link && c ? <Link className="hover:underline" to={`/carte?pays=${c.code}`}>{name}</Link> : <>{name}</>
}

export const countryOptions = (isFrench = true) =>
  AFRICA_COUNTRIES
    .map((c) => ({ value: c.code, label: isFrench ? c.name : c.nameEn }))
    .sort((a, b) => a.label.localeCompare(b.label, isFrench ? 'fr' : 'en'))

// ── Formulaire générique piloté par un schéma de champs ─────────────────────
// Champ : { name, label, type: text|textarea|number|select|multiselect|tags|date|latlng|checkbox, options, required, help, full }
const toInput = (field, value) => {
  if (field.type === 'date') return value ? String(value).slice(0, 10) : ''
  if (field.type === 'tags') return Array.isArray(value) ? value.join(', ') : (value || '')
  if (field.type === 'latlng') {
    const c = value?.coordinates
    return { lat: c ? c[1] : '', lng: c ? c[0] : '' }
  }
  if (field.type === 'select' && value && typeof value === 'object') return value._id || ''
  if (field.type === 'multiselect') return Array.isArray(value) ? value.map((v) => (v && typeof v === 'object' ? v._id : v)) : []
  return value ?? (field.type === 'checkbox' ? false : '')
}

const fromInput = (field, value) => {
  if (field.type === 'number') return value === '' || value === null ? undefined : Number(value)
  if (field.type === 'tags') return String(value || '').split(',').map((s) => s.trim()).filter(Boolean)
  if (field.type === 'latlng') {
    const lat = value?.lat === '' ? NaN : Number(value?.lat)
    const lng = value?.lng === '' ? NaN : Number(value?.lng)
    return Number.isFinite(lat) && Number.isFinite(lng) ? { lat, lng } : null
  }
  if (field.type === 'select' && value === '') return field.nullable ? null : undefined
  return value
}

export const EntityForm = ({ fields, initial = {}, onSubmit, onCancel, submitLabel = 'Enregistrer', isFrench = true }) => {
  const [values, setValues] = useState(() => Object.fromEntries(fields.map((f) => [f.name, toInput(f, initial[f.name] ?? f.default)])))
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState(null)
  const set = (name, v) => setValues((prev) => ({ ...prev, [name]: v }))

  const submit = async (e) => {
    e.preventDefault()
    setSaving(true); setError(null)
    try {
      const body = {}
      fields.forEach((f) => { const v = fromInput(f, values[f.name]); if (v !== undefined) body[f.name] = v })
      await onSubmit(body)
    } catch (err) {
      setError(err?.response?.data?.message || err?.message || 'Erreur')
    } finally {
      setSaving(false)
    }
  }

  const inputCls = 'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-200 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-100'

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        {fields.map((f) => (
          <label key={f.name} className={`block ${f.full || f.type === 'textarea' || f.type === 'multiselect' ? 'sm:col-span-2' : ''}`}>
            <span className="mb-1 block text-xs font-semibold text-slate-600 dark:text-slate-300">
              {f.label}{f.required ? ' *' : ''}
            </span>
            {f.type === 'textarea' ? (
              <textarea rows={3} className={inputCls} value={values[f.name]} onChange={(e) => set(f.name, e.target.value)} required={f.required} />
            ) : f.type === 'select' ? (
              <select className={inputCls} value={values[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} required={f.required}>
                <option value="">{isFrench ? '— Choisir —' : '— Select —'}</option>
                {f.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            ) : f.type === 'multiselect' ? (
              <div className="flex max-h-40 flex-wrap gap-1.5 overflow-y-auto rounded-lg border border-slate-200 p-2 dark:border-slate-600">
                {f.options.map((o) => {
                  const on = (values[f.name] || []).includes(o.value)
                  return (
                    <button
                      type="button" key={o.value}
                      onClick={() => set(f.name, on ? values[f.name].filter((x) => x !== o.value) : [...(values[f.name] || []), o.value])}
                      className={`rounded-full border px-2.5 py-1 text-xs font-medium ${on ? 'border-primary-600 bg-primary-600 text-white' : 'border-slate-300 text-slate-600 hover:bg-slate-50 dark:text-slate-300'}`}
                    >
                      {o.label}
                    </button>
                  )
                })}
              </div>
            ) : f.type === 'checkbox' ? (
              <input type="checkbox" className="h-4 w-4" checked={!!values[f.name]} onChange={(e) => set(f.name, e.target.checked)} />
            ) : f.type === 'latlng' ? (
              <div className="flex gap-2">
                <input className={inputCls} type="number" step="any" placeholder="Latitude" value={values[f.name].lat} onChange={(e) => set(f.name, { ...values[f.name], lat: e.target.value })} />
                <input className={inputCls} type="number" step="any" placeholder="Longitude" value={values[f.name].lng} onChange={(e) => set(f.name, { ...values[f.name], lng: e.target.value })} />
              </div>
            ) : (
              <input
                className={inputCls}
                type={f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : 'text'}
                min={f.min} step={f.type === 'number' ? 'any' : undefined}
                value={values[f.name]} onChange={(e) => set(f.name, e.target.value)} required={f.required}
                placeholder={f.placeholder}
              />
            )}
            {f.help && <span className="mt-1 block text-[11px] text-slate-400">{f.help}</span>}
          </label>
        ))}
      </div>
      {error && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}
      <div className="flex justify-end gap-2 border-t border-slate-100 pt-4 dark:border-slate-700">
        {onCancel && <Button variant="ghost" onClick={onCancel}>{isFrench ? 'Annuler' : 'Cancel'}</Button>}
        <button type="submit" disabled={saving} className="rounded-lg bg-primary-700 px-4 py-2 text-sm font-semibold text-white hover:bg-primary-800 disabled:opacity-60">
          {saving ? (isFrench ? 'Enregistrement…' : 'Saving…') : submitLabel}
        </button>
      </div>
    </form>
  )
}

export const Table = ({ columns, rows, empty, onRowClick }) => (
  <div className="overflow-x-auto">
    <table className="min-w-full text-sm">
      <thead>
        <tr className="border-b border-slate-200 text-left text-[11px] font-bold uppercase tracking-wide text-slate-500 dark:border-slate-700">
          {columns.map((c) => <th key={c.key} className={`whitespace-nowrap px-3 py-2 ${c.right ? 'text-right' : ''}`}>{c.label}</th>)}
        </tr>
      </thead>
      <tbody>
        {rows.length === 0 ? (
          <tr><td colSpan={columns.length} className="px-3 py-8 text-center text-slate-400">{empty}</td></tr>
        ) : rows.map((r, i) => (
          <tr
            key={r._id || r.key || i}
            onClick={onRowClick ? () => onRowClick(r) : undefined}
            className={`border-b border-slate-100 last:border-0 dark:border-slate-700/60 ${onRowClick ? 'cursor-pointer hover:bg-primary-50/50 dark:hover:bg-slate-700/40' : ''}`}
          >
            {columns.map((c) => <td key={c.key} className={`px-3 py-2.5 align-top ${c.right ? 'text-right tabular-nums' : ''}`}>{c.render ? c.render(r) : r[c.key]}</td>)}
          </tr>
        ))}
      </tbody>
    </table>
  </div>
)
