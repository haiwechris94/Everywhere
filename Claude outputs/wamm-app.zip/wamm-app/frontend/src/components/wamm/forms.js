/**
 * Schémas des formulaires WAMM (utilisés par EntityForm).
 */
import { WAMM_REGIONS } from '../../config/wammGeography'
import { countryOptions } from './ui'
import {
  options, PARTNER_TYPES, PARTNER_LEVELS, PARTNER_STATUSES, CENTER_TYPES, CENTER_STATUSES, REACH_STATUSES,
  PEOPLE_STAGES, COMMITMENTS, PILLARS, PROGRAMME_STATUSES, RESULT_FIELDS, AXIS_KINDS,
} from './labels'

const regionOptions = (fr) => WAMM_REGIONS.map((r) => ({ value: r.id, label: fr ? r.name : r.nameEn }))

export const partnerFields = (fr) => [
  { name: 'name', label: fr ? 'Nom' : 'Name', required: true },
  { name: 'acronym', label: fr ? 'Sigle / nom court' : 'Acronym' },
  { name: 'type', label: 'Type', type: 'select', options: options(PARTNER_TYPES, fr), required: true },
  { name: 'status', label: fr ? 'Statut' : 'Status', type: 'select', options: options(PARTNER_STATUSES, fr) },
  { name: 'levels', label: fr ? 'Nature du partenariat' : 'Partnership', type: 'multiselect', options: options(PARTNER_LEVELS, fr) },
  { name: 'countryCodes', label: fr ? 'Pays' : 'Countries', type: 'multiselect', options: countryOptions(fr) },
  { name: 'city', label: fr ? 'Ville (siège)' : 'City (HQ)' },
  { name: 'since', label: fr ? 'Partenaire depuis (année)' : 'Partner since (year)', type: 'number' },
  { name: 'website', label: fr ? 'Site web' : 'Website' },
  { name: 'supportTypes', label: fr ? 'Types d’appui (séparés par des virgules)' : 'Support types (comma separated)', type: 'tags', full: true },
  { name: 'description', label: 'Description', type: 'textarea' },
]

export const centerFields = (fr, { partners = [], programmes = [] } = {}) => [
  { name: 'name', label: fr ? 'Nom' : 'Name', required: true },
  { name: 'type', label: 'Type', type: 'select', options: options(CENTER_TYPES, fr), required: true },
  { name: 'status', label: fr ? 'Statut' : 'Status', type: 'select', options: options(CENTER_STATUSES, fr) },
  { name: 'countryCode', label: fr ? 'Pays' : 'Country', type: 'select', options: countryOptions(fr), required: true },
  { name: 'city', label: fr ? 'Localité' : 'Place' },
  { name: 'zone', label: 'Zone', placeholder: fr ? 'ex. Zone 1 : Nord-Est' : 'e.g. Zone 1: North-East' },
  { name: 'partner', label: fr ? 'Partenaire' : 'Partner', type: 'select', nullable: true, options: partners.map((p) => ({ value: p._id, label: p.name })) },
  { name: 'programme', label: fr ? 'Programme' : 'Programme', type: 'select', nullable: true, options: programmes.map((p) => ({ value: p._id, label: p.name })) },
  { name: 'openingYear', label: fr ? 'Année d’ouverture' : 'Opening year', type: 'number' },
  { name: 'location', label: fr ? 'Position (latitude, longitude)' : 'Position (latitude, longitude)', type: 'latlng', help: fr ? 'Laisser vide si inconnue : le centre apparaîtra dans « à géolocaliser ».' : 'Leave empty if unknown.' },
  { name: 'locationApprox', label: fr ? 'Position indicative' : 'Indicative position', type: 'checkbox' },
  { name: 'peoplesServed', label: fr ? 'Peuples servis (séparés par des virgules)' : 'Peoples served (comma separated)', type: 'tags', full: true },
  { name: 'description', label: 'Description', type: 'textarea' },
]

export const resultFields = (fr) => [
  { name: 'periodLabel', label: fr ? 'Période' : 'Period', required: true, placeholder: fr ? 'ex. Avril-Mai 2026' : 'e.g. April-May 2026' },
  { name: 'from', label: fr ? 'Du' : 'From', type: 'date' },
  { name: 'to', label: fr ? 'Au' : 'To', type: 'date' },
  ...Object.keys(RESULT_FIELDS).map((k) => ({ name: k, label: fr ? RESULT_FIELDS[k][0] : RESULT_FIELDS[k][1], type: 'number', min: 0 })),
  { name: 'notes', label: 'Notes', type: 'textarea' },
]

export const focusPeopleFields = (fr, { programmes = [] } = {}) => [
  { name: 'name', label: fr ? 'Nom du peuple' : 'People name', required: true },
  { name: 'alternateNames', label: fr ? 'Autres noms (virgules)' : 'Other names (comma separated)', type: 'tags' },
  { name: 'countryCode', label: fr ? 'Pays principal' : 'Main country', type: 'select', options: countryOptions(fr), required: true },
  { name: 'otherCountryCodes', label: fr ? 'Présent aussi dans' : 'Also present in', type: 'multiselect', options: countryOptions(fr) },
  { name: 'reachStatus', label: fr ? 'Statut d’atteinte' : 'Reach status', type: 'select', options: options(REACH_STATUSES, fr) },
  { name: 'stage', label: fr ? 'Étape WAMM' : 'WAMM stage', type: 'select', options: options(PEOPLE_STAGES, fr) },
  { name: 'population', label: 'Population', type: 'number', min: 0 },
  { name: 'lot', label: fr ? 'Lot d’adoption' : 'Adoption lot' },
  { name: 'religion', label: fr ? 'Religion' : 'Religion' },
  { name: 'area', label: fr ? 'Zone / préfecture' : 'Area' },
  { name: 'workersNeeded', label: fr ? 'Ouvriers pionniers nécessaires' : 'Pioneer workers needed', type: 'number', min: 0 },
  { name: 'workersInPlace', label: fr ? 'Ouvriers en place' : 'Workers in place', type: 'number', min: 0 },
  { name: 'declaredAdopters', label: fr ? 'Adoptants annoncés (non nominatifs)' : 'Announced adopters', type: 'number', min: 0 },
  { name: 'adoptionEvent', label: fr ? 'Événement d’adoption' : 'Adoption event' },
  { name: 'programme', label: fr ? 'Programme' : 'Programme', type: 'select', nullable: true, options: programmes.map((p) => ({ value: p._id, label: p.name })) },
  { name: 'isPastoral', label: fr ? 'Peuple pastoral / nomade' : 'Pastoral / nomadic people', type: 'checkbox' },
  { name: 'location', label: fr ? 'Position (latitude, longitude)' : 'Position (latitude, longitude)', type: 'latlng' },
  { name: 'locationApprox', label: fr ? 'Position indicative' : 'Indicative position', type: 'checkbox', default: true },
  { name: 'notes', label: 'Notes', type: 'textarea' },
]

export const adoptionFields = (fr, { partners = [], peoples = [] } = {}) => [
  { name: 'focusPeople', label: fr ? 'Peuple' : 'People', type: 'select', required: true, options: peoples.map((p) => ({ value: p._id, label: p.name })) },
  { name: 'partner', label: fr ? 'Partenaire adoptant' : 'Adopting partner', type: 'select', nullable: true, options: partners.map((p) => ({ value: p._id, label: p.name })) },
  { name: 'adopterName', label: fr ? 'Ou nom de l’adoptant (non enregistré)' : 'Or adopter name', help: fr ? 'Église ou organisation pas encore enregistrée comme partenaire.' : '' },
  { name: 'event', label: fr ? 'Événement' : 'Event', placeholder: fr ? 'ex. Conférence de vision de Lomé' : '' },
  { name: 'date', label: 'Date', type: 'date' },
  { name: 'commitments', label: fr ? 'Engagements' : 'Commitments', type: 'multiselect', options: options(COMMITMENTS, fr) },
  { name: 'workersCommitted', label: fr ? 'Ouvriers promis' : 'Workers committed', type: 'number', min: 0 },
  { name: 'status', label: fr ? 'Statut' : 'Status', type: 'select', options: [
    { value: 'committed', label: fr ? 'Engagé' : 'Committed' }, { value: 'active', label: fr ? 'Actif' : 'Active' },
    { value: 'paused', label: fr ? 'En pause' : 'Paused' }, { value: 'ended', label: fr ? 'Terminé' : 'Ended' }] },
  { name: 'notes', label: 'Notes', type: 'textarea' },
]

export const programmeFields = (fr, { partners = [] } = {}) => [
  { name: 'key', label: fr ? 'Code' : 'Code', required: true, placeholder: 'FULANI-MERGON' },
  { name: 'name', label: fr ? 'Nom' : 'Name', required: true },
  { name: 'pillar', label: fr ? 'Pilier' : 'Pillar', type: 'select', options: options(PILLARS, fr) },
  { name: 'status', label: fr ? 'Statut' : 'Status', type: 'select', options: options(PROGRAMME_STATUSES, fr) },
  { name: 'regionId', label: fr ? 'Front / zone' : 'Front / area', type: 'select', options: regionOptions(fr) },
  { name: 'countryCodes', label: fr ? 'Pays' : 'Countries', type: 'multiselect', options: countryOptions(fr) },
  { name: 'partners', label: fr ? 'Partenaires' : 'Partners', type: 'multiselect', options: partners.map((p) => ({ value: p._id, label: p.acronym || p.name })) },
  { name: 'startYear', label: fr ? 'Début (année)' : 'Start year', type: 'number' },
  { name: 'endYear', label: fr ? 'Fin (année)' : 'End year', type: 'number' },
  { name: 'targetPeoples', label: fr ? 'Peuples visés (virgules)' : 'Target peoples (comma separated)', type: 'tags', full: true },
  { name: 'description', label: 'Description', type: 'textarea' },
]

export const axisFields = (fr, { centers = [] } = {}) => [
  { name: 'label', label: fr ? 'Libellé' : 'Label', required: true },
  { name: 'kind', label: 'Type', type: 'select', options: options(AXIS_KINDS, fr) },
  { name: 'fromCenter', label: fr ? 'Centre de départ' : 'From centre', type: 'select', nullable: true, options: centers.map((c) => ({ value: c._id, label: c.name })) },
  { name: 'fromName', label: fr ? 'Départ (nom)' : 'From (name)' },
  { name: 'from', label: fr ? 'Départ (lat, lng)' : 'From (lat, lng)', type: 'latlng' },
  { name: 'toName', label: fr ? 'Destination' : 'Destination', required: true },
  { name: 'to', label: fr ? 'Destination (lat, lng)' : 'Destination (lat, lng)', type: 'latlng' },
  { name: 'regionId', label: fr ? 'Front / zone' : 'Front / area', type: 'select', options: regionOptions(fr) },
  { name: 'targetPeoples', label: fr ? 'Peuples visés (virgules)' : 'Target peoples', type: 'tags' },
  { name: 'status', label: fr ? 'Statut' : 'Status', type: 'select', options: [{ value: 'active', label: fr ? 'Actif' : 'Active' }, { value: 'planned', label: fr ? 'Prévu' : 'Planned' }, { value: 'paused', label: fr ? 'En pause' : 'Paused' }] },
]
