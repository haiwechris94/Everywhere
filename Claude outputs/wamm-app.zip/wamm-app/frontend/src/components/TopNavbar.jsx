/**
 * TopNavbar - Collapsible vertical left sidebar navigation
 */
import { useState, useRef, useEffect } from 'react'
import { NavLink, useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useLanguage } from '../i18n'
import LanguageSwitcher from './LanguageSwitcher'
import {
  User,
  LogOut,
  Menu,
  X,
  Shield,
  LayoutDashboard,
  MapPin,
  Globe,
  FolderKanban,
  Activity,
  BarChart3,
  Database,
  Flag,
  PanelLeftClose,
  PanelLeftOpen,
  ChevronDown,
  ChevronRight,
  Target,
  HeartHandshake,
  School,
  Heart,
  Users,
  Sprout,
} from 'lucide-react'

const COLLAPSE_KEY = 'sidebar.collapsed'

const TopNavbar = () => {
  const { user, logout } = useAuth()
  const { t, isFrench } = useLanguage()
  const navigate = useNavigate()
  const location = useLocation()

  const [mobileOpen, setMobileOpen] = useState(false)
  const [collapsed, setCollapsed] = useState(() => {
    try { return localStorage.getItem(COLLAPSE_KEY) === 'true' } catch { return false }
  })
  const [mainOpen, setMainOpen] = useState(true)
  const [networkOpen, setNetworkOpen] = useState(true)
  const [reportingOpen, setReportingOpen] = useState(false)
  const [managementOpen, setManagementOpen] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const userMenuRef = useRef(null)

  // Navigation WAMM : pilotage, réseau, terrain (MFD/DMM), gestion.
  const navGroups = [
    {
      title: isFrench ? 'PILOTAGE' : 'STEERING',
      open: mainOpen,
      setOpen: setMainOpen,
      items: [
        { path: '/dashboard', label: isFrench ? 'Tableau de bord' : 'Dashboard', icon: LayoutDashboard, exact: true },
        { path: '/carte', label: isFrench ? 'Carte WAMM' : 'WAMM map', icon: MapPin },
        { path: '/objectifs', label: isFrench ? 'Objectifs 2026-2030' : 'Targets 2026-2030', icon: Target },
        { path: '/bilan', label: isFrench ? 'Bilan M.E.C.' : 'M.E.C. report', icon: BarChart3 },
      ],
    },
    {
      title: isFrench ? 'RÉSEAU WAMM' : 'WAMM NETWORK',
      open: networkOpen,
      setOpen: setNetworkOpen,
      items: [
        { path: '/partenaires', label: isFrench ? 'Partenaires' : 'Partners', icon: HeartHandshake },
        { path: '/centres', label: isFrench ? 'Centres et instituts' : 'Centres and institutes', icon: School },
        { path: '/adoptions', label: isFrench ? 'Peuples et adoptions' : 'Peoples and adoptions', icon: Heart },
        { path: '/programmes', label: isFrench ? 'Programmes' : 'Programmes', icon: FolderKanban },
      ],
    },
    {
      title: isFrench ? 'TERRAIN MFD' : 'DMM FIELD',
      open: reportingOpen,
      setOpen: setReportingOpen,
      items: [
        { path: '/regions', label: isFrench ? 'Régions et fronts' : 'Regions and fronts', icon: Globe },
        { path: '/countries', label: isFrench ? 'Pays' : 'Countries', icon: Flag },
        { path: '/people-groups', label: isFrench ? 'Référentiel des peuples' : 'People groups', icon: Users },
        { path: '/engagements', label: isFrench ? 'Engagements MFD' : 'DMM engagements', icon: Sprout },
        { path: '/persons', label: isFrench ? 'Personnes' : 'People', icon: User },
        { path: '/activities', label: isFrench ? 'Activités' : 'Activities', icon: Activity },
        { path: '/dmm-reporting', label: isFrench ? 'Rapports MFD' : 'DMM reports', icon: BarChart3 },
        { path: '/unified-map', label: isFrench ? 'Carte des villages' : 'Village map', icon: MapPin },
      ],
    },
    {
      title: isFrench ? 'GESTION' : 'MANAGEMENT',
      open: managementOpen,
      setOpen: setManagementOpen,
      items: [
        { path: '/data-management', label: isFrench ? 'Données' : 'Data', icon: Database },
        ...(user?.role === 'admin' ? [{ path: '/admin/users', label: 'Administration', icon: Shield, admin: true }] : []),
      ],
    },
  ]

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target)) {
        setUserMenuOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  useEffect(() => {
    setMobileOpen(false)
  }, [location.pathname])

  useEffect(() => {
    try { localStorage.setItem(COLLAPSE_KEY, String(collapsed)) } catch { /* noop */ }
  }, [collapsed])

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const isActive = (path) => {
    if (path === '/dashboard') {
      return location.pathname === '/dashboard' || location.pathname === '/'
    }
    if (path === '/map') {
      return location.pathname.startsWith('/map') || location.pathname.startsWith('/geojson-map')
    }
    return location.pathname.startsWith(path)
  }

  const renderNavItem = (item) => {
    const active = isActive(item.path)
    const Icon = item.icon
    return (
      <NavLink
        key={item.path}
        to={item.path}
        onClick={() => setMobileOpen(false)}
        title={collapsed ? item.label : undefined}
        className={
          `flex items-center gap-3 rounded-lg text-[15px] font-medium transition-all duration-150 font-[Arial] ${collapsed ? 'lg:justify-center lg:px-0 px-3' : 'px-3'} py-2.5 ${
            active
              ? 'bg-neutral-900 text-white dark:bg-slate-100 dark:text-slate-900'
              : 'text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 dark:text-slate-400 dark:hover:text-slate-100 dark:hover:bg-slate-700'
          }${item.admin ? (active ? '' : ' bg-red-50 text-red-700 hover:bg-red-100 hover:text-red-800 dark:bg-red-900/40 dark:text-red-300 dark:hover:bg-red-900/60 dark:hover:text-red-200') : ''}`
        }
      >
        {Icon && <Icon size={18} className="flex-shrink-0" />}
        <span className={`whitespace-nowrap font-normal font-[Arial] ${collapsed ? 'lg:hidden' : ''}`}>{item.label}</span>
      </NavLink>
    )
  }

  const width = collapsed ? 'lg:w-16' : 'lg:w-64'

  return (
    <>
      {/* Mobile top bar (hamburger + logo) */}
      <header className="lg:hidden bg-white dark:bg-slate-800 shadow-sm border-b border-neutral-200 dark:border-slate-700 sticky top-0 z-50">
        <div className="flex items-center justify-between h-14 px-4">
          <button
            onClick={() => setMobileOpen(true)}
            className="p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-slate-700 transition-colors text-neutral-600 dark:text-slate-300"
            aria-label="Open menu"
          >
            <Menu size={22} />
          </button>
          <NavLink to="/dashboard" className="flex items-center gap-2">
            <img src="/brand-wamm-logo.jpg" alt="WAMM — West Africa Missionary Movements" className="h-8 w-auto rounded" />
          </NavLink>
          <LanguageSwitcher variant="compact" />
        </div>
      </header>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/40 dark:bg-black/60 z-50"
          onClick={() => setMobileOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          bg-white dark:bg-slate-800 border-r border-neutral-200 dark:border-slate-700 flex flex-col z-50
          fixed inset-y-0 left-0 w-64 transform transition-transform duration-200
          ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}
          lg:static lg:translate-x-0 lg:h-screen lg:sticky lg:top-0 ${width} lg:transition-[width] lg:duration-200
        `}
      >
        {/* Header: logo + collapse toggle */}
        <div className={`flex items-center h-14 flex-shrink-0 border-b border-neutral-200 dark:border-slate-700 ${collapsed ? 'lg:justify-center px-2' : 'justify-between px-4'}`}>
          <NavLink to="/dashboard" className="flex items-center gap-2.5 overflow-hidden">
            <img src={collapsed ? '/brand-wamm-mark.png' : '/brand-wamm-logo.jpg'} alt="WAMM — West Africa Missionary Movements" className={`${collapsed ? 'h-9 w-9' : 'h-10 w-auto'} flex-shrink-0 rounded`} />
          </NavLink>
          {/* Close on mobile */}
          <button
            onClick={() => setMobileOpen(false)}
            className="lg:hidden p-1.5 rounded-lg hover:bg-neutral-100 dark:hover:bg-slate-700 text-neutral-600 dark:text-slate-300"
            aria-label="Close menu"
          >
            <X size={20} />
          </button>
          {/* Collapse toggle on desktop */}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className={`hidden lg:inline-flex p-1.5 rounded-lg hover:bg-neutral-100 dark:hover:bg-slate-700 text-neutral-500 dark:text-slate-400 hover:text-neutral-800 dark:hover:text-slate-100 ${collapsed ? 'lg:hidden' : ''}`}
            aria-label="Collapse sidebar"
            title="Réduire"
          >
            <PanelLeftClose size={18} />
          </button>
        </div>

        {/* Expand button visible when collapsed (desktop) */}
        {collapsed && (
          <button
            onClick={() => setCollapsed(false)}
            className="hidden lg:flex items-center justify-center h-9 mx-2 mt-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-slate-700 text-neutral-500 dark:text-slate-400 hover:text-neutral-800 dark:hover:text-slate-100"
            aria-label="Expand sidebar"
            title="Développer"
          >
            <PanelLeftOpen size={18} />
          </button>
        )}

        {/* Nav items */}
        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-2 dark:bg-slate-800">
          {navGroups.map((group) => (
            <div key={group.title} className="space-y-1">
              <button
                type="button"
                onClick={() => group.setOpen((v) => !v)}
                className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm tracking-widest text-neutral-400 dark:text-slate-500 ${collapsed ? 'lg:justify-center' : ''}`}
                aria-expanded={group.open}
              >
                <span className={`font-normal ${collapsed ? 'lg:hidden' : ''}`}>{group.title}</span>
                {!collapsed && (group.open ? <ChevronDown size={16} /> : <ChevronRight size={16} />)}
              </button>
              {group.open && (
                <div className="space-y-0.5">
                  {group.items.map(renderNavItem)}
                </div>
              )}
            </div>
          ))}
        </nav>

        {/* Footer: language (desktop) + user */}
        <div className="flex-shrink-0 border-t border-neutral-200 dark:border-slate-700 p-2 space-y-1">
          <div className={`hidden lg:block ${collapsed ? 'lg:hidden' : ''} px-1 py-1`}>
            <LanguageSwitcher variant="compact" />
          </div>
          <div className="relative" ref={userMenuRef}>
            <button
              onClick={() => setUserMenuOpen(!userMenuOpen)}
              className={`flex items-center gap-2.5 w-full rounded-xl hover:bg-neutral-50 dark:hover:bg-slate-700 transition-all duration-150 border border-transparent hover:border-neutral-200 dark:hover:border-slate-600 ${collapsed ? 'lg:justify-center px-2' : 'px-2.5'} py-2`}
              aria-label="User menu"
              title={collapsed ? user?.name : undefined}
            >
              <div className="w-8 h-8 flex-shrink-0 bg-gradient-to-br from-neutral-700 to-neutral-900 dark:from-slate-600 dark:to-slate-800 rounded-full flex items-center justify-center">
                <User size={15} className="text-white dark:text-slate-100" />
              </div>
              <div className={`flex-1 min-w-0 text-left ${collapsed ? 'lg:hidden' : ''}`}>
                <p className="text-sm font-semibold text-neutral-800 dark:text-slate-100 truncate">{user?.name}</p>
                <p className="text-xs text-neutral-400 dark:text-slate-500 truncate">{user?.email}</p>
              </div>
            </button>

            {userMenuOpen && (
              <div className="absolute bottom-full left-0 mb-2 w-52 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-neutral-200 dark:border-slate-700 py-2 overflow-hidden z-50">
                <div className="px-4 py-2.5 border-b border-neutral-100 dark:border-slate-700">
                  <p className="text-sm font-semibold text-neutral-800 dark:text-slate-100">{user?.name}</p>
                  <p className="text-xs text-neutral-400 dark:text-slate-500 truncate">{user?.email}</p>
                </div>
                <div className="py-1">
                  <NavLink
                    to="/profile"
                    onClick={() => setUserMenuOpen(false)}
                    className="flex items-center gap-3 px-4 py-2 text-sm text-neutral-700 dark:text-slate-300 hover:bg-neutral-50 dark:hover:bg-slate-700 transition-colors"
                  >
                    <User size={15} />
                    <span>{t('nav.profile') || 'Profil'}</span>
                  </NavLink>
                </div>
                <div className="border-t border-neutral-100 dark:border-slate-700 pt-1">
                  <button
                    onClick={handleLogout}
                    className="flex items-center gap-3 px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/30 w-full transition-colors"
                  >
                    <LogOut size={15} />
                    <span>{t('auth.logout') || 'Déconnexion'}</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </aside>
    </>
  )
}

export default TopNavbar
