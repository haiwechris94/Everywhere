/**
 * App.jsx - Main Application Router
 * 
 * OPTIMIZED: Implements React.lazy() for code splitting and lazy loading
 * Heavy components (MapView, GeoJSONMapView, VoronoiMapPage) are loaded on demand
 * This significantly reduces initial bundle size and improves first load time
 * 
 * @author WAMM
 * @version 2.0.0 - Performance Optimized
 */

import { Suspense, lazy } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './context/AuthContext'
import Layout from './components/Layout'
import { useParams } from 'react-router-dom'
import { getCountry } from './config/wammGeography'
import ErrorBoundary from './components/ErrorBoundary'

// ============================================================================
// EAGER LOADED COMPONENTS (Critical Path - needed immediately)
// These are loaded in the main bundle for fast initial render
// ============================================================================
import Login from './pages/Login'
import Register from './pages/Register'
import ResetPassword from './pages/ResetPassword'

// ============================================================================
// LAZY LOADED COMPONENTS (Code Splitting - loaded on demand)
// These heavy components are split into separate chunks
// Reduces initial bundle size by ~60% for faster first load
// ============================================================================

// Dashboard components - loaded after authentication
const DashboardEnhanced = lazy(() => import('./pages/DashboardEnhanced'))
const AnalyticsTablePage = lazy(() => import('./pages/AnalyticsTablePage'))

// Map components - HEAVY (~1600 lines each) - loaded only when navigating to map
const GeoJSONMapView = lazy(() => import('./pages/GeoJSONMapView'))
const VoronoiMapPage = lazy(() => import('./pages/VoronoiMapPage'))
const UnifiedMapView = lazy(() => import('./pages/UnifiedMapView'))

// Secondary pages - loaded on demand
const Profile = lazy(() => import('./pages/Profile'))
const PeopleGroupDetail = lazy(() => import('./pages/PeopleGroupDetail'))
const VillageDetail = lazy(() => import('./pages/VillageDetail'))
// Pages WAMM — fonctionnement interne
const WammDashboard = lazy(() => import('./pages/wamm/WammDashboard'))
const WammMap = lazy(() => import('./pages/wamm/WammMap'))
const WammTargets = lazy(() => import('./pages/wamm/Targets'))
const WammMecReport = lazy(() => import('./pages/wamm/MecReport'))
const PartnersList = lazy(() => import('./pages/wamm/Partners').then((m) => ({ default: m.PartnersList })))
const PartnerDetail = lazy(() => import('./pages/wamm/Partners').then((m) => ({ default: m.PartnerDetail })))
const CentersList = lazy(() => import('./pages/wamm/Centers').then((m) => ({ default: m.CentersList })))
const CenterDetail = lazy(() => import('./pages/wamm/Centers').then((m) => ({ default: m.CenterDetail })))
const AdoptionBoard = lazy(() => import('./pages/wamm/Adoptions').then((m) => ({ default: m.AdoptionBoard })))
const FocusPeopleDetail = lazy(() => import('./pages/wamm/Adoptions').then((m) => ({ default: m.FocusPeopleDetail })))
const ProgrammesList = lazy(() => import('./pages/wamm/Programmes').then((m) => ({ default: m.ProgrammesList })))
const ProgrammeDetail = lazy(() => import('./pages/wamm/Programmes').then((m) => ({ default: m.ProgrammeDetail })))
const DataManagement = lazy(() => import('./pages/DataManagement'))
const PendingValidations = lazy(() => import('./pages/PendingValidations'))
const RejectedPeopleGroups = lazy(() => import('./pages/RejectedPeopleGroups'))

// DMM pillars — nouvelles pages
const DmmReporting = lazy(() => import('./pages/DmmReporting'))
const DmmReviewQueue = lazy(() => import('./pages/DmmReviewQueue'));
const Regions = lazy(() => import('./pages/Regions'))
const Pays = lazy(() => import('./pages/Pays'))
const RegionCountries = lazy(() => import('./pages/RegionCountries'))
const CountryPeoples = lazy(() => import('./pages/CountryPeoples'))
const PeopleDetailLite = lazy(() => import('./pages/PeopleDetailLite'))
const EngagementDetail = lazy(() => import('./pages/EngagementDetail'))
const PlanterEngagements = lazy(() => import('./pages/PlanterEngagements'))
const DonorEngagements = lazy(() => import('./pages/DonorEngagements'))
const Activities = lazy(() => import('./pages/Activities'))
const PeopleGroupsList = lazy(() => import('./pages/PeopleGroupsList'))
const EngagementsList = lazy(() => import('./pages/EngagementsList'))
const PersonsList = lazy(() => import('./pages/PersonsList'))


// Admin pages - lazy loaded, admin-only access
const AdminUsers = lazy(() => import('./pages/AdminUsers'))

// ============================================================================
// LOADING FALLBACK COMPONENT
// Shown while lazy components are being loaded
// ============================================================================
const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center bg-gray-50">
    <div className="text-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
      <p className="text-gray-500 text-sm">Chargement...</p>
    </div>
  </div>
)

// Compact loader for nested routes
const CompactLoader = () => (
  <div className="flex items-center justify-center py-12">
    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
  </div>
)

// /pays/:code → fiche pays dans sa sous-région (/regions/OUEST/countries/CI)
const PaysRedirect = () => {
  const { code } = useParams()
  const c = getCountry(code)
  return <Navigate to={c ? `/regions/${c.subregion}/countries/${c.code}` : '/countries'} replace />
}

const ProtectedRoute = ({ children }) => {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  if (!user) {
    return <Navigate to="/login" replace />
  }

  return children
}

/**
 * AdminRoute - Protected route that requires admin role
 * Redirects to dashboard if user is not an admin
 */
const AdminRoute = ({ children }) => {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  if (!user) {
    return <Navigate to="/login" replace />
  }

  if (user.role !== 'admin') {
    return <Navigate to="/dashboard" replace />
  }

  return children
}

const PublicRoute = ({ children }) => {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  if (user) {
    // Après connexion, la première page affichée est le tableau de bord WAMM.
    return <Navigate to="/dashboard" replace />
  }

  return children
}

function App() {
  return (
    // Wrap entire app in Suspense for lazy-loaded components
    <Suspense fallback={<PageLoader />}>
      <Routes>
        {/* Public Routes - Login/Register are eagerly loaded for fast initial render */}
        <Route
          path="/login"
          element={
            <PublicRoute>
              <Login />
            </PublicRoute>
          }
        />
        <Route
          path="/register"
          element={
            <PublicRoute>
              <Register />
            </PublicRoute>
          }
        />
        <Route
          path="/reset-password/:token"
          element={
            <PublicRoute>
              <ResetPassword />
            </PublicRoute>
          }
        />

        {/* Protected Routes - All lazy loaded for code splitting */}
        <Route
          path="/"
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Navigate to="/dashboard" replace />} />

          {/* ── WAMM : pilotage et réseau ── */}
          <Route path="dashboard" element={<Suspense fallback={<CompactLoader />}><WammDashboard /></Suspense>} />
          <Route path="carte" element={
            <ErrorBoundary fallbackMessage="Erreur lors du chargement de la carte WAMM.">
              <Suspense fallback={<CompactLoader />}><WammMap /></Suspense>
            </ErrorBoundary>
          } />
          <Route path="objectifs" element={<Suspense fallback={<CompactLoader />}><WammTargets /></Suspense>} />
          <Route path="bilan" element={<Suspense fallback={<CompactLoader />}><WammMecReport /></Suspense>} />
          <Route path="partenaires" element={<Suspense fallback={<CompactLoader />}><PartnersList /></Suspense>} />
          <Route path="partenaires/:id" element={<Suspense fallback={<CompactLoader />}><PartnerDetail /></Suspense>} />
          <Route path="centres" element={<Suspense fallback={<CompactLoader />}><CentersList /></Suspense>} />
          <Route path="centres/:id" element={<Suspense fallback={<CompactLoader />}><CenterDetail /></Suspense>} />
          <Route path="adoptions" element={<Suspense fallback={<CompactLoader />}><AdoptionBoard /></Suspense>} />
          <Route path="adoptions/:id" element={<Suspense fallback={<CompactLoader />}><FocusPeopleDetail /></Suspense>} />
          <Route path="programmes" element={<Suspense fallback={<CompactLoader />}><ProgrammesList /></Suspense>} />
          <Route path="programmes/:id" element={<Suspense fallback={<CompactLoader />}><ProgrammeDetail /></Suspense>} />
          <Route path="pays/:code" element={<PaysRedirect />} />
          {/* Ancien tableau de bord DMM (analyses détaillées) */}
          <Route path="dmm-dashboard" element={
            <Suspense fallback={<CompactLoader />}>
              <DashboardEnhanced />
            </Suspense>
          } />
          <Route path="analytics-table" element={
            <Suspense fallback={<CompactLoader />}>
              <AnalyticsTablePage />
            </Suspense>
          } />
          
          {/* Map Views - HEAVY components, lazy loaded with error boundaries */}
          <Route path="unified-map" element={
            <ErrorBoundary fallbackMessage="Erreur lors du chargement de la carte unifiee.">
              <Suspense fallback={<CompactLoader />}>
                <UnifiedMapView />
              </Suspense>
            </ErrorBoundary>
          } />
          {/* Legacy Map route removed - redirect to the unified map */}
          <Route path="map" element={<Navigate to="/unified-map" replace />} />
          <Route path="geojson-map" element={<Navigate to="/unified-map" replace />} />
          <Route path="voronoi-map" element={
            <ErrorBoundary fallbackMessage="Erreur lors du chargement de la carte Voronoi.">
              <Suspense fallback={<CompactLoader />}>
                <VoronoiMapPage />
              </Suspense>
            </ErrorBoundary>
          } />
          
          {/* Secondary pages - lazy loaded */}
          <Route path="activities" element={
            <Suspense fallback={<CompactLoader />}>
              <Activities />
            </Suspense>
          } />
          {/* Les initiatives ESP300/YCS du réseau NG sont remplacées par les programmes WAMM. */}
          <Route path="initiatives/*" element={<Navigate to="/programmes" replace />} />
          <Route path="projects/*" element={<Navigate to="/programmes" replace />} />
          <Route path="pending-validations" element={
            <Suspense fallback={<CompactLoader />}>
              <PendingValidations />
            </Suspense>
          } />
          <Route path="dmm-review" element={<Suspense fallback={<CompactLoader />}><DmmReviewQueue /></Suspense>} />
          <Route path="rejected-people-groups" element={
            <Suspense fallback={<CompactLoader />}>
              <RejectedPeopleGroups />
            </Suspense>
          } />
          {/* DMM pillars — groupes DBS, reporting */}
          <Route path="dmm-reporting" element={
            <Suspense fallback={<CompactLoader />}>
              <DmmReporting />
            </Suspense>
          } />
          <Route path="regions" element={
            <Suspense fallback={<CompactLoader />}>
              <Regions />
            </Suspense>
          } />
          <Route path="countries" element={
            <Suspense fallback={<CompactLoader />}>
              <Pays />
            </Suspense>
          } />
          <Route path="regions/:regionId" element={
            <Suspense fallback={<CompactLoader />}>
              <RegionCountries />
            </Suspense>
          } />
          <Route path="regions/:regionId/countries/:countryCode" element={
            <Suspense fallback={<CompactLoader />}>
              <CountryPeoples />
            </Suspense>
          } />
          <Route path="regions/:regionId/countries/:countryCode/peoples/:peopleId" element={
            <Suspense fallback={<CompactLoader />}>
              <PeopleDetailLite />
            </Suspense>
          } />
          <Route path="regions/:regionId/countries/:countryCode/peoples/:peopleId/engagements/:engagementId" element={
            <ErrorBoundary fallbackMessage="Error loading engagement details.">
              <Suspense fallback={<CompactLoader />}>
                <EngagementDetail />
              </Suspense>
            </ErrorBoundary>
          } />
          <Route path="engagements/:engagementId" element={
            <ErrorBoundary fallbackMessage="Error loading engagement details.">
              <Suspense fallback={<CompactLoader />}>
                <EngagementDetail />
              </Suspense>
            </ErrorBoundary>
          } />
          <Route path="data-management" element={
            <Suspense fallback={<CompactLoader />}>
              <DataManagement />
            </Suspense>
          } />
          <Route path="profile" element={
            <Suspense fallback={<CompactLoader />}>
              <Profile />
            </Suspense>
          } />
          <Route path="people-groups/:id" element={
            <ErrorBoundary fallbackMessage="Error loading people group details.">
              <Suspense fallback={<CompactLoader />}>
                <PeopleGroupDetail />
              </Suspense>
            </ErrorBoundary>
          } />
          <Route path="planters/:name/engagements" element={
            <ErrorBoundary fallbackMessage="Error loading planter engagements.">
              <Suspense fallback={<CompactLoader />}>
                <PlanterEngagements />
              </Suspense>
            </ErrorBoundary>
          } />
          <Route path="donors/:name/engagements" element={
            <ErrorBoundary fallbackMessage="Error loading donor engagements.">
              <Suspense fallback={<CompactLoader />}>
                <DonorEngagements />
              </Suspense>
            </ErrorBoundary>
          } />
          <Route path="villages/:id" element={
            <ErrorBoundary fallbackMessage="Error loading village details.">
              <Suspense fallback={<CompactLoader />}>
                <VillageDetail />
              </Suspense>
            </ErrorBoundary>
          } />
          
          {/* People Groups / Engagements / Persons - global list pages */}
          <Route path="people-groups" element={
            <Suspense fallback={<CompactLoader />}>
              <PeopleGroupsList />
            </Suspense>
          } />
          <Route path="engagements" element={
            <Suspense fallback={<CompactLoader />}>
              <EngagementsList />
            </Suspense>
          } />
          <Route path="persons" element={
            <Suspense fallback={<CompactLoader />}>
              <PersonsList />
            </Suspense>
          } />
          <Route path="peoples" element={<Navigate to="/people-groups" replace />} />

          {/* Admin Routes - Admin-only access */}
          <Route path="admin/users" element={
            <AdminRoute>
              <Suspense fallback={<CompactLoader />}>
                <AdminUsers />
              </Suspense>
            </AdminRoute>
          } />
        </Route>

        {/* Catch all */}
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Suspense>
  )
}

export default App
