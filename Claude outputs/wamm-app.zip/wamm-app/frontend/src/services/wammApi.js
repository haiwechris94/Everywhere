import api from './api'

/**
 * API WAMM — backend/routes/wamm.js (monté sur /api/wamm).
 * Chaque ressource expose list/get/create/update/remove.
 */
const resource = (path) => ({
  list: (params = {}) => api.get(`/api/wamm/${path}`, { params }).then((r) => r.data.data),
  get: (id) => api.get(`/api/wamm/${path}/${id}`).then((r) => r.data.data),
  create: (body) => api.post(`/api/wamm/${path}`, body).then((r) => r.data.data),
  update: (id, body) => api.put(`/api/wamm/${path}/${id}`, body).then((r) => r.data.data),
  remove: (id) => api.delete(`/api/wamm/${path}/${id}`).then((r) => r.data),
})

const withResults = (path) => ({
  ...resource(path),
  addResult: (id, body) => api.post(`/api/wamm/${path}/${id}/results`, body).then((r) => r.data.data),
  updateResult: (id, resultId, body) => api.put(`/api/wamm/${path}/${id}/results/${resultId}`, body).then((r) => r.data.data),
  removeResult: (id, resultId) => api.delete(`/api/wamm/${path}/${id}/results/${resultId}`).then((r) => r.data.data),
})

export const wammApi = {
  partners: resource('partners'),
  centers: withResults('centers'),
  focusPeoples: resource('focus-peoples'),
  adoptions: resource('adoptions'),
  programmes: withResults('programmes'),
  targets: resource('targets'),
  axes: resource('axes'),
  meta: () => api.get('/api/wamm/meta').then((r) => r.data.data),
  overview: () => api.get('/api/wamm/overview').then((r) => r.data.data),
  map: () => api.get('/api/wamm/map').then((r) => r.data.data),
  mecReport: (params = {}) => api.get('/api/wamm/reports/mec', { params }).then((r) => r.data.data),
}

export const errorMessage = (err) =>
  err?.response?.data?.message || err?.response?.data?.error || err?.message || 'Erreur inconnue'

export default wammApi
