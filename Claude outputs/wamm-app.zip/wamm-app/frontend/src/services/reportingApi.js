import api from './api'

/**
 * Reporting / géographie WAMM API wrapper.
 * Backed by backend/routes/reporting.js (mounted at /api/reporting) and
 * backend/routes/masterPeople.js (mounted at /api/master-people).
 *
 * Funnel: Regions -> Countries (per region) -> Peoples (per country) -> Person.
 *
 * Response shapes:
 *  - getRegions()        -> { data: [ { id, name, fullName, countryCount, countries:[{code,code3,name,nameEn,capital,...}] } ] }
 *  - getRegion(id)       -> { data: { id, name, fullName, countries:[...], metrics:<NUMREPORT> } }
 *  - getRegionCountry()  -> { data: { region:{id,name}, country:{...}, metrics:<NUMREPORT> } }
 *  - getPeoples(params)  -> { meta:{ totals, pagination }, data:[ { masterPeopleId, canonicalName, status, dmm, ... } ] }
 *  - getPerson(id)       -> { ...profile with nested `overview` }  (no dmm rollup)
 */
export const reportingApi = {
  getRegions: () => api.get('/api/reporting/regions'),
  // Flat list of every country across all regions, with per-country
  // { engagements, totalPGs, unreachedPGs } summaries for the Pays page.
  getCountries: (params = {}) => api.get('/api/reporting/countries', { params }),
  getRegion: (regionId, params = {}) =>
    api.get(`/api/reporting/regions/${regionId}`, { params }),
  getRegionCountry: (regionId, code, params = {}) =>
    api.get(`/api/reporting/regions/${regionId}/countries/${code}`, { params }),
  getPeoples: (params = {}) => api.get('/api/reporting/peoples', { params }),
  getPerson: (id) => api.get(`/api/master-people/${id}/profile`),
}


/**
 * Region / Country ADMIN overlay API — editable regions & countries.
 * Backed by backend/routes/regionAdmin.js (mounted at /api/region-admin).
 * Admin/supervisor only for writes. Overlays augment the built-in NG regions
 * (sous-régions, fronts WAMM) and ISO countries, and allow brand-new custom regions/countries
 * with editable leader/responsible names.
 *
 *  - listRegions()               -> { data: [ RegionOverlay ] }
 *  - createRegion(body)          -> { data: RegionOverlay }   (body: { regionId, name, fullName, description, leaders, responsibleName, countryCodes })
 *  - updateRegion(regionId, body)-> { data: RegionOverlay }   (upsert)
 *  - deleteRegion(regionId)      -> { data: ... }             (custom only)
 *  - listCountries()             -> { data: [ CountryOverlay ] }
 *  - createCountry(body)         -> { data: CountryOverlay }  (body: { code, code3, nameFr, nameEn, capital, regionId, leaders, responsibleName, defaultCenter, description })
 *  - updateCountry(code, body)   -> { data: CountryOverlay }  (upsert)
 *  - deleteCountry(code)         -> { data: ... }             (custom only)
 */
export const regionAdminApi = {
  listRegions: () => api.get('/api/region-admin/regions'),
  createRegion: (body) => api.post('/api/region-admin/regions', body),
  updateRegion: (regionId, body) => api.put(`/api/region-admin/regions/${regionId}`, body),
  deleteRegion: (regionId) => api.delete(`/api/region-admin/regions/${regionId}`),
  listCountries: () => api.get('/api/region-admin/countries'),
  createCountry: (body) => api.post('/api/region-admin/countries', body),
  updateCountry: (code, body) => api.put(`/api/region-admin/countries/${code}`, body),
  deleteCountry: (code) => api.delete(`/api/region-admin/countries/${code}`),
}

export default reportingApi
