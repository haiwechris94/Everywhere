﻿import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useSearchParams, useNavigate } from 'react-router-dom'
import { activitiesApi, villagesApi, churchesApi, peopleGroupsApi } from '../services/api'
import { useAuth } from '../context/AuthContext'
import {
  Search,
  Plus,
  Calendar,
  MapPin,
  Church,
  X,
  Clock,
  Users,
  ClipboardCheck,
  AlertCircle,
  Archive,
  ArchiveRestore,
  Eye,
  EyeOff,
  Heart,
  BookOpen,
  GraduationCap,
  Megaphone,
  Music,
  UsersRound,
  MessageCircle,
  MoreHorizontal,
  ChevronDown,
  Filter,
} from 'lucide-react'
import toast from 'react-hot-toast'
import { format } from 'date-fns'
import { fr, enUS } from 'date-fns/locale'
import { useLanguage } from '../i18n'

const activityTypeKeys = [
  'evangelism',
  'discipleship',
  'prayer',
  'training',
  'outreach',
  'worship',
  'meeting',
  'coaching-igrow',
  // Types WAMM (méthode M.E.C.)
  'field-assessment',
  'scouting-trip',
  'vision-conference',
  'jesus-film',
  'internship',
  'forum',
  'course',
  'leader-training',
  'compassion',
  'other',
]

// Activity type configurations with icons and colors
const activityTypeConfig = {
  evangelism: { 
    icon: Megaphone, 
    color: '#8b5cf6', 
    bgColor: 'bg-purple-100', 
    textColor: 'text-purple-700',
    borderColor: 'border-l-purple-500'
  },
  discipleship: { 
    icon: BookOpen, 
    color: '#3b82f6', 
    bgColor: 'bg-blue-100', 
    textColor: 'text-blue-700',
    borderColor: 'border-l-blue-500'
  },
  prayer: { 
    icon: Heart, 
    color: '#eab308', 
    bgColor: 'bg-yellow-100', 
    textColor: 'text-yellow-700',
    borderColor: 'border-l-yellow-500'
  },
  training: { 
    icon: GraduationCap, 
    color: '#22c55e', 
    bgColor: 'bg-green-100', 
    textColor: 'text-green-700',
    borderColor: 'border-l-green-500'
  },
  outreach: { 
    icon: Heart, 
    color: '#f97316', 
    bgColor: 'bg-orange-100', 
    textColor: 'text-orange-700',
    borderColor: 'border-l-orange-500'
  },
  worship: { 
    icon: Music, 
    color: '#ec4899', 
    bgColor: 'bg-pink-100', 
    textColor: 'text-pink-700',
    borderColor: 'border-l-pink-500'
  },
  meeting: { 
    icon: UsersRound, 
    color: '#6b7280', 
    bgColor: 'bg-gray-100 dark:bg-slate-800', 
    textColor: 'text-gray-700',
    borderColor: 'border-l-gray-500'
  },
  'coaching-igrow': { 
    icon: MessageCircle, 
    color: '#14b8a6', 
    bgColor: 'bg-teal-100', 
    textColor: 'text-teal-700',
    borderColor: 'border-l-teal-500'
  },
  other: { 
    icon: MoreHorizontal, 
    color: '#6b7280', 
    bgColor: 'bg-gray-100 dark:bg-slate-800', 
    textColor: 'text-gray-700',
    borderColor: 'border-l-gray-400'
  },
}

// Coaching iGROW conversation partner options
const coachingConversationWithOptions = [
  { value: 'leader', labelKey: 'activities.coaching.leader' },
  { value: 'church-planter', labelKey: 'activities.coaching.churchPlanter' },
  { value: 'other', labelKey: 'activities.coaching.otherPerson' },
]

const Activities = () => {
  const { t, language } = useLanguage()
  const { user } = useAuth()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const [searchParams] = useSearchParams()
  
  // Build activity types with translations
  const activityTypes = activityTypeKeys.map(key => ({
    value: key,
    label: t(`activities.types.${key}`)
  }))
  
  // Get date locale based on current language
  const dateLocale = language === 'fr' ? fr : enUS

  const [searchTerm, setSearchTerm] = useState('')
  const [typeFilter, setTypeFilter] = useState('')
  const [villageFilter, setVillageFilter] = useState(searchParams.get('village') || '')
  const [churchFilter, setChurchFilter] = useState(searchParams.get('church') || '')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [showFilters, setShowFilters] = useState(false)
  const [showAddModal, setShowAddModal] = useState(false)
  const [showArchived, setShowArchived] = useState(false)
  const [newActivity, setNewActivity] = useState({
    type: 'evangelism',
    description: '',
    date: '',
    village: '',
    church: '',
    participants: '',
    notes: '',
    coachingDetails: {
      conversationWith: '',
      conversationTheme: '',
      duration: '',
    },
  })

  const { data: activitiesData, isLoading, error } = useQuery({
    queryKey: ['activities', searchTerm, typeFilter, villageFilter, churchFilter, dateFrom, dateTo],
    queryFn: async () => {
      const params = {}
      if (searchTerm) params.search = searchTerm
      if (typeFilter) params.type = typeFilter
      if (villageFilter) params.village = villageFilter
      if (churchFilter) params.church = churchFilter
      if (dateFrom) params.dateFrom = dateFrom
      if (dateTo) params.dateTo = dateTo
      const response = await activitiesApi.getAll(params)
      return response.data.activities || []
    },
  })

  const { data: villages } = useQuery({
    queryKey: ['villages-list'],
    queryFn: async () => {
      const response = await villagesApi.getAll()
      return response.data.villages || []
    },
  })

  const { data: churches } = useQuery({
    queryKey: ['churches-list'],
    queryFn: async () => {
      const response = await churchesApi.getAll()
      return response.data.churches || []
    },
  })

  // Query for pending validations count (only for supervisors/admins)
  const canValidate = user?.role === 'admin' || user?.role === 'supervisor'
  const { data: pendingData } = useQuery({
    queryKey: ['pendingValidationsCount'],
    queryFn: async () => {
      const response = await peopleGroupsApi.getPending({ limit: 1 })
      return response.data
    },
    enabled: canValidate,
  })
  const pendingCount = pendingData?.total || 0

  // Query for rejected people groups count (only for supervisors/admins)
  const { data: rejectedData } = useQuery({
    queryKey: ['rejectedPeopleGroupsCount'],
    queryFn: async () => {
      const response = await peopleGroupsApi.getRejectedCount()
      return response.data
    },
    enabled: canValidate,
  })
  const rejectedCount = rejectedData?.total || 0

  const createMutation = useMutation({
    mutationFn: (data) => activitiesApi.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['activities'])
      toast.success(t('activities.messages.createSuccess'))
      resetForm()
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || t('activities.messages.createError'))
    },
  })

  const archiveMutation = useMutation({
    mutationFn: ({ id, archived }) => activitiesApi.archive(id, archived),
    onSuccess: (response, variables) => {
      queryClient.invalidateQueries(['activities'])
      toast.success(variables.archived ? t('activities.messages.archiveSuccess') : t('activities.messages.unarchiveSuccess'))
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || t('activities.messages.archiveError'))
    },
  })

  const handleArchive = (activityId, currentArchived) => {
    archiveMutation.mutate({ id: activityId, archived: !currentArchived })
  }

  const resetForm = () => {
    setShowAddModal(false)
    setNewActivity({
      type: 'evangelism',
      description: '',
      date: '',
      village: '',
      church: '',
      participants: '',
      notes: '',
      coachingDetails: {
        conversationWith: '',
        conversationTheme: '',
        duration: '',
      },
    })
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const activityData = {
      ...newActivity,
      participants: parseInt(newActivity.participants) || 0,
    }
    if (!activityData.village) delete activityData.village
    if (!activityData.church) delete activityData.church
    if (activityData.type === 'coaching-igrow') {
      activityData.coachingDetails = {
        conversationWith: newActivity.coachingDetails.conversationWith || undefined,
        conversationTheme: newActivity.coachingDetails.conversationTheme || undefined,
        duration: parseInt(newActivity.coachingDetails.duration) || undefined,
      }
    } else {
      delete activityData.coachingDetails
    }
    createMutation.mutate(activityData)
  }

  const clearFilters = () => {
    setSearchTerm('')
    setTypeFilter('')
    setVillageFilter('')
    setChurchFilter('')
    setDateFrom('')
    setDateTo('')
  }

  const allActivities = activitiesData || []
  const activities = showArchived 
    ? allActivities 
    : allActivities.filter(a => !a.archived)
  const archivedCount = allActivities.filter(a => a.archived).length
  const hasActiveFilters = searchTerm || typeFilter || villageFilter || churchFilter || dateFrom || dateTo

  // Calculate type counts
  const typeCounts = activities.reduce((acc, a) => {
    acc[a.type] = (acc[a.type] || 0) + 1
    return acc
  }, {})

  // Loading skeleton
  if (isLoading) {
    return (
      <div className="space-y-6 animate-fade-in">
        <div>
          <div className="h-8 w-48 bg-gray-200 rounded-lg animate-pulse mb-4"></div>
          <div className="h-6 w-32 bg-gray-200 rounded-lg animate-pulse"></div>
        </div>
        <div className="space-y-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="bg-white dark:bg-slate-800 rounded-xl p-6 shadow-sm">
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-gray-200 rounded-xl animate-pulse"></div>
                <div className="flex-1">
                  <div className="h-5 w-24 bg-gray-200 rounded animate-pulse mb-2"></div>
                  <div className="h-4 w-3/4 bg-gray-200 rounded animate-pulse"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <div className="text-center bg-white dark:bg-slate-800 rounded-2xl shadow-lg p-12 max-w-md">
          <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <X size={40} className="text-red-500" />
          </div>
          <h3 className="text-xl font-bold text-gray-900 dark:text-slate-100 mb-2">{t('activities.messages.loadError')}</h3>
          <p className="text-gray-500 dark:text-slate-400">{t('activities.messages.loadErrorDesc')}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header — titre noir en haut, actions neutres à droite, sans grand cadre */}
      <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-slate-100">{t('activities.title')}</h1>
          <p className="text-gray-500 dark:text-slate-400 mt-1">
            {t('activities.totalCount').replace('{count}', activities.length)}
          </p>
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap gap-3">
          {canValidate && (
            <>
              <button
                onClick={() => navigate('/pending-validations')}
                className="relative flex items-center gap-2 px-4 py-2 border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-700 rounded-lg hover:bg-gray-50 dark:bg-slate-900 transition-colors"
              >
                <ClipboardCheck size={18} />
                <span className="text-sm font-medium">{t('validation.pendingValidations')}</span>
                {pendingCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full min-w-[20px] text-center shadow">
                    {pendingCount > 99 ? '99+' : pendingCount}
                  </span>
                )}
              </button>
              <button
                onClick={() => navigate('/rejected-people-groups')}
                className="relative flex items-center gap-2 px-4 py-2 border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-700 rounded-lg hover:bg-gray-50 dark:bg-slate-900 transition-colors"
              >
                <AlertCircle size={18} />
                <span className="text-sm font-medium">{t('rejected.rejectedPeopleGroups')}</span>
                {rejectedCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full min-w-[20px] text-center shadow">
                    {rejectedCount > 99 ? '99+' : rejectedCount}
                  </span>
                )}
              </button>
            </>
          )}
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-5 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors font-semibold"
          >
            <Plus size={18} />
            {t('activities.newActivity')}
          </button>
        </div>
      </div>

      {/* Liens externes : site officiel + calendrier détaillé */}

      {/* Search and Type Filter Tabs */}
      <div className="bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 overflow-hidden">
        {/* Search Bar */}
        <div className="p-4 border-b border-gray-100 dark:border-slate-700">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 relative">
              <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder={t('activities.searchPlaceholder')}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-gray-400 focus:border-transparent transition-all"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className={`flex items-center gap-2 px-4 py-3 rounded-xl border transition-all ${
                  showFilters 
                    ? 'bg-gray-900 border-gray-900 text-white' 
                    : 'bg-gray-50 dark:bg-slate-900 border-gray-200 dark:border-slate-700 text-gray-600 dark:text-slate-400 hover:bg-gray-100 dark:bg-slate-800'
                }`}
              >
                <Filter size={18} />
                {t('common.filters')}
                {hasActiveFilters && (
                  <span className="w-2 h-2 bg-gray-900 rounded-full"></span>
                )}
                <ChevronDown size={16} className={`transition-transform ${showFilters ? 'rotate-180' : ''}`} />
              </button>
              <button
                onClick={() => setShowArchived(!showArchived)}
                className={`flex items-center gap-2 px-4 py-3 rounded-xl border transition-all ${
                  showArchived 
                    ? 'bg-gray-200 border-gray-300 text-gray-700' 
                    : 'bg-gray-50 dark:bg-slate-900 border-gray-200 dark:border-slate-700 text-gray-600 dark:text-slate-400 hover:bg-gray-100 dark:bg-slate-800'
                }`}
                title={showArchived ? t('activities.hideArchived') : t('activities.showArchived')}
              >
                {showArchived ? <EyeOff size={18} /> : <Eye size={18} />}
                <Archive size={18} />
                {archivedCount > 0 && (
                  <span className="bg-gray-500 text-white text-xs px-2 py-0.5 rounded-full">{archivedCount}</span>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Activity Type Filter Tabs - Horizontal Scrollable */}
        <div className="px-4 py-3 overflow-x-auto scrollbar-hide">
          <div className="flex gap-2 min-w-max">
            <button
              onClick={() => setTypeFilter('')}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                typeFilter === '' 
                  ? 'bg-gray-900 text-white shadow-sm' 
                  : 'bg-gray-100 dark:bg-slate-800 text-gray-600 dark:text-slate-400 hover:bg-gray-200'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-current opacity-60"></span>
              {t('activities.filters.allTypes')}
              <span className={`px-1.5 py-0.5 rounded-full text-xs ${typeFilter === '' ? 'bg-white dark:bg-slate-800/20' : 'bg-gray-200'}`}>
                {activities.length}
              </span>
            </button>
            {activityTypes.map((type) => {
              const config = activityTypeConfig[type.value] || activityTypeConfig.other
              const TypeIcon = config.icon
              const count = typeCounts[type.value] || 0
              return (
                <button
                  key={type.value}
                  onClick={() => setTypeFilter(type.value)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                    typeFilter === type.value 
                      ? `${config.bgColor} ${config.textColor} shadow-md ring-2 ring-offset-1`
                      : 'bg-gray-100 dark:bg-slate-800 text-gray-600 dark:text-slate-400 hover:bg-gray-200'
                  }`}
                  style={typeFilter === type.value ? { '--tw-ring-color': config.color } : {}}
                >
                  <TypeIcon size={16} style={{ color: typeFilter === type.value ? config.color : '#6b7280' }} />
                  {type.label}
                  {count > 0 && (
                    <span className={`px-1.5 py-0.5 rounded-full text-xs ${
                      typeFilter === type.value ? 'bg-white dark:bg-slate-800/50' : 'bg-gray-200'
                    }`}>
                      {count}
                    </span>
                  )}
                </button>
              )
            })}
          </div>
        </div>

        {/* Advanced Filters Panel */}
        {showFilters && (
          <div className="px-4 pb-4 pt-2 border-t border-gray-100 dark:border-slate-700 animate-fade-in">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">{t('activities.labels.village')}</label>
                <select
                  value={villageFilter}
                  onChange={(e) => setVillageFilter(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-gray-400 focus:border-transparent"
                >
                  <option value="">{t('activities.filters.allVillages')}</option>
                  {villages?.map((village) => (
                    <option key={village._id} value={village._id}>{village.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">{t('activities.labels.church')}</label>
                <select
                  value={churchFilter}
                  onChange={(e) => setChurchFilter(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-gray-400 focus:border-transparent"
                >
                  <option value="">{t('activities.filters.allChurches')}</option>
                  {churches?.map((church) => (
                    <option key={church._id} value={church._id}>{church.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">{t('activities.filters.dateFrom')}</label>
                <input
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-gray-400 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">{t('activities.filters.dateTo')}</label>
                <input
                  type="date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-gray-400 focus:border-transparent"
                />
              </div>
            </div>
            {hasActiveFilters && (
              <button 
                onClick={clearFilters}
                className="mt-4 flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors text-sm font-medium"
              >
                <X size={16} />
                {t('common.clearFilters') || 'Effacer les filtres'}
              </button>
            )}
          </div>
        )}
      </div>

      {/* Activities List */}
      {activities.length > 0 ? (
        <div className="space-y-4">
          {activities.map((activity) => {
            const config = activityTypeConfig[activity.type] || activityTypeConfig.other
            const TypeIcon = config.icon
            return (
              <div
                key={activity._id}
                className={`group bg-white dark:bg-slate-800 rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden border-l-4 ${config.borderColor} ${
                  activity.archived ? 'opacity-60' : ''
                }`}
              >
                <div className="p-5">
                  <div className="flex items-start gap-4">
                    {/* Icon Badge */}
                    <div 
                      className={`p-3 rounded-xl ${config.bgColor} transition-transform group-hover:scale-110`}
                    >
                      <TypeIcon size={24} style={{ color: config.color }} />
                    </div>
                    
                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-2">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${config.bgColor} ${config.textColor}`}>
                          {activityTypes.find((t) => t.value === activity.type)?.label || activity.type}
                        </span>
                        {activity.archived && (
                          <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-200 text-gray-600 dark:text-slate-400 flex items-center gap-1">
                            <Archive size={12} />
                            {t('activities.archived')}
                          </span>
                        )}
                      </div>
                      
                      <p className="font-medium text-gray-900 dark:text-slate-100 mb-3">{activity.description}</p>
                      
                      {/* Date - Prominent Display */}
                      {activity.date && (
                        <div className="flex items-center gap-2 mb-3">
                          <div className="flex items-center gap-2 px-3 py-1.5 bg-gray-100 dark:bg-slate-800 rounded-lg">
                            <Calendar size={16} className="text-gray-500 dark:text-slate-400" />
                            <span className="text-sm font-medium text-gray-700">
                              {format(new Date(activity.date), 'EEEE dd MMMM yyyy', { locale: dateLocale })}
                            </span>
                          </div>
                        </div>
                      )}
                      
                      {/* Location Tags */}
                      <div className="flex flex-wrap items-center gap-3 text-sm">
                        {activity.village && (
                          <span className="flex items-center gap-1.5 px-3 py-1 bg-blue-50 text-blue-700 rounded-full">
                            <MapPin size={14} />
                            {activity.village.name || activity.village}
                          </span>
                        )}
                        {activity.church && (
                          <span className="flex items-center gap-1.5 px-3 py-1 bg-purple-50 text-purple-700 rounded-full">
                            <Church size={14} />
                            {activity.church.name || activity.church}
                          </span>
                        )}
                        {activity.participants > 0 && (
                          <span className="flex items-center gap-1.5 px-3 py-1 bg-green-50 text-green-700 rounded-full">
                            <Users size={14} />
                            {activity.participants} {t('common.participants').toLowerCase()}
                          </span>
                        )}
                      </div>

                      {activity.notes && (
                        <p className="mt-3 text-sm text-gray-600 dark:text-slate-400 bg-gray-50 dark:bg-slate-900 p-3 rounded-lg border-l-2 border-gray-300">
                          {activity.notes}
                        </p>
                      )}
                    </div>
                    
                    {/* Actions */}
                    <div className="flex flex-col items-end gap-2">
                      {activity.createdAt && (
                        <span className="text-xs text-gray-400 flex items-center gap-1">
                          <Clock size={12} />
                          {format(new Date(activity.createdAt), 'HH:mm')}
                        </span>
                      )}
                      <button
                        onClick={() => handleArchive(activity._id, activity.archived)}
                        disabled={archiveMutation.isLoading}
                        className={`p-2 rounded-lg transition-all ${
                          activity.archived 
                            ? 'text-green-600 hover:bg-green-50 hover:scale-110' 
                            : 'text-gray-400 hover:bg-gray-100 dark:bg-slate-800 hover:text-gray-600 dark:text-slate-400 hover:scale-110'
                        }`}
                        title={activity.archived ? t('activities.unarchive') : t('activities.archive')}
                      >
                        {activity.archived ? <ArchiveRestore size={18} /> : <Archive size={18} />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      ) : (
        /* Empty State */
        <div className="p-12 text-center">
          <div className="w-32 h-32 bg-gray-100 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-6">
            <Calendar size={56} className="text-gray-400" />
          </div>
          <h3 className="text-2xl font-bold text-gray-900 dark:text-slate-100 mb-2">{t('activities.empty.title')}</h3>
          <p className="text-gray-500 dark:text-slate-400 max-w-md mx-auto mb-6">
            {hasActiveFilters
              ? t('activities.empty.withFilters')
              : t('activities.empty.withoutFilters')}
          </p>
          {!hasActiveFilters && (
            <button
              onClick={() => setShowAddModal(true)}
              className="inline-flex items-center gap-2 px-6 py-3 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors font-medium"
            >
              <Plus size={20} />
              {t('activities.addActivity')}
            </button>
          )}
        </div>
      )}

      {/* Floating Add Button (Mobile) */}
      <button
        onClick={() => setShowAddModal(true)}
        className="fixed bottom-6 right-6 lg:hidden w-14 h-14 bg-gray-900 text-white rounded-full shadow-2xl flex items-center justify-center z-40 hover:scale-110 transition-all"
      >
        <Plus size={24} />
      </button>

      {/* Add Activity Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto animate-fade-in">
            {/* Modal Header */}
            <div className="border-b border-gray-200 dark:border-slate-700 px-6 py-5 rounded-t-2xl">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-slate-100">{t('activities.newActivity')}</h3>
                  <p className="text-gray-500 dark:text-slate-400 text-sm mt-1">{t('activities.addActivityDesc') || 'Enregistrez une nouvelle activité'}</p>
                </div>
                <button 
                  onClick={resetForm} 
                  className="p-2 hover:bg-white dark:bg-slate-800/20 rounded-lg transition-colors"
                >
                  <X size={20} className="text-white" />
                </button>
              </div>
            </div>
            
            {/* Modal Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-5">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {t('activities.labels.activityType')} <span className="text-red-500">*</span>
                </label>
                <select
                  value={newActivity.type}
                  onChange={(e) => setNewActivity((prev) => ({ ...prev, type: e.target.value }))}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-gray-400 focus:border-transparent"
                  required
                >
                  {activityTypes.map((type) => (
                    <option key={type.value} value={type.value}>{type.label}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {t('activities.labels.description')} <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={newActivity.description}
                  onChange={(e) => setNewActivity((prev) => ({ ...prev, description: e.target.value }))}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-gray-400 focus:border-transparent resize-none"
                  rows={3}
                  required
                  placeholder={t('activities.placeholders.description') || 'Décrivez l\'activité...'}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    {t('activities.labels.date')} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={newActivity.date}
                    onChange={(e) => setNewActivity((prev) => ({ ...prev, date: e.target.value }))}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-gray-400 focus:border-transparent"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    {t('activities.labels.participants')}
                  </label>
                  <input
                    type="number"
                    value={newActivity.participants}
                    onChange={(e) => setNewActivity((prev) => ({ ...prev, participants: e.target.value }))}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-gray-400 focus:border-transparent"
                    min="0"
                    placeholder="0"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {t('activities.labels.village')}
                </label>
                <select
                  value={newActivity.village}
                  onChange={(e) => setNewActivity((prev) => ({ ...prev, village: e.target.value }))}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-gray-400 focus:border-transparent"
                >
                  <option value="">{t('activities.placeholders.selectVillage')}</option>
                  {villages?.map((village) => (
                    <option key={village._id} value={village._id}>{village.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {t('activities.labels.church')}
                </label>
                <select
                  value={newActivity.church}
                  onChange={(e) => setNewActivity((prev) => ({ ...prev, church: e.target.value }))}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-gray-400 focus:border-transparent"
                >
                  <option value="">{t('activities.placeholders.selectChurch')}</option>
                  {churches?.map((church) => (
                    <option key={church._id} value={church._id}>{church.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {t('activities.labels.notes')}
                </label>
                <textarea
                  value={newActivity.notes}
                  onChange={(e) => setNewActivity((prev) => ({ ...prev, notes: e.target.value }))}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-gray-400 focus:border-transparent resize-none"
                  rows={2}
                  placeholder={t('activities.placeholders.notes') || 'Notes additionnelles...'}
                />
              </div>

              {/* Coaching iGROW specific fields */}
              {newActivity.type === 'coaching-igrow' && (
                <div className="space-y-4 p-4 bg-gray-50 dark:bg-slate-900 rounded-lg border border-gray-200 dark:border-slate-700">
                  <h4 className="font-semibold text-teal-800 flex items-center gap-2">
                    <MessageCircle size={18} />
                    {t('activities.coaching.title') || 'Détails du coaching iGROW'}
                  </h4>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t('activities.coaching.conversationWith') || 'Conversation avec'}
                    </label>
                    <select
                      value={newActivity.coachingDetails.conversationWith}
                      onChange={(e) => setNewActivity((prev) => ({
                        ...prev,
                        coachingDetails: { ...prev.coachingDetails, conversationWith: e.target.value }
                      }))}
                      className="w-full px-4 py-2.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-gray-400 focus:border-transparent"
                    >
                      <option value="">{t('common.select') || 'Sélectionner...'}</option>
                      {coachingConversationWithOptions.map((opt) => (
                        <option key={opt.value} value={opt.value}>{t(opt.labelKey) || opt.value}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t('activities.coaching.theme') || 'Thème de la conversation'}
                    </label>
                    <input
                      type="text"
                      value={newActivity.coachingDetails.conversationTheme}
                      onChange={(e) => setNewActivity((prev) => ({
                        ...prev,
                        coachingDetails: { ...prev.coachingDetails, conversationTheme: e.target.value }
                      }))}
                      className="w-full px-4 py-2.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-gray-400 focus:border-transparent"
                      placeholder={t('activities.coaching.themePlaceholder') || 'Ex: Leadership, Vision...'}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t('activities.coaching.duration') || 'Durée (minutes)'}
                    </label>
                    <input
                      type="number"
                      value={newActivity.coachingDetails.duration}
                      onChange={(e) => setNewActivity((prev) => ({
                        ...prev,
                        coachingDetails: { ...prev.coachingDetails, duration: e.target.value }
                      }))}
                      className="w-full px-4 py-2.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-gray-400 focus:border-transparent"
                      min="0"
                      placeholder="30"
                    />
                  </div>
                </div>
              )}

              <div className="flex gap-3 pt-4">
                <button 
                  type="button" 
                  onClick={resetForm} 
                  className="flex-1 px-6 py-3 bg-gray-100 dark:bg-slate-800 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors font-medium"
                >
                  {t('common.cancel')}
                </button>
                <button
                  type="submit"
                  disabled={createMutation.isLoading}
                  className="flex-1 px-6 py-3 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors font-medium disabled:opacity-50"
                >
                  {createMutation.isLoading ? (
                    <span className="flex items-center justify-center gap-2">
                      <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      {t('common.loading')}
                    </span>
                  ) : t('activities.addActivity')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

export default Activities
