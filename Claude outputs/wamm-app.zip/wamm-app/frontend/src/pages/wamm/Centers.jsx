/**
 * Centres WAMM — IFM, CEIMP, alphabétisation, santé, agriculture, radio, pivots.
 * Liste filtrable, création, fiche avec saisie des résultats DMM par période.
 */
import { useMemo, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Plus, Pencil, Trash2, MapPin } from 'lucide-react'
import { useLanguage } from '../../i18n'
import wammApi from '../../services/wammApi'
import { PageHeader, Card, Table, Badge, Button, Modal, EntityForm, Loading, ErrorBox, Empty, CountryName, Stat, useCanEdit, countryOptions } from '../../components/wamm/ui'
import { centerFields, resultFields } from '../../components/wamm/forms'
import { L, fmt, fmtDate, fmtRange, CENTER_TYPES, CENTER_STATUSES, CENTER_COLORS, RESULT_FIELDS, ACTIVITY_TYPES } from '../../components/wamm/labels'

const STATUS_COLOR = { existing: '#1f6d44', new: '#0f766e', planned: '#d98e04', paused: '#64748b', closed: '#94a3b8' }

const useRefs = () => {
  const partners = useQuery({ queryKey: ['wamm-partners'], queryFn: () => wammApi.partners.list() })
  const programmes = useQuery({ queryKey: ['wamm-programmes'], queryFn: () => wammApi.programmes.list() })
  return { partners: partners.data || [], programmes: programmes.data || [] }
}

export function CentersList() {
  const { isFrench } = useLanguage()
  const { canEdit } = useCanEdit()
  const qc = useQueryClient()
  const navigate = useNavigate()
  const refs = useRefs()
  const [creating, setCreating] = useState(false)
  const [f, setF] = useState({ type: '', status: '', countryCode: '', q: '' })
  const { data = [], isLoading, isError, error } = useQuery({ queryKey: ['wamm-centers'], queryFn: () => wammApi.centers.list() })

  const rows = useMemo(() => data.filter((c) =>
    (!f.type || c.type === f.type) && (!f.status || c.status === f.status) && (!f.countryCode || c.countryCode === f.countryCode)
    && (!f.q || `${c.name} ${c.city} ${c.zone}`.toLowerCase().includes(f.q.toLowerCase()))), [data, f])

  const byType = data.reduce((acc, c) => { acc[c.type] = (acc[c.type] || 0) + 1; return acc }, {})
  const countries = [...new Set(data.map((c) => c.countryCode))]

  return (
    <div>
      <PageHeader
        eyebrow="WAMM"
        title={isFrench ? 'Centres et instituts' : 'Centres and institutes'}
        subtitle={isFrench ? 'Instituts de formation missionnaire (IFM) pour les leaders de mission, centres d’équipement intégrés (CEIMP) pour les leaders autochtones, centres pivots et projets de compassion. Objectif 2030 : 30 IFM et 300 CEIMP.' : 'Missionary training institutes, integrated equipping centres, hub centres and compassion projects.'}
        actions={canEdit && <Button onClick={() => setCreating(true)}><Plus size={16} />{isFrench ? 'Nouveau centre' : 'New centre'}</Button>}
      />
      <div className="mb-5 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="IFM" value={byType.ifm || 0} tone="green" />
        <Stat label="CEIMP" value={byType.ceimp || 0} tone="ochre" />
        <Stat label={isFrench ? 'Centres pivots' : 'Hubs'} value={byType.hub || 0} />
        <Stat label={isFrench ? 'Sans coordonnées' : 'Without coordinates'} value={data.filter((c) => !c.location?.coordinates?.length).length} hint={isFrench ? 'à géolocaliser' : 'to geolocate'} />
      </div>
      <div className="mb-4 flex flex-wrap gap-2">
        <input value={f.q} onChange={(e) => setF({ ...f, q: e.target.value })} placeholder={isFrench ? 'Rechercher…' : 'Search…'} className="w-56 rounded-lg border border-slate-300 px-3 py-2 text-sm dark:bg-slate-800" />
        <select value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })} className="rounded-lg border border-slate-300 px-3 py-2 text-sm dark:bg-slate-800">
          <option value="">{isFrench ? 'Tous les types' : 'All types'}</option>
          {Object.keys(CENTER_TYPES).map((k) => <option key={k} value={k}>{L(CENTER_TYPES, k, isFrench)}</option>)}
        </select>
        <select value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })} className="rounded-lg border border-slate-300 px-3 py-2 text-sm dark:bg-slate-800">
          <option value="">{isFrench ? 'Tous les statuts' : 'All statuses'}</option>
          {Object.keys(CENTER_STATUSES).map((k) => <option key={k} value={k}>{L(CENTER_STATUSES, k, isFrench)}</option>)}
        </select>
        <select value={f.countryCode} onChange={(e) => setF({ ...f, countryCode: e.target.value })} className="rounded-lg border border-slate-300 px-3 py-2 text-sm dark:bg-slate-800">
          <option value="">{isFrench ? 'Tous les pays' : 'All countries'}</option>
          {countryOptions(isFrench).filter((o) => countries.includes(o.value)).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
      </div>
      {isLoading ? <Loading /> : isError ? <ErrorBox error={error} label={isFrench ? 'Erreur de chargement.' : 'Loading error.'} /> : (
        <Card bodyClass="p-0">
          <Table
            rows={rows}
            onRowClick={(r) => navigate(`/centres/${r._id}`)}
            empty={isFrench ? 'Aucun centre.' : 'No centre.'}
            columns={[
              { key: 'name', label: isFrench ? 'Centre' : 'Centre', render: (r) => <span className="flex items-center gap-2"><span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: CENTER_COLORS[r.type] }} /><strong className="text-slate-900 dark:text-slate-100">{r.name}</strong>{!r.location?.coordinates?.length && <MapPin size={12} className="text-amber-500" title={isFrench ? 'à géolocaliser' : 'to geolocate'} />}</span> },
              { key: 'type', label: 'Type', render: (r) => L(CENTER_TYPES, r.type, isFrench) },
              { key: 'country', label: isFrench ? 'Pays' : 'Country', render: (r) => <CountryName code={r.countryCode} isFrench={isFrench} /> },
              { key: 'zone', label: 'Zone', render: (r) => r.zone || r.city || '—' },
              { key: 'partner', label: isFrench ? 'Partenaire' : 'Partner', render: (r) => r.partner?.acronym || r.partner?.name || '—' },
              { key: 'status', label: isFrench ? 'Statut' : 'Status', render: (r) => <Badge color={STATUS_COLOR[r.status]}>{L(CENTER_STATUSES, r.status, isFrench)}</Badge> },
              { key: 'churches', label: isFrench ? 'Églises' : 'Churches', right: true, render: (r) => fmt(r.totals?.churchesPlanted || 0, isFrench) },
            ]}
          />
        </Card>
      )}
      <Modal open={creating} title={isFrench ? 'Nouveau centre' : 'New centre'} onClose={() => setCreating(false)} wide>
        <EntityForm
          isFrench={isFrench}
          fields={centerFields(isFrench, refs)}
          initial={{ type: 'ceimp', status: 'planned' }}
          onCancel={() => setCreating(false)}
          onSubmit={async (body) => {
            const c = await wammApi.centers.create(body)
            await qc.invalidateQueries({ queryKey: ['wamm-centers'] })
            setCreating(false)
            navigate(`/centres/${c._id}`)
          }}
        />
      </Modal>
    </div>
  )
}

export function CenterDetail() {
  const { id } = useParams()
  const { isFrench } = useLanguage()
  const { canEdit, isAdmin } = useCanEdit()
  const qc = useQueryClient()
  const navigate = useNavigate()
  const refs = useRefs()
  const [editing, setEditing] = useState(false)
  const [resultEdit, setResultEdit] = useState(null) // {} = nouveau, objet = édition
  const { data: c, isLoading, isError, error } = useQuery({ queryKey: ['wamm-center', id], queryFn: () => wammApi.centers.get(id) })
  const refresh = () => Promise.all([qc.invalidateQueries({ queryKey: ['wamm-center', id] }), qc.invalidateQueries({ queryKey: ['wamm-centers'] }), qc.invalidateQueries({ queryKey: ['wamm-map'] }), qc.invalidateQueries({ queryKey: ['wamm-overview'] })])

  if (isLoading) return <Loading />
  if (isError) return <ErrorBox error={error} label={isFrench ? 'Centre introuvable.' : 'Centre not found.'} />

  const totals = c.totals || {}
  return (
    <div>
      <Link to="/centres" className="text-sm font-semibold text-primary-700 hover:underline">← {isFrench ? 'Centres' : 'Centres'}</Link>
      <PageHeader
        eyebrow={L(CENTER_TYPES, c.type, isFrench)}
        title={c.name}
        subtitle={c.description}
        actions={<>
          {c.location?.coordinates?.length === 2 && <Link to={`/carte?centre=${c._id}`} className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 dark:text-slate-200"><MapPin size={14} />{isFrench ? 'Voir sur la carte' : 'Show on map'}</Link>}
          {canEdit && <Button variant="ghost" onClick={() => setEditing(true)}><Pencil size={14} />{isFrench ? 'Modifier' : 'Edit'}</Button>}
          {isAdmin && <Button variant="danger" onClick={async () => {
            if (!window.confirm(isFrench ? 'Supprimer ce centre et ses résultats ?' : 'Delete this centre?')) return
            await wammApi.centers.remove(id); await qc.invalidateQueries({ queryKey: ['wamm-centers'] }); navigate('/centres')
          }}><Trash2 size={14} />{isFrench ? 'Supprimer' : 'Delete'}</Button>}
        </>}
      />
      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-7">
        {Object.keys(RESULT_FIELDS).map((k) => <Stat key={k} label={L(RESULT_FIELDS, k, isFrench)} value={fmt(totals[k] || 0, isFrench)} tone={k === 'churchesPlanted' ? 'green' : 'slate'} />)}
      </div>
      <div className="grid gap-6 lg:grid-cols-3">
        <Card title={isFrench ? 'Fiche' : 'Profile'}>
          <dl className="space-y-2 text-sm">
            <div><dt className="text-xs text-slate-500">{isFrench ? 'Statut' : 'Status'}</dt><dd><Badge color={STATUS_COLOR[c.status]}>{L(CENTER_STATUSES, c.status, isFrench)}</Badge></dd></div>
            <div><dt className="text-xs text-slate-500">{isFrench ? 'Pays' : 'Country'}</dt><dd><CountryName code={c.countryCode} isFrench={isFrench} link /></dd></div>
            {c.city && <div><dt className="text-xs text-slate-500">{isFrench ? 'Localité' : 'Place'}</dt><dd>{c.city}</dd></div>}
            {c.zone && <div><dt className="text-xs text-slate-500">Zone</dt><dd>{c.zone}</dd></div>}
            {c.partner && <div><dt className="text-xs text-slate-500">{isFrench ? 'Partenaire' : 'Partner'}</dt><dd><Link className="text-primary-700 hover:underline" to={`/partenaires/${c.partner._id}`}>{c.partner.name}</Link></dd></div>}
            {c.programme && <div><dt className="text-xs text-slate-500">{isFrench ? 'Programme' : 'Programme'}</dt><dd><Link className="text-primary-700 hover:underline" to={`/programmes/${c.programme._id}`}>{c.programme.name}</Link></dd></div>}
            {c.openingYear && <div><dt className="text-xs text-slate-500">{isFrench ? 'Ouverture' : 'Opening'}</dt><dd>{c.openingYear}</dd></div>}
            {c.peoplesServed?.length > 0 && <div><dt className="text-xs text-slate-500">{isFrench ? 'Peuples servis' : 'Peoples served'}</dt><dd>{c.peoplesServed.join(', ')}</dd></div>}
            <div><dt className="text-xs text-slate-500">{isFrench ? 'Position' : 'Position'}</dt><dd>{c.location?.coordinates?.length === 2 ? `${c.location.coordinates[1].toFixed(3)}, ${c.location.coordinates[0].toFixed(3)}${c.locationApprox ? (isFrench ? ' (indicative)' : ' (indicative)') : ''}` : <span className="text-amber-600">{isFrench ? 'À géolocaliser' : 'To geolocate'}</span>}</dd></div>
          </dl>
        </Card>
        <Card className="lg:col-span-2" title={isFrench ? 'Résultats par période' : 'Results by period'} action={canEdit && <Button variant="ghost" onClick={() => setResultEdit({})}><Plus size={14} />{isFrench ? 'Saisir des résultats' : 'Add results'}</Button>} bodyClass="p-0">
          <Table
            rows={[...(c.results || [])].sort((a, b) => new Date(b.from || 0) - new Date(a.from || 0))}
            onRowClick={canEdit ? (r) => setResultEdit(r) : undefined}
            empty={isFrench ? 'Aucun résultat saisi.' : 'No results yet.'}
            columns={[
              { key: 'periodLabel', label: isFrench ? 'Période' : 'Period', render: (r) => <span><strong>{r.periodLabel}</strong><span className="block text-[11px] text-slate-400">{r.from ? fmtRange(r.from, r.to, isFrench) : ''}</span></span> },
              ...['personsOfPeace', 'discoveryGroups', 'churchesPlanted', 'baptisms', 'newBelievers', 'leadersTrained'].map((k) => ({ key: k, right: true, label: L(RESULT_FIELDS, k, isFrench), render: (r) => fmt(r[k] || 0, isFrench) })),
            ]}
          />
        </Card>
        <Card className="lg:col-span-3" title={isFrench ? 'Activités liées' : 'Related activities'} bodyClass="p-0">
          {(c.activities || []).length === 0 ? <div className="p-5"><Empty>{isFrench ? 'Aucune activité liée à ce centre.' : 'No related activity.'}</Empty></div> : (
            <ul className="divide-y divide-slate-100 dark:divide-slate-700">
              {c.activities.map((a) => <li key={a._id} className="px-5 py-3 text-sm"><strong>{a.title || a.description}</strong><span className="block text-xs text-slate-500">{fmtDate(a.date, isFrench)} · {L(ACTIVITY_TYPES, a.type, isFrench)}</span></li>)}
            </ul>
          )}
        </Card>
      </div>

      <Modal open={editing} title={isFrench ? 'Modifier le centre' : 'Edit centre'} onClose={() => setEditing(false)} wide>
        <EntityForm isFrench={isFrench} fields={centerFields(isFrench, refs)} initial={c} onCancel={() => setEditing(false)}
          onSubmit={async (body) => { await wammApi.centers.update(id, body); await refresh(); setEditing(false) }} />
      </Modal>
      <Modal open={!!resultEdit} title={resultEdit?._id ? (isFrench ? 'Modifier les résultats' : 'Edit results') : (isFrench ? 'Saisir des résultats' : 'Add results')} onClose={() => setResultEdit(null)} wide>
        {resultEdit && (
          <>
            <EntityForm isFrench={isFrench} fields={resultFields(isFrench)} initial={resultEdit} onCancel={() => setResultEdit(null)}
              onSubmit={async (body) => {
                if (resultEdit._id) await wammApi.centers.updateResult(id, resultEdit._id, body)
                else await wammApi.centers.addResult(id, body)
                await refresh(); setResultEdit(null)
              }} />
            {resultEdit._id && (
              <button type="button" className="mt-3 text-sm font-semibold text-red-600 hover:underline" onClick={async () => {
                if (!window.confirm(isFrench ? 'Supprimer cette période ?' : 'Delete this period?')) return
                await wammApi.centers.removeResult(id, resultEdit._id); await refresh(); setResultEdit(null)
              }}>{isFrench ? 'Supprimer cette période' : 'Delete this period'}</button>
            )}
          </>
        )}
      </Modal>
    </div>
  )
}
