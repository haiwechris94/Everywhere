/**
 * Carte WAMM — toute l'Afrique, interactive.
 *
 * Couches : pays (présence WAMM / sous-régions / peuples prioritaires),
 * découpages administratifs (admin 1), fronts WAMM, ceinture de sécurité du
 * Sahel, Grande Muraille Verte, centres (IFM, CEIMP, pivots…), peuples
 * prioritaires et adoptions, axes d'envoi.
 * Clic sur un pays, un centre ou un peuple → fiche dans le panneau latéral.
 * URL : /carte?pays=CI  ·  /carte?front=FRONT-GTB
 */
import { Fragment, memo, useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { MapContainer, TileLayer, GeoJSON, Marker, Polyline, Tooltip, useMap, useMapEvents, ZoomControl } from 'react-leaflet'
import L from 'leaflet'
import { Layers, Search, X, MapPin, ChevronLeft, ChevronRight, Crosshair } from 'lucide-react'
import { useLanguage } from '../../i18n'
import wammApi from '../../services/wammApi'
import { AFRICA_COUNTRIES, WAMM_REGIONS, WAMM_STATUS_LABELS, WAMM_COUNTRY_STATUS, REGION_BY_ID, getCountry } from '../../config/wammGeography'
import { SAHEL_SECURITY_BELT, GREAT_GREEN_WALL, AFRICA_BOUNDS, AFRICA_CENTER } from '../../config/wammOverlays'
import {
  L as lbl, fmt, CENTER_TYPES, CENTER_SHORT, CENTER_COLORS, CENTER_STATUSES, REACH_STATUSES, REACH_COLORS,
  PEOPLE_STAGES, AXIS_KINDS, RESULT_FIELDS,
} from '../../components/wamm/labels'

const TILES = {
  light: { url: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', attr: '&copy; OpenStreetMap, &copy; CARTO' },
  relief: { url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}', attr: 'Tiles &copy; Esri' },
  satellite: { url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', attr: 'Tiles &copy; Esri' },
}

const SUBREGION_COLOR = Object.fromEntries(WAMM_REGIONS.filter((r) => r.kind === 'subregion').map((r) => [r.id, r.color]))
const FRONTS = WAMM_REGIONS.filter((r) => r.kind === 'front' || r.kind === 'belt')
const PEOPLE_SCALE = ['#f3efe6', '#f2d6a2', '#e9ae5d', '#c8792b', '#874a1d']

const useGeo = (url) => useQuery({
  queryKey: ['geo', url],
  queryFn: async () => { const r = await fetch(url); if (!r.ok) throw new Error(url); return r.json() },
  staleTime: Infinity,
})

const bboxOf = (feature) => {
  let s = 90; let w = 180; let n = -90; let e = -180
  const walk = (c) => { if (typeof c[0] === 'number') { w = Math.min(w, c[0]); e = Math.max(e, c[0]); s = Math.min(s, c[1]); n = Math.max(n, c[1]) } else c.forEach(walk) }
  walk(feature.geometry.coordinates)
  return [[s, w], [n, e]]
}

// ── Icônes ───────────────────────────────────────────────────────────────────
const iconCache = {}
const centerIcon = (type, status, selected) => {
  const key = `${type}|${status}|${selected}`
  if (iconCache[key]) return iconCache[key]
  const color = CENTER_COLORS[type] || '#334155'
  const planned = status === 'planned' || status === 'paused'
  const size = type === 'ifm' || type === 'hub' || type === 'office' ? 24 : 20
  const letter = { ifm: 'I', ceimp: 'C', literacy: 'A', health: '+', agricultural: 'G', radio: 'R', hub: 'P', office: 'W' }[type] || '•'
  const radius = type === 'ceimp' ? '50%' : '6px'
  iconCache[key] = L.divIcon({
    className: '',
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    html: `<div style="width:${size}px;height:${size}px;border-radius:${radius};background:${planned ? '#fff' : color};color:${planned ? color : '#fff'};border:2px ${planned ? 'dashed' : 'solid'} ${selected ? '#111827' : (planned ? color : '#fff')};box-shadow:0 1px 4px rgba(0,0,0,.35);display:flex;align-items:center;justify-content:center;font:700 ${size > 20 ? 12 : 11}px/1 Inter,sans-serif">${letter}</div>`,
  })
  return iconCache[key]
}

const peopleIcon = (p, selected) => {
  const color = REACH_COLORS[p.reachStatus] || REACH_COLORS.unknown
  const size = Math.round(12 + Math.min(14, Math.log10(Math.max(1000, p.population || 1000)) * 2.2 - 6))
  const badge = p.adoptionCount > 0
    ? `<span style="position:absolute;top:-9px;right:-12px;min-width:16px;height:16px;padding:0 3px;border-radius:9px;background:#1f6d44;color:#fff;font:700 10px/16px Inter,sans-serif;text-align:center;box-shadow:0 0 0 2px #fff">${p.adoptionCount}</span>`
    : ''
  return L.divIcon({
    className: '',
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    html: `<div style="position:relative;width:${size}px;height:${size}px"><div style="width:100%;height:100%;transform:rotate(45deg);background:${color};border:2px solid ${selected ? '#111827' : '#fff'};box-shadow:0 1px 4px rgba(0,0,0,.35)"></div>${badge}</div>`,
  })
}

const arrowIcon = (angle, color) => L.divIcon({
  className: '',
  iconSize: [14, 14],
  iconAnchor: [7, 7],
  html: `<div style="transform:rotate(${angle}deg);width:14px;height:14px"><svg viewBox="0 0 14 14" width="14" height="14"><path d="M1 2 L13 7 L1 12 Z" fill="${color}" stroke="#fff" stroke-width="1"/></svg></div>`,
})

// Courbe de Bézier quadratique entre deux points [lat, lng]
const curve = (a, b, bend = 0.18) => {
  const [la1, lo1] = a; const [la2, lo2] = b
  const mx = (lo1 + lo2) / 2; const my = (la1 + la2) / 2
  const dx = lo2 - lo1; const dy = la2 - la1
  const cx = mx - dy * bend; const cy = my + dx * bend
  const pts = []
  for (let i = 0; i <= 24; i++) {
    const t = i / 24
    pts.push([(1 - t) ** 2 * la1 + 2 * (1 - t) * t * cy + t ** 2 * la2, (1 - t) ** 2 * lo1 + 2 * (1 - t) * t * cx + t ** 2 * lo2])
  }
  return pts
}
const angleOf = (p1, p2) => (Math.atan2(-(p2[0] - p1[0]), p2[1] - p1[1]) * 180) / Math.PI

// ── Composants carte ─────────────────────────────────────────────────────────
const FitAfrica = () => {
  const map = useMap()
  useEffect(() => {
    const wide = map.getSize().x >= 900
    map.fitBounds([[-35, -18], [37.5, 52]], wide ? { paddingTopLeft: [330, 10], paddingBottomRight: [400, 10] } : { padding: [8, 8] })
  }, [map])
  return null
}

const FlyTo = ({ target }) => {
  const map = useMap()
  useEffect(() => {
    if (!target) return
    const wide = map.getSize().x >= 900
    const pad = wide ? { paddingTopLeft: [340, 30], paddingBottomRight: [410, 30] } : { padding: [20, 20] }
    if (target.bounds) map.flyToBounds(target.bounds, { ...pad, duration: 0.8, maxZoom: target.maxZoom || 7 })
    else if (target.center) map.flyTo(target.center, target.zoom || Math.max(map.getZoom(), 7), { duration: 0.8 })
  }, [target, map])
  return null
}

const ZoomWatcher = ({ onZoom }) => {
  useMapEvents({ zoomend: (e) => onZoom(e.target.getZoom()) })
  return null
}

const CenterMarker = memo(({ c, selected, onSelect, isFrench }) => (
  <Marker
    position={[c.location.coordinates[1], c.location.coordinates[0]]}
    icon={centerIcon(c.type, c.status, selected)}
    eventHandlers={{ click: () => onSelect({ kind: 'center', id: c._id }) }}
    zIndexOffset={c.type === 'ifm' || c.type === 'hub' ? 600 : 400}
  >
    <Tooltip direction="top" offset={[0, -10]}>
      <strong>{c.name}</strong><br />{lbl(CENTER_TYPES, c.type, isFrench)} · {lbl(CENTER_STATUSES, c.status, isFrench)}
    </Tooltip>
  </Marker>
))

const PeopleMarker = memo(({ p, selected, onSelect, isFrench }) => (
  <Marker
    position={[p.location.coordinates[1], p.location.coordinates[0]]}
    icon={peopleIcon(p, selected)}
    eventHandlers={{ click: () => onSelect({ kind: 'people', id: p._id }) }}
    zIndexOffset={300}
  >
    <Tooltip direction="top" offset={[0, -10]}>
      <strong>{p.name}</strong><br />{lbl(REACH_STATUSES, p.reachStatus, isFrench)}
      {p.adoptionCount > 0 ? <><br />{p.adoptionCount} {isFrench ? 'adoptant(s)' : 'adopter(s)'}</> : null}
    </Tooltip>
  </Marker>
))

// ── Page ─────────────────────────────────────────────────────────────────────
export default function WammMap() {
  const { isFrench } = useLanguage()
  const [params, setParams] = useSearchParams()
  const { data, isLoading, isError } = useQuery({ queryKey: ['wamm-map'], queryFn: wammApi.map })
  const countriesGeo = useGeo('/data/africa_countries.geojson')
  const admin1Geo = useGeo('/data/africa_admin1.geojson')

  const [tiles, setTiles] = useState('light')
  const [colorMode, setColorMode] = useState('presence')
  const [layers, setLayers] = useState({ admin1: 'auto', fronts: true, belt: true, ggw: false, centers: true, peoples: true, axes: true })
  const [centerTypes, setCenterTypes] = useState(() => Object.keys(CENTER_TYPES))
  const [showPlanned, setShowPlanned] = useState(true)
  const [zoom, setZoom] = useState(3)
  const [target, setTarget] = useState(null)
  const [panelOpen, setPanelOpen] = useState(true)
  const [controlsOpen, setControlsOpen] = useState(typeof window === 'undefined' ? true : window.innerWidth >= 768)
  const [search, setSearch] = useState('')
  const selected = useMemo(() => {
    const pays = params.get('pays'); const centre = params.get('centre'); const peuple = params.get('peuple')
    if (centre) return { kind: 'center', id: centre }
    if (peuple) return { kind: 'people', id: peuple }
    if (pays) return { kind: 'country', id: pays.toUpperCase() }
    return null
  }, [params])

  const centers = data?.centers || []
  const peoples = data?.focusPeoples || []
  const axes = data?.axes || []
  const partners = data?.partners || []
  const countryStatus = data?.countryStatus || WAMM_COUNTRY_STATUS

  const select = useCallback((sel) => {
    const next = new URLSearchParams()
    if (params.get('front')) next.set('front', params.get('front'))
    if (sel?.kind === 'country') next.set('pays', sel.id)
    if (sel?.kind === 'center') next.set('centre', sel.id)
    if (sel?.kind === 'people') next.set('peuple', sel.id)
    setParams(next, { replace: true })
    setPanelOpen(true)
  }, [params, setParams])

  // Statistiques par pays (pour la choroplèthe et la fiche pays)
  const statsByCountry = useMemo(() => {
    const m = {}
    const row = (cc) => (m[cc] = m[cc] || { centers: 0, ifm: 0, ceimp: 0, peoples: 0, adoptions: 0, partners: 0, churches: 0 })
    centers.forEach((c) => { const r = row(c.countryCode); r.centers += 1; if (c.type === 'ifm') r.ifm += 1; if (c.type === 'ceimp') r.ceimp += 1; r.churches += c.totals?.churchesPlanted || 0 })
    peoples.forEach((p) => { const r = row(p.countryCode); r.peoples += 1; r.adoptions += p.adoptionCount || 0 })
    partners.forEach((p) => (p.countryCodes || []).forEach((cc) => { row(cc).partners += 1 }))
    return m
  }, [centers, peoples, partners])

  const maxPeoples = useMemo(() => Math.max(1, ...Object.values(statsByCountry).map((s) => s.peoples)), [statsByCountry])

  // Ouvrir sur un pays ou un front passé dans l'URL
  const featureByIso2 = useMemo(() => {
    const m = {}
    ;(countriesGeo.data?.features || []).forEach((f) => { if (f.properties.iso2) m[f.properties.iso2] = f })
    return m
  }, [countriesGeo.data])

  const zoomToCountries = useCallback((codes) => {
    const feats = codes.map((c) => featureByIso2[c]).filter(Boolean)
    if (!feats.length) return
    const b = feats.map(bboxOf).reduce((acc, x) => [[Math.min(acc[0][0], x[0][0]), Math.min(acc[0][1], x[0][1])], [Math.max(acc[1][0], x[1][0]), Math.max(acc[1][1], x[1][1])]])
    setTarget({ bounds: b, maxZoom: codes.length === 1 ? 7 : 6, t: Date.now() })
  }, [featureByIso2])

  const initialised = useRef(false)
  useEffect(() => {
    if (initialised.current || !countriesGeo.data) return
    initialised.current = true
    const front = params.get('front')
    if (front && REGION_BY_ID[front]) zoomToCountries(REGION_BY_ID[front].countries)
    else if (selected?.kind === 'country') zoomToCountries([selected.id])
  }, [countriesGeo.data, params, selected, zoomToCountries])

  useEffect(() => {
    if (!selected || selected.kind === 'country') return
    const item = selected.kind === 'center' ? centers.find((c) => c._id === selected.id) : peoples.find((p) => p._id === selected.id)
    if (item?.location?.coordinates?.length === 2) setTarget({ center: [item.location.coordinates[1], item.location.coordinates[0]], zoom: 8, t: Date.now() })
  }, [selected, centers, peoples])

  const activeFront = params.get('front')
  const setFront = (id) => {
    const next = new URLSearchParams(params)
    if (id) next.set('front', id); else next.delete('front')
    setParams(next, { replace: true })
    if (id && REGION_BY_ID[id]) zoomToCountries(REGION_BY_ID[id].countries)
    else setTarget({ bounds: AFRICA_BOUNDS, maxZoom: 4, t: Date.now() })
  }

  // Style des pays
  const frontCountries = activeFront && REGION_BY_ID[activeFront] ? new Set(REGION_BY_ID[activeFront].countries) : null
  const countryStyle = useCallback((feature) => {
    const iso2 = feature.properties.iso2
    const c = getCountry(iso2)
    let fill = '#ece8df'
    if (colorMode === 'presence') fill = (WAMM_STATUS_LABELS[countryStatus[iso2] || 'none'] || WAMM_STATUS_LABELS.none).color
    if (colorMode === 'subregion' && c) fill = SUBREGION_COLOR[c.subregion] || fill
    if (colorMode === 'peoples') {
      const n = statsByCountry[iso2]?.peoples || 0
      fill = n === 0 ? PEOPLE_SCALE[0] : PEOPLE_SCALE[Math.min(4, 1 + Math.floor((n / (maxPeoples + 1)) * 4))]
    }
    const isSel = selected?.kind === 'country' && selected.id === iso2
    const dim = frontCountries && !frontCountries.has(iso2)
    return {
      color: isSel ? '#111827' : '#ffffff',
      weight: isSel ? 2.5 : 0.8,
      fillColor: fill,
      fillOpacity: dim ? 0.18 : (colorMode === 'subregion' ? 0.45 : 0.6),
    }
  }, [colorMode, countryStatus, statsByCountry, maxPeoples, selected, frontCountries])

  const onEachCountry = useCallback((feature, layer) => {
    const c = getCountry(feature.properties.iso2) || {}
    layer.bindTooltip(isFrench ? (c.name || feature.properties.nameFr) : (c.nameEn || feature.properties.name), { sticky: true, className: 'wamm-tip' })
    layer.on({
      click: () => feature.properties.iso2 && select({ kind: 'country', id: feature.properties.iso2 }),
      mouseover: (e) => e.target.setStyle({ weight: 2, color: '#334155' }),
      mouseout: (e) => e.target.setStyle(countryStyle(feature)),
    })
  }, [isFrench, select, countryStyle])

  const showAdmin1 = layers.admin1 === true || (layers.admin1 === 'auto' && zoom >= 5)

  const visibleCenters = centers.filter((c) => c.location?.coordinates?.length === 2 && centerTypes.includes(c.type) && (showPlanned || !['planned', 'paused'].includes(c.status)))
  const visiblePeoples = peoples.filter((p) => p.location?.coordinates?.length === 2)
  const notLocated = [
    ...centers.filter((c) => !c.location?.coordinates?.length).map((c) => ({ kind: 'center', ...c })),
    ...peoples.filter((p) => !p.location?.coordinates?.length).map((p) => ({ kind: 'people', ...p })),
  ]

  // Recherche : pays, centres, peuples
  const results = useMemo(() => {
    const q = search.trim().toLowerCase()
    if (q.length < 2) return []
    const out = []
    AFRICA_COUNTRIES.forEach((c) => { if (c.name.toLowerCase().includes(q) || c.nameEn.toLowerCase().includes(q)) out.push({ kind: 'country', id: c.code, label: isFrench ? c.name : c.nameEn, sub: isFrench ? 'Pays' : 'Country' }) })
    centers.forEach((c) => { if (c.name.toLowerCase().includes(q) || (c.city || '').toLowerCase().includes(q)) out.push({ kind: 'center', id: c._id, label: c.name, sub: lbl(CENTER_TYPES, c.type, isFrench) }) })
    peoples.forEach((p) => { if (p.name.toLowerCase().includes(q) || (p.alternateNames || []).some((n) => n.toLowerCase().includes(q))) out.push({ kind: 'people', id: p._id, label: p.name, sub: isFrench ? 'Peuple' : 'People' }) })
    return out.slice(0, 8)
  }, [search, centers, peoples, isFrench])

  const pickResult = (r) => {
    setSearch('')
    select(r)
    if (r.kind === 'country') zoomToCountries([r.id])
  }

  const toggle = (k) => setLayers((s) => ({ ...s, [k]: s[k] === 'auto' ? true : s[k] === true && k === 'admin1' ? false : !s[k] }))

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#dfe8ee]">
      <MapContainer
        center={AFRICA_CENTER} zoom={3} minZoom={2.5} maxZoom={12} zoomSnap={0.25} zoomDelta={0.5}
        maxBounds={[[-50, -45], [50, 75]]} zoomControl={false} worldCopyJump={false}
        className="h-full w-full" style={{ background: '#dfe8ee' }}
      >
        <ZoomControl position="bottomleft" />
        <TileLayer key={tiles} url={TILES[tiles].url} attribution={`${TILES[tiles].attr} · Natural Earth`} />
        <FitAfrica />
        <FlyTo target={target} />
        <ZoomWatcher onZoom={setZoom} />

        {countriesGeo.data && (
          <GeoJSON
            key={`countries-${colorMode}-${isFrench}-${selected?.id || ''}-${activeFront || ''}-${centers.length}-${peoples.length}`}
            data={countriesGeo.data}
            style={countryStyle}
            onEachFeature={onEachCountry}
          />
        )}

        {showAdmin1 && admin1Geo.data && (
          <GeoJSON
            key="admin1"
            data={admin1Geo.data}
            style={{ color: '#475569', weight: 0.6, opacity: 0.7, fill: true, fillOpacity: 0, dashArray: '2 3' }}
            onEachFeature={(f, layer) => layer.bindTooltip(`${f.properties.name}${f.properties.type ? ` · ${f.properties.type}` : ''}`, { sticky: true, className: 'wamm-tip' })}
          />
        )}

        {layers.fronts && countriesGeo.data && FRONTS.filter((r) => r.kind === 'front' && (!activeFront || activeFront === r.id)).map((r) => (
          <GeoJSON
            key={`front-${r.id}`}
            data={{ type: 'FeatureCollection', features: r.countries.map((c) => featureByIso2[c]).filter(Boolean) }}
            style={{ color: r.color, weight: 2.4, dashArray: '6 4', fill: false }}
            interactive={false}
          />
        ))}

        {layers.ggw && (
          <Polyline positions={GREAT_GREEN_WALL} pathOptions={{ color: '#3f8f3a', weight: 7, opacity: 0.45, lineCap: 'round' }}>
            <Tooltip sticky>{isFrench ? 'Grande Muraille Verte (tracé indicatif)' : 'Great Green Wall (indicative)'}</Tooltip>
          </Polyline>
        )}
        {layers.belt && (
          <Polyline positions={SAHEL_SECURITY_BELT} pathOptions={{ color: '#d62828', weight: 3.5, opacity: 0.9 }}>
            <Tooltip sticky>{isFrench ? 'Ceinture de sécurité du Sahel (tracé indicatif)' : 'Sahel Security Belt (indicative)'}</Tooltip>
          </Polyline>
        )}

        {layers.axes && axes.map((a) => {
          if (!a.from?.coordinates || !a.to?.coordinates) return null
          const p1 = [a.from.coordinates[1], a.from.coordinates[0]]
          const p2 = [a.to.coordinates[1], a.to.coordinates[0]]
          const pts = curve(p1, p2, a.kind === 'outreach' ? 0.12 : 0.22)
          const color = a.kind === 'outreach' ? '#15803d' : '#7c3aed'
          return (
            <Fragment key={a._id}>
              <Polyline positions={pts} pathOptions={{ color, weight: 2.5, opacity: 0.85, dashArray: a.kind === 'outreach' || a.status === 'planned' ? '7 6' : null }}>
                <Tooltip sticky><strong>{a.label}</strong><br />{lbl(AXIS_KINDS, a.kind, isFrench)}{a.targetPeoples?.length ? ` · ${a.targetPeoples.join(', ')}` : ''}</Tooltip>
              </Polyline>
              <Marker position={pts[pts.length - 1]} icon={arrowIcon(angleOf(pts[pts.length - 3], pts[pts.length - 1]), color)} interactive={false} />
            </Fragment>
          )
        })}

        {layers.peoples && visiblePeoples.map((p) => (
          <PeopleMarker key={p._id} p={p} isFrench={isFrench} selected={selected?.kind === 'people' && selected.id === p._id} onSelect={select} />
        ))}
        {layers.centers && visibleCenters.map((c) => (
          <CenterMarker key={c._id} c={c} isFrench={isFrench} selected={selected?.kind === 'center' && selected.id === c._id} onSelect={select} />
        ))}
      </MapContainer>

      {/* ── Panneau de contrôle (gauche) ── */}
      <div className="pointer-events-none absolute left-3 top-3 z-[1000] flex w-[min(320px,calc(100vw-24px))] flex-col gap-2">
        <div className="pointer-events-auto relative">
          <div className="flex items-center gap-2 rounded-xl bg-white/95 px-3 py-2 shadow-lg ring-1 ring-slate-200 backdrop-blur dark:bg-slate-800/95">
            <Search size={16} className="text-slate-400" />
            <input
              value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder={isFrench ? 'Pays, centre, peuple…' : 'Country, centre, people…'}
              className="w-full bg-transparent text-sm outline-none" style={{ fontSize: 16 }}
            />
            <button type="button" onClick={() => setControlsOpen((v) => !v)} className="rounded p-1 text-slate-500 hover:bg-slate-100" title={isFrench ? 'Couches' : 'Layers'}><Layers size={16} /></button>
          </div>
          {results.length > 0 && (
            <ul className="absolute left-0 right-0 top-full mt-1 overflow-hidden rounded-xl bg-white shadow-xl ring-1 ring-slate-200 dark:bg-slate-800">
              {results.map((r) => (
                <li key={`${r.kind}-${r.id}`}>
                  <button type="button" onClick={() => pickResult(r)} className="flex w-full items-center justify-between gap-2 px-3 py-2 text-left text-sm hover:bg-primary-50 dark:hover:bg-slate-700">
                    <span className="truncate font-medium">{r.label}</span><span className="shrink-0 text-xs text-slate-400">{r.sub}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {controlsOpen && (
          <div className="pointer-events-auto max-h-[calc(100vh-10rem)] overflow-y-auto rounded-xl bg-white/95 p-3 text-sm shadow-lg ring-1 ring-slate-200 backdrop-blur dark:bg-slate-800/95">
            <p className="mb-1.5 text-[11px] font-bold uppercase tracking-wide text-slate-500">{isFrench ? 'Front / zone' : 'Front / area'}</p>
            <select value={activeFront || ''} onChange={(e) => setFront(e.target.value)} className="mb-3 w-full rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-sm dark:bg-slate-900" style={{ fontSize: 16 }}>
              <option value="">{isFrench ? 'Toute l’Afrique' : 'All of Africa'}</option>
              {WAMM_REGIONS.map((r) => <option key={r.id} value={r.id}>{isFrench ? r.name : r.nameEn}</option>)}
            </select>

            <p className="mb-1.5 text-[11px] font-bold uppercase tracking-wide text-slate-500">{isFrench ? 'Couleur des pays' : 'Country colours'}</p>
            <div className="mb-3 grid grid-cols-3 gap-1 rounded-lg bg-slate-100 p-1 dark:bg-slate-700">
              {[['presence', isFrench ? 'Présence' : 'Presence'], ['subregion', isFrench ? 'Régions' : 'Regions'], ['peoples', isFrench ? 'Peuples' : 'Peoples']].map(([k, label]) => (
                <button key={k} type="button" onClick={() => setColorMode(k)} className={`rounded-md px-2 py-1 text-xs font-semibold ${colorMode === k ? 'bg-white text-primary-700 shadow dark:bg-slate-900' : 'text-slate-600 dark:text-slate-300'}`}>{label}</button>
              ))}
            </div>

            <p className="mb-1.5 text-[11px] font-bold uppercase tracking-wide text-slate-500">{isFrench ? 'Couches' : 'Layers'}</p>
            {[
              ['centers', isFrench ? 'Centres et instituts' : 'Centres and institutes'],
              ['peoples', isFrench ? 'Peuples prioritaires et adoptions' : 'Focus peoples and adoptions'],
              ['axes', isFrench ? "Axes d'envoi" : 'Sending axes'],
              ['fronts', isFrench ? 'Fronts WAMM' : 'WAMM fronts'],
              ['belt', isFrench ? 'Ceinture de sécurité du Sahel' : 'Sahel Security Belt'],
              ['ggw', isFrench ? 'Grande Muraille Verte' : 'Great Green Wall'],
              ['admin1', isFrench ? 'Découpages administratifs' : 'Administrative units'],
            ].map(([k, label]) => (
              <label key={k} className="flex cursor-pointer items-center justify-between gap-2 py-1">
                <span className="flex items-center gap-2">
                  <input type="checkbox" checked={layers[k] === true || (layers[k] === 'auto' && showAdmin1)} onChange={() => toggle(k)} className="h-4 w-4 accent-primary-700" />
                  {label}
                </span>
                {k === 'admin1' && layers.admin1 === 'auto' && <span className="text-[10px] text-slate-400">{isFrench ? 'auto (zoom ≥ 5)' : 'auto (zoom ≥ 5)'}</span>}
              </label>
            ))}

            {layers.centers && (
              <>
                <p className="mb-1.5 mt-3 text-[11px] font-bold uppercase tracking-wide text-slate-500">{isFrench ? 'Types de centres' : 'Centre types'}</p>
                <div className="flex flex-wrap gap-1">
                  {Object.keys(CENTER_TYPES).map((t) => {
                    const on = centerTypes.includes(t)
                    return (
                      <button key={t} type="button" onClick={() => setCenterTypes(on ? centerTypes.filter((x) => x !== t) : [...centerTypes, t])}
                        className="rounded-full border px-2 py-0.5 text-[11px] font-semibold"
                        style={on ? { background: CENTER_COLORS[t], borderColor: CENTER_COLORS[t], color: '#fff' } : { borderColor: '#cbd5e1', color: '#64748b' }}>
                        {lbl(CENTER_SHORT, t, isFrench)}
                      </button>
                    )
                  })}
                </div>
                <label className="mt-2 flex items-center gap-2 text-xs"><input type="checkbox" className="accent-primary-700" checked={showPlanned} onChange={(e) => setShowPlanned(e.target.checked)} />{isFrench ? 'Afficher les centres prévus' : 'Show planned centres'}</label>
              </>
            )}

            <p className="mb-1.5 mt-3 text-[11px] font-bold uppercase tracking-wide text-slate-500">{isFrench ? 'Fond de carte' : 'Basemap'}</p>
            <div className="grid grid-cols-3 gap-1 rounded-lg bg-slate-100 p-1 dark:bg-slate-700">
              {[['light', isFrench ? 'Clair' : 'Light'], ['relief', 'Relief'], ['satellite', 'Satellite']].map(([k, label]) => (
                <button key={k} type="button" onClick={() => setTiles(k)} className={`rounded-md px-2 py-1 text-xs font-semibold ${tiles === k ? 'bg-white text-primary-700 shadow dark:bg-slate-900' : 'text-slate-600 dark:text-slate-300'}`}>{label}</button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ── Légende (bas) ── */}
      <Legend isFrench={isFrench} colorMode={colorMode} maxPeoples={maxPeoples} />

      {/* ── Panneau latéral (droite) ── */}
      <button
        type="button" onClick={() => setPanelOpen((v) => !v)}
        className="absolute right-3 top-3 z-[1001] rounded-lg bg-white p-2 shadow-lg ring-1 ring-slate-200 md:hidden"
        aria-label="Panneau"
      >
        {panelOpen ? <X size={16} /> : <MapPin size={16} />}
      </button>
      <aside className={`absolute bottom-0 right-0 top-0 z-[1000] w-full max-w-sm transform bg-white shadow-2xl ring-1 ring-slate-200 backdrop-blur transition-transform dark:bg-slate-800 md:w-96 ${panelOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <button type="button" onClick={() => setPanelOpen((v) => !v)} className="absolute -left-7 top-20 hidden h-12 w-7 items-center justify-center rounded-l-lg bg-white shadow ring-1 ring-slate-200 md:flex dark:bg-slate-800">
          {panelOpen ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
        </button>
        <div className="h-full overflow-y-auto p-5 pt-14 md:pt-5">
          {isLoading ? <p className="text-sm text-slate-500">{isFrench ? 'Chargement des données WAMM…' : 'Loading WAMM data…'}</p>
            : isError ? <p className="text-sm text-red-600">{isFrench ? 'Données WAMM indisponibles.' : 'WAMM data unavailable.'}</p>
              : (
                <Panel
                  selected={selected} isFrench={isFrench} centers={centers} peoples={peoples} partners={partners} axes={axes}
                  statsByCountry={statsByCountry} countryStatus={countryStatus} notLocated={notLocated}
                  onSelect={select} onClose={() => select(null)} onFront={setFront} activeFront={activeFront}
                  onZoomCountry={(cc) => zoomToCountries([cc])}
                />
              )}
        </div>
      </aside>
    </div>
  )
}

// ── Légende ──────────────────────────────────────────────────────────────────
const Legend = ({ isFrench, colorMode, maxPeoples }) => {
  const [open, setOpen] = useState(typeof window === 'undefined' ? true : window.innerWidth >= 768 && window.innerHeight >= 860)
  return (
    <div className="absolute bottom-3 left-14 z-[1000] max-w-[calc(100vw-5rem)] rounded-xl bg-white/95 text-xs shadow-lg ring-1 ring-slate-200 backdrop-blur dark:bg-slate-800/95 md:right-[25rem] md:max-w-xl">
      <button type="button" onClick={() => setOpen((v) => !v)} className="w-full px-3 py-1.5 text-left text-[11px] font-bold uppercase tracking-wide text-slate-500">
        {isFrench ? 'Légende' : 'Legend'} {open ? '▾' : '▸'}
      </button>
      {open && (
        <div className="grid gap-x-5 gap-y-1.5 px-3 pb-3 sm:grid-cols-2">
          <div className="space-y-1">
            {colorMode === 'presence' && Object.entries(WAMM_STATUS_LABELS).map(([k, v]) => (
              <div key={k} className="flex items-center gap-2"><span className="h-3 w-4 rounded-sm" style={{ background: v.color }} />{isFrench ? v.fr : v.en}</div>
            ))}
            {colorMode === 'subregion' && WAMM_REGIONS.filter((r) => r.kind === 'subregion').map((r) => (
              <div key={r.id} className="flex items-center gap-2"><span className="h-3 w-4 rounded-sm opacity-70" style={{ background: r.color }} />{isFrench ? r.name : r.nameEn}</div>
            ))}
            {colorMode === 'peoples' && (
              <div>
                <p className="mb-1">{isFrench ? 'Peuples prioritaires par pays' : 'Focus peoples per country'}</p>
                <div className="flex">{PEOPLE_SCALE.map((c) => <span key={c} className="h-3 w-8" style={{ background: c }} />)}</div>
                <div className="flex justify-between text-[10px] text-slate-400"><span>0</span><span>{maxPeoples}</span></div>
              </div>
            )}
            <div className="flex items-center gap-2"><span className="h-0.5 w-5 bg-[#d62828]" />{isFrench ? 'Ceinture de sécurité du Sahel' : 'Sahel Security Belt'}</div>
            <div className="flex items-center gap-2"><span className="w-5 border-t-2 border-dashed border-[#15803d]" />{isFrench ? 'Axe de rayonnement' : 'Outreach axis'}</div>
            <div className="flex items-center gap-2"><span className="h-0.5 w-5 bg-[#7c3aed]" />{isFrench ? "Axe d'envoi" : 'Sending axis'}</div>
          </div>
          <div className="space-y-1">
            {['ifm', 'ceimp', 'hub', 'office'].map((t) => (
              <div key={t} className="flex items-center gap-2">
                <span className="flex h-4 w-4 items-center justify-center text-[9px] font-bold text-white" style={{ background: CENTER_COLORS[t], borderRadius: t === 'ceimp' ? '50%' : 3 }}>{{ ifm: 'I', ceimp: 'C', hub: 'P', office: 'W' }[t]}</span>
                {lbl(CENTER_TYPES, t, isFrench)}
              </div>
            ))}
            <div className="flex items-center gap-2"><span className="h-4 w-4 rounded-full border-2 border-dashed border-slate-500 bg-white" />{isFrench ? 'Centre prévu / en prospection' : 'Planned centre'}</div>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
              {['frontier', 'unreached', 'minimally_reached', 'partially_reached'].map((k) => (
                <span key={k} className="flex items-center gap-1"><span className="h-2.5 w-2.5 rotate-45" style={{ background: REACH_COLORS[k] }} />{lbl(REACH_STATUSES, k, isFrench).split(' (')[0]}</span>
              ))}
            </div>
            <div className="flex items-center gap-2"><span className="flex h-4 min-w-4 items-center justify-center rounded-full bg-[#1f6d44] px-1 text-[9px] font-bold text-white">3</span>{isFrench ? "Nombre d'adoptants" : 'Number of adopters'}</div>
          </div>
        </div>
      )}
    </div>
  )
}

// ── Panneau de détail ────────────────────────────────────────────────────────
const Row = ({ label, children }) => (
  <div className="flex justify-between gap-3 border-b border-slate-100 py-1.5 text-sm last:border-0 dark:border-slate-700">
    <span className="text-slate-500">{label}</span><span className="text-right font-medium text-slate-800 dark:text-slate-100">{children}</span>
  </div>
)

const Panel = ({ selected, isFrench, centers, peoples, partners, axes, statsByCountry, countryStatus, notLocated, onSelect, onClose, onFront, activeFront, onZoomCountry }) => {
  if (selected?.kind === 'center') {
    const c = centers.find((x) => x._id === selected.id)
    if (!c) return <p className="text-sm text-slate-500">{isFrench ? 'Centre introuvable.' : 'Centre not found.'}</p>
    const country = getCountry(c.countryCode)
    const out = axes.filter((a) => String(a.fromCenter?._id || a.fromCenter) === String(c._id))
    return (
      <div>
        <PanelHead onClose={onClose} eyebrow={lbl(CENTER_TYPES, c.type, isFrench)} title={c.name} color={CENTER_COLORS[c.type]} />
        <Row label={isFrench ? 'Statut' : 'Status'}>{lbl(CENTER_STATUSES, c.status, isFrench)}</Row>
        <Row label={isFrench ? 'Pays' : 'Country'}><button type="button" className="hover:underline" onClick={() => onSelect({ kind: 'country', id: c.countryCode })}>{country ? (isFrench ? country.name : country.nameEn) : c.countryCode}</button></Row>
        {c.city && <Row label={isFrench ? 'Localité' : 'Place'}>{c.city}</Row>}
        {c.zone && <Row label="Zone">{c.zone}</Row>}
        {c.partner && <Row label={isFrench ? 'Partenaire' : 'Partner'}><Link className="text-primary-700 hover:underline" to={`/partenaires/${c.partner._id}`}>{c.partner.acronym || c.partner.name}</Link></Row>}
        {c.programme && <Row label={isFrench ? 'Programme' : 'Programme'}><Link className="text-primary-700 hover:underline" to={`/programmes/${c.programme._id}`}>{c.programme.name}</Link></Row>}
        {c.peoplesServed?.length > 0 && <Row label={isFrench ? 'Peuples servis' : 'Peoples served'}>{c.peoplesServed.join(', ')}</Row>}
        {c.locationApprox && <p className="mt-2 text-[11px] text-amber-700">{isFrench ? 'Position indicative (lue sur une carte WAMM ou zone du centre).' : 'Indicative position.'}</p>}
        <Totals totals={c.totals} isFrench={isFrench} />
        {out.length > 0 && (
          <div className="mt-4">
            <p className="mb-1 text-xs font-bold uppercase tracking-wide text-slate-500">{isFrench ? "Axes d'envoi" : 'Sending axes'}</p>
            <ul className="space-y-1 text-sm">{out.map((a) => <li key={a._id}>→ {a.toName}{a.targetPeoples?.length ? <span className="text-slate-400"> ({a.targetPeoples.join(', ')})</span> : null}</li>)}</ul>
          </div>
        )}
        {c.description && <p className="mt-4 text-sm text-slate-600 dark:text-slate-300">{c.description}</p>}
        <Link to={`/centres/${c._id}`} className="mt-5 inline-flex rounded-lg bg-primary-700 px-3 py-2 text-sm font-semibold text-white hover:bg-primary-800">{isFrench ? 'Ouvrir la fiche du centre' : 'Open centre page'}</Link>
      </div>
    )
  }

  if (selected?.kind === 'people') {
    const p = peoples.find((x) => x._id === selected.id)
    if (!p) return <p className="text-sm text-slate-500">{isFrench ? 'Peuple introuvable.' : 'People not found.'}</p>
    const country = getCountry(p.countryCode)
    return (
      <div>
        <PanelHead onClose={onClose} eyebrow={isFrench ? 'Peuple prioritaire' : 'Focus people'} title={p.name} color={REACH_COLORS[p.reachStatus]} />
        <Row label={isFrench ? 'Pays' : 'Country'}><button type="button" className="hover:underline" onClick={() => onSelect({ kind: 'country', id: p.countryCode })}>{country ? (isFrench ? country.name : country.nameEn) : p.countryCode}</button></Row>
        {p.otherCountryCodes?.length > 0 && <Row label={isFrench ? 'Aussi présent' : 'Also in'}>{p.otherCountryCodes.map((cc) => getCountry(cc)?.[isFrench ? 'name' : 'nameEn'] || cc).join(', ')}</Row>}
        <Row label={isFrench ? 'Statut' : 'Status'}>{lbl(REACH_STATUSES, p.reachStatus, isFrench)}</Row>
        <Row label={isFrench ? 'Étape' : 'Stage'}>{lbl(PEOPLE_STAGES, p.stage, isFrench)}</Row>
        {p.population > 0 && <Row label="Population">{fmt(p.population, isFrench)}</Row>}
        {p.lot && <Row label="Lot">{p.lot}</Row>}
        {p.religion && <Row label={isFrench ? 'Religion' : 'Religion'}>{p.religion}</Row>}
        {(p.workersNeeded > 0 || p.workersInPlace > 0) && <Row label={isFrench ? 'Ouvriers (en place / nécessaires)' : 'Workers (in place / needed)'}>{p.workersInPlace || 0} / {p.workersNeeded || 0}</Row>}
        <Row label={isFrench ? 'Adoptants' : 'Adopters'}>{p.adoptionCount || 0}</Row>
        {p.adopters?.length > 0 && <p className="mt-1 text-xs text-slate-500">{p.adopters.filter(Boolean).join(', ')}</p>}
        {p.adoptionEvent && <p className="mt-1 text-xs text-slate-500">{p.adoptionEvent}</p>}
        {p.isPastoral && <p className="mt-3 rounded-lg bg-amber-50 p-2 text-xs text-amber-800">{isFrench ? 'Peuple pastoral : la position indique une zone de présence, pas un village.' : 'Pastoral people: position shows an area, not a village.'}</p>}
        {p.notes && <p className="mt-3 text-sm text-slate-600 dark:text-slate-300">{p.notes}</p>}
        <Link to={`/adoptions/${p._id}`} className="mt-5 inline-flex rounded-lg bg-primary-700 px-3 py-2 text-sm font-semibold text-white hover:bg-primary-800">{isFrench ? 'Ouvrir la fiche du peuple' : 'Open people page'}</Link>
      </div>
    )
  }

  if (selected?.kind === 'country') {
    const c = getCountry(selected.id)
    if (!c) return null
    const s = statsByCountry[c.code] || {}
    const status = countryStatus[c.code] || 'none'
    const regions = WAMM_REGIONS.filter((r) => r.countries.includes(c.code))
    const cCenters = centers.filter((x) => x.countryCode === c.code)
    const cPeoples = peoples.filter((x) => x.countryCode === c.code || (x.otherCountryCodes || []).includes(c.code))
    const cPartners = partners.filter((x) => (x.countryCodes || []).includes(c.code))
    return (
      <div>
        <PanelHead onClose={onClose} eyebrow={isFrench ? 'Pays' : 'Country'} title={isFrench ? c.name : c.nameEn} color={WAMM_STATUS_LABELS[status].color} />
        <p className="mb-3 text-xs font-semibold" style={{ color: WAMM_STATUS_LABELS[status].color === '#E5E1D8' ? '#64748b' : WAMM_STATUS_LABELS[status].color }}>{isFrench ? WAMM_STATUS_LABELS[status].fr : WAMM_STATUS_LABELS[status].en}</p>
        <Row label={isFrench ? 'Capitale' : 'Capital'}>{c.capital || '—'}</Row>
        {c.population ? <Row label="Population">{fmt(c.population, isFrench)}</Row> : null}
        <div className="mt-2 flex flex-wrap gap-1">
          {regions.map((r) => <button key={r.id} type="button" onClick={() => onFront(r.id)} className="rounded-full px-2 py-0.5 text-[11px] font-semibold text-white" style={{ background: r.color }}>{isFrench ? r.name : r.nameEn}</button>)}
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2 text-center">
          {[[s.ifm || 0, 'IFM'], [s.ceimp || 0, 'CEIMP'], [s.peoples || 0, isFrench ? 'Peuples' : 'Peoples'], [s.adoptions || 0, isFrench ? 'Adoptions' : 'Adoptions'], [s.partners || 0, isFrench ? 'Partenaires' : 'Partners'], [s.churches || 0, isFrench ? 'Églises' : 'Churches']].map(([v, l]) => (
            <div key={l} className="rounded-lg bg-slate-50 p-2 dark:bg-slate-700"><p className="text-lg font-bold text-slate-900 dark:text-slate-100">{fmt(v, isFrench)}</p><p className="text-[10px] font-semibold text-slate-500">{l}</p></div>
          ))}
        </div>
        <button type="button" onClick={() => onZoomCountry(c.code)} className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-primary-700 hover:underline"><Crosshair size={12} />{isFrench ? 'Centrer la carte sur ce pays' : 'Zoom to country'}</button>
        <ListBlock title={isFrench ? 'Centres' : 'Centres'} items={cCenters} render={(x) => (<button type="button" onClick={() => onSelect({ kind: 'center', id: x._id })} className="text-left hover:underline"><span className="font-medium">{x.name}</span> <span className="text-slate-400">· {lbl(CENTER_SHORT, x.type, isFrench)}</span></button>)} />
        <ListBlock title={isFrench ? 'Peuples prioritaires' : 'Focus peoples'} items={cPeoples} render={(x) => (<button type="button" onClick={() => onSelect({ kind: 'people', id: x._id })} className="text-left hover:underline"><span className="font-medium">{x.name}</span> <span className="text-slate-400">· {lbl(REACH_STATUSES, x.reachStatus, isFrench).split(' (')[0]}</span></button>)} />
        <ListBlock title={isFrench ? 'Partenaires' : 'Partners'} items={cPartners} render={(x) => <Link to={`/partenaires/${x._id}`} className="hover:underline">{x.name}</Link>} />
        <Link to={`/pays/${c.code}`} className="mt-5 inline-flex rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 dark:text-slate-200">{isFrench ? 'Peuples du pays (Joshua Project)' : 'Country peoples (Joshua Project)'}</Link>
      </div>
    )
  }

  // Vue d'ensemble
  const nCenters = centers.length
  return (
    <div>
      <p className="text-xs font-bold uppercase tracking-[0.14em] text-accent-600">WAMM</p>
      <h2 className="mt-1 text-xl font-bold text-slate-900 dark:text-slate-100">{isFrench ? 'Le travail de WAMM en Afrique' : "WAMM's work across Africa"}</h2>
      <p className="mt-1 text-sm text-slate-500">{isFrench ? 'Cliquez sur un pays, un centre ou un peuple pour voir sa fiche.' : 'Click a country, a centre or a people to see its details.'}</p>
      <div className="mt-4 grid grid-cols-3 gap-2 text-center">
        {[[centers.filter((c) => c.type === 'ifm').length, 'IFM'], [centers.filter((c) => c.type === 'ceimp').length, 'CEIMP'], [peoples.length, isFrench ? 'Peuples' : 'Peoples']].map(([v, l]) => (
          <div key={l} className="rounded-lg bg-slate-50 p-2 dark:bg-slate-700"><p className="text-xl font-bold">{v}</p><p className="text-[10px] font-semibold text-slate-500">{l}</p></div>
        ))}
      </div>
      <p className="mb-2 mt-5 text-xs font-bold uppercase tracking-wide text-slate-500">{isFrench ? 'Fronts et zones' : 'Fronts and areas'}</p>
      <div className="space-y-1.5">
        {FRONTS.map((r) => (
          <button key={r.id} type="button" onClick={() => onFront(activeFront === r.id ? '' : r.id)}
            className={`flex w-full items-start gap-2 rounded-lg border p-2 text-left text-sm transition ${activeFront === r.id ? 'border-slate-800 bg-slate-50 dark:bg-slate-700' : 'border-slate-200 hover:bg-slate-50 dark:border-slate-600 dark:hover:bg-slate-700'}`}>
            <span className="mt-1 h-3 w-3 shrink-0 rounded-full" style={{ background: r.color }} />
            <span><span className="block font-semibold">{isFrench ? r.name : r.nameEn}</span><span className="block text-xs text-slate-500">{r.countries.map((cc) => getCountry(cc)?.[isFrench ? 'name' : 'nameEn']).join(', ')}</span></span>
          </button>
        ))}
      </div>
      {notLocated.length > 0 && (
        <div className="mt-5 rounded-lg bg-amber-50 p-3 dark:bg-amber-900/20">
          <p className="text-xs font-bold text-amber-800 dark:text-amber-200">{isFrench ? `${notLocated.length} élément(s) à géolocaliser` : `${notLocated.length} item(s) to geolocate`}</p>
          <p className="mb-2 text-[11px] text-amber-700">{isFrench ? 'Sans coordonnées, ils ne sont pas sur la carte. Ajoutez latitude et longitude dans leur fiche.' : 'Add coordinates on their page to show them.'}</p>
          <ul className="space-y-0.5 text-xs">
            {notLocated.map((x) => (
              <li key={x._id}>
                <Link className="text-amber-900 hover:underline dark:text-amber-100" to={x.kind === 'center' ? `/centres/${x._id}` : `/adoptions/${x._id}`}>{x.name}</Link>
                <span className="text-amber-700"> · {getCountry(x.countryCode)?.[isFrench ? 'name' : 'nameEn'] || x.countryCode}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      <p className="mt-5 text-[11px] text-slate-400">{isFrench ? `${nCenters} centres au total · frontières : Natural Earth · tracés de la ceinture et de la Grande Muraille Verte indicatifs.` : `${nCenters} centres · borders: Natural Earth · belt and Great Green Wall lines are indicative.`}</p>
    </div>
  )
}

const PanelHead = ({ eyebrow, title, color, onClose }) => (
  <div className="mb-3 flex items-start justify-between gap-3">
    <div className="min-w-0">
      <p className="text-[11px] font-bold uppercase tracking-wide" style={{ color: color && color !== '#E5E1D8' ? color : '#64748b' }}>{eyebrow}</p>
      <h2 className="text-xl font-bold leading-tight text-slate-900 dark:text-slate-100">{title}</h2>
    </div>
    <button type="button" onClick={onClose} className="rounded p-1 text-slate-400 hover:bg-slate-100" aria-label="Fermer"><X size={18} /></button>
  </div>
)

const Totals = ({ totals, isFrench }) => {
  if (!totals) return null
  const keys = Object.keys(RESULT_FIELDS).filter((k) => totals[k])
  if (!keys.length) return null
  return (
    <div className="mt-4 grid grid-cols-2 gap-2">
      {keys.map((k) => (
        <div key={k} className="rounded-lg bg-primary-50 p-2 dark:bg-slate-700"><p className="text-lg font-bold text-primary-800 dark:text-primary-200">{fmt(totals[k], isFrench)}</p><p className="text-[10px] font-semibold text-slate-500">{lbl(RESULT_FIELDS, k, isFrench)}</p></div>
      ))}
    </div>
  )
}

const ListBlock = ({ title, items, render }) => (items.length ? (
  <div className="mt-4">
    <p className="mb-1 text-xs font-bold uppercase tracking-wide text-slate-500">{title} ({items.length})</p>
    <ul className="max-h-48 space-y-1 overflow-y-auto text-sm">{items.map((x) => <li key={x._id}>{render(x)}</li>)}</ul>
  </div>
) : null)
