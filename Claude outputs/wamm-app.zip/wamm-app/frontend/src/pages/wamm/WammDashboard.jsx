/**
 * Tableau de bord WAMM — page d'accueil de l'application interne.
 * Objectifs 2026-2030 vs réalisé, résultats des centres, pays, programmes,
 * activités récentes.
 */
import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, LabelList } from 'recharts'
import { Map as MapIcon, ArrowRight } from 'lucide-react'
import { useLanguage } from '../../i18n'
import wammApi from '../../services/wammApi'
import { PageHeader, Card, Stat, Progress, Loading, ErrorBox, Empty, Badge } from '../../components/wamm/ui'
import { L, fmt, fmtRange, PILLARS, PROGRAMME_STATUSES, MEC_PILLARS, MEC_COLORS, ACTIVITY_TYPES } from '../../components/wamm/labels'
import { WAMM_STATUS_LABELS } from '../../config/wammGeography'

export default function WammDashboard() {
  const { isFrench } = useLanguage()
  const { data, isLoading, isError, error } = useQuery({ queryKey: ['wamm-overview'], queryFn: wammApi.overview })

  if (isLoading) return <Loading label={isFrench ? 'Chargement du tableau de bord…' : 'Loading dashboard…'} />
  if (isError) return <ErrorBox error={error} label={isFrench ? 'Impossible de charger le tableau de bord WAMM.' : 'Unable to load the WAMM dashboard.'} />

  const { actuals = {}, targets = [], counts = {}, countries = [], centerResults = [], programmes = [], recentActivities = [] } = data || {}
  const globalTargets = targets.filter((t) => t.scope === 'global')
  const chartData = centerResults.slice(0, 14).map((c) => ({ name: c.name, value: c.churchesPlanted }))
  const totalChurches = centerResults.reduce((s, c) => s + c.churchesPlanted, 0)

  return (
    <div>
      <PageHeader
        eyebrow="West Africa Missionary Movements"
        title={isFrench ? 'Tableau de bord' : 'Dashboard'}
        subtitle={isFrench
          ? 'Catalyser les mouvements de faiseurs de disciples (MFD) parmi les peuples non atteints du Sahel et des îles de l’océan Indien. Catalyser. Équiper. Envoyer.'
          : 'Catalysing disciple-making movements among the unreached peoples of the Sahel and the Indian Ocean islands. Catalyse. Equip. Send.'}
        actions={<Link to="/carte" className="inline-flex items-center gap-2 rounded-lg bg-primary-700 px-4 py-2 text-sm font-semibold text-white hover:bg-primary-800"><MapIcon size={16} />{isFrench ? 'Ouvrir la carte' : 'Open the map'}</Link>}
      />

      {/* Indicateurs clés */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
        <Stat label={isFrench ? 'Partenaires actifs' : 'Active partners'} value={fmt(counts.activePartners, isFrench)} tone="green" />
        <Stat label="IFM" value={fmt(actuals.ifm, isFrench)} hint={isFrench ? 'en fonctionnement ou nouveaux' : 'running or new'} />
        <Stat label="CEIMP" value={fmt(actuals.ceimp, isFrench)} hint={isFrench ? 'en fonctionnement ou nouveaux' : 'running or new'} />
        <Stat label={isFrench ? 'Peuples prioritaires' : 'Focus peoples'} value={fmt(counts.focusPeoples, isFrench)} hint={`${fmt(actuals.peoplesEngaged, isFrench)} ${isFrench ? 'engagés' : 'engaged'}`} />
        <Stat label={isFrench ? 'Adoptions' : 'Adoptions'} value={fmt(counts.adoptions, isFrench)} hint={`${fmt(counts.unadoptedPeoples, isFrench)} ${isFrench ? 'peuple(s) sans adoptant' : 'without adopter'}`} tone="ochre" />
        <Stat label={isFrench ? 'Églises implantées' : 'Churches planted'} value={fmt(actuals.churchesPlanted, isFrench)} tone="green" />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-5">
        {/* Objectifs 2026-2030 */}
        <Card className="lg:col-span-3" title={isFrench ? 'Objectifs cumulés 2026-2030' : 'Cumulative targets 2026-2030'} action={<Link to="/objectifs" className="text-xs font-semibold text-primary-700 hover:underline">{isFrench ? 'Gérer' : 'Manage'}</Link>}>
          {globalTargets.length === 0 ? <Empty>{isFrench ? 'Aucun objectif saisi.' : 'No targets yet.'}</Empty> : (
            <div className="space-y-4">
              {globalTargets.map((t) => (
                <div key={t._id}>
                  <div className="mb-1 flex items-baseline justify-between gap-3 text-sm">
                    <span className="font-semibold text-slate-700 dark:text-slate-200">{isFrench ? t.label : t.labelEn}</span>
                    <span className="tabular-nums text-slate-500"><strong className="text-slate-900 dark:text-slate-100">{fmt(t.actual, isFrench)}</strong> / {fmt(t.value, isFrench)}{t.manual ? ' ✎' : ''}</span>
                  </div>
                  <Progress value={t.value ? (t.actual / t.value) * 100 : 0} color={t.progress >= 50 ? '#1f6d44' : '#c8792b'} />
                </div>
              ))}
              <p className="text-[11px] text-slate-400">{isFrench ? 'Réalisé calculé à partir des centres, peuples, adoptions et résultats saisis dans l’application (✎ = valeur saisie manuellement). Règle de multiplication : chaque leader formé implante au moins 5 églises de 15 disciples.' : 'Actuals are computed from the data entered in the app (✎ = manual value).'}</p>
            </div>
          )}
        </Card>

        {/* Pays */}
        <Card className="lg:col-span-2" title={isFrench ? 'Pays d’intervention' : 'Countries of intervention'} bodyClass="p-0">
          <ul className="divide-y divide-slate-100 dark:divide-slate-700">
            {countries.map((c) => {
              const st = WAMM_STATUS_LABELS[c.status] || WAMM_STATUS_LABELS.none
              return (
                <li key={c.code}>
                  <Link to={`/carte?pays=${c.code}`} className="flex items-center justify-between gap-3 px-5 py-2.5 hover:bg-slate-50 dark:hover:bg-slate-700/40">
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-semibold text-slate-800 dark:text-slate-100">{isFrench ? c.name : c.nameEn}</span>
                      <span className="block text-[11px] text-slate-500">{isFrench ? st.fr : st.en}</span>
                    </span>
                    <span className="flex shrink-0 gap-3 text-right text-[11px] text-slate-500">
                      <span><strong className="block text-sm text-slate-900 dark:text-slate-100">{c.centers}</strong>{isFrench ? 'centres' : 'centres'}</span>
                      <span><strong className="block text-sm text-slate-900 dark:text-slate-100">{c.focusPeoples}</strong>{isFrench ? 'peuples' : 'peoples'}</span>
                      <span><strong className="block text-sm text-slate-900 dark:text-slate-100">{c.adoptions}</strong>{isFrench ? 'adopt.' : 'adopt.'}</span>
                    </span>
                  </Link>
                </li>
              )
            })}
          </ul>
        </Card>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-3" title={isFrench ? 'Églises implantées par centre' : 'Churches planted per centre'} action={<span className="text-xs text-slate-500">{isFrench ? 'Total' : 'Total'} : {fmt(totalChurches, isFrench)}</span>}>
          {chartData.length === 0 ? <Empty>{isFrench ? 'Aucun résultat saisi pour les centres.' : 'No centre results yet.'}</Empty> : (
            <div style={{ height: Math.max(220, chartData.length * 28) }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} layout="vertical" margin={{ left: 8, right: 36, top: 4, bottom: 4 }}>
                  <XAxis type="number" hide />
                  <YAxis type="category" dataKey="name" width={150} tick={{ fontSize: 12, fill: '#475569' }} axisLine={false} tickLine={false} />
                  <Tooltip cursor={{ fill: '#f1f5f9' }} formatter={(v) => [v, isFrench ? 'Églises' : 'Churches']} />
                  <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={16}>
                    {chartData.map((d, i) => <Cell key={d.name} fill={i < 2 ? '#1f6d44' : '#c8792b'} />)}
                    <LabelList dataKey="value" position="right" style={{ fontSize: 12, fill: '#334155', fontWeight: 600 }} />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>

        <Card className="lg:col-span-2" title={isFrench ? 'Programmes' : 'Programmes'} action={<Link to="/programmes" className="text-xs font-semibold text-primary-700 hover:underline">{isFrench ? 'Tous' : 'All'}</Link>} bodyClass="p-0">
          <ul className="divide-y divide-slate-100 dark:divide-slate-700">
            {programmes.map((p) => (
              <li key={p._id}>
                <Link to={`/programmes/${p._id}`} className="flex items-center justify-between gap-3 px-5 py-3 hover:bg-slate-50 dark:hover:bg-slate-700/40">
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-semibold text-slate-800 dark:text-slate-100">{p.name}</span>
                    <span className="block text-[11px] text-slate-500">{L(PILLARS, p.pillar, isFrench)}</span>
                  </span>
                  <Badge color={p.status === 'active' ? '#1f6d44' : p.status === 'validation' ? '#d98e04' : '#64748b'}>{L(PROGRAMME_STATUSES, p.status, isFrench)}</Badge>
                </Link>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <Card className="mt-6" title={isFrench ? 'Activités récentes' : 'Recent activities'} action={<Link to="/bilan" className="inline-flex items-center gap-1 text-xs font-semibold text-primary-700 hover:underline">{isFrench ? 'Bilan M.E.C.' : 'M.E.C. report'}<ArrowRight size={12} /></Link>} bodyClass="p-0">
        {recentActivities.length === 0 ? <div className="p-5"><Empty>{isFrench ? 'Aucune activité.' : 'No activity.'}</Empty></div> : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-700">
            {recentActivities.map((a) => (
              <li key={a._id} className="flex flex-wrap items-center justify-between gap-2 px-5 py-3">
                <span className="min-w-0">
                  <span className="block text-sm font-semibold text-slate-800 dark:text-slate-100">{a.title || a.description}</span>
                  <span className="block text-[11px] text-slate-500">{fmtRange(a.date, a.endDate, isFrench)}{a.place ? ` · ${a.place}` : ''} · {L(ACTIVITY_TYPES, a.type, isFrench)}{a.partners?.length ? ` · ${a.partners.map((p) => p.acronym || p.name).join(', ')}` : ''}</span>
                </span>
                {a.mecPillar && <Badge color={MEC_COLORS[a.mecPillar]}>{L(MEC_PILLARS, a.mecPillar, isFrench)}</Badge>}
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  )
}
