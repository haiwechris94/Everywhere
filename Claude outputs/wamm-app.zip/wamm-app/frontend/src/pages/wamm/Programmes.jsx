/**
 * Programmes WAMM (remplacent les initiatives ESP300/YCS du réseau NG) :
 * centres d'équipement CI, adoption en Guinée, corridor Ghana-Togo-Bénin,
 * programme peul avec Mergon, compassion, prière.
 */
import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Plus, Pencil, Trash2, Map as MapIcon } from 'lucide-react'
import { useLanguage } from '../../i18n'
import wammApi from '../../services/wammApi'
import { PageHeader, Card, Table, Badge, Button, Modal, EntityForm, Loading, ErrorBox, Empty, CountryName, Progress, useCanEdit } from '../../components/wamm/ui'
import { programmeFields, resultFields } from '../../components/wamm/forms'
import { L, fmt, fmtRange, PILLARS, PROGRAMME_STATUSES, CENTER_TYPES, CENTER_STATUSES, RESULT_FIELDS, REACH_STATUSES, REACH_COLORS } from '../../components/wamm/labels'
import { REGION_BY_ID } from '../../config/wammGeography'

const STATUS_COLOR = { draft: '#94a3b8', validation: '#d98e04', active: '#1f6d44', completed: '#3f6fa8', paused: '#64748b' }
const PILLAR_COLOR = { dmm: '#1f6d44', compassion: '#b5544a', prayer: '#6b4fa0' }

export function ProgrammesList() {
  const { isFrench } = useLanguage()
  const { canEdit } = useCanEdit()
  const qc = useQueryClient()
  const navigate = useNavigate()
  const [creating, setCreating] = useState(false)
  const partners = useQuery({ queryKey: ['wamm-partners'], queryFn: () => wammApi.partners.list() })
  const { data = [], isLoading, isError, error } = useQuery({ queryKey: ['wamm-programmes'], queryFn: () => wammApi.programmes.list() })

  return (
    <div>
      <PageHeader
        eyebrow="WAMM"
        title={isFrench ? 'Programmes' : 'Programmes'}
        subtitle={isFrench ? 'Un réseau dynamique reposant sur trois piliers : mouvements de multiplication de disciples, ministère de compassion, mouvement de prière.' : 'A dynamic network resting on three pillars: disciple multiplication movements, compassion ministry, prayer movement.'}
        actions={canEdit && <Button onClick={() => setCreating(true)}><Plus size={16} />{isFrench ? 'Nouveau programme' : 'New programme'}</Button>}
      />
      {isLoading ? <Loading /> : isError ? <ErrorBox error={error} label={isFrench ? 'Erreur de chargement.' : 'Loading error.'} /> : data.length === 0 ? <Empty>{isFrench ? 'Aucun programme.' : 'No programme.'}</Empty> : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {data.map((p) => {
            const region = REGION_BY_ID[p.regionId]
            return (
              <Link key={p._id} to={`/programmes/${p._id}`} className="group rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md dark:border-slate-700 dark:bg-slate-800">
                <div className="flex items-start justify-between gap-3">
                  <span className="text-[11px] font-bold uppercase tracking-wide" style={{ color: PILLAR_COLOR[p.pillar] }}>{L(PILLARS, p.pillar, isFrench)}</span>
                  <Badge color={STATUS_COLOR[p.status]}>{L(PROGRAMME_STATUSES, p.status, isFrench)}</Badge>
                </div>
                <h2 className="mt-2 text-lg font-bold text-slate-900 group-hover:text-primary-700 dark:text-slate-100">{p.name}</h2>
                {region && <p className="mt-1 text-xs font-semibold" style={{ color: region.color }}>{isFrench ? region.name : region.nameEn}</p>}
                <p className="mt-2 line-clamp-3 text-sm text-slate-600 dark:text-slate-300">{p.description}</p>
                <p className="mt-3 text-xs text-slate-500">{(p.countryCodes || []).map((c, i) => <span key={c}>{i ? ', ' : ''}<CountryName code={c} isFrench={isFrench} /></span>)}{p.startYear ? ` · ${p.startYear}${p.endYear ? `-${p.endYear}` : ''}` : ''}</p>
              </Link>
            )
          })}
        </div>
      )}
      <Modal open={creating} title={isFrench ? 'Nouveau programme' : 'New programme'} onClose={() => setCreating(false)} wide>
        <EntityForm isFrench={isFrench} fields={programmeFields(isFrench, { partners: partners.data || [] })} initial={{ pillar: 'dmm', status: 'draft' }} onCancel={() => setCreating(false)}
          onSubmit={async (body) => { const p = await wammApi.programmes.create(body); await qc.invalidateQueries({ queryKey: ['wamm-programmes'] }); setCreating(false); navigate(`/programmes/${p._id}`) }} />
      </Modal>
    </div>
  )
}

export function ProgrammeDetail() {
  const { id } = useParams()
  const { isFrench } = useLanguage()
  const { canEdit, isAdmin } = useCanEdit()
  const qc = useQueryClient()
  const navigate = useNavigate()
  const [editing, setEditing] = useState(false)
  const [resultEdit, setResultEdit] = useState(null)
  const partners = useQuery({ queryKey: ['wamm-partners'], queryFn: () => wammApi.partners.list() })
  const meta = useQuery({ queryKey: ['wamm-meta'], queryFn: wammApi.meta })
  const { data: p, isLoading, isError, error } = useQuery({ queryKey: ['wamm-programme', id], queryFn: () => wammApi.programmes.get(id) })
  const refresh = () => Promise.all([['wamm-programme', id], ['wamm-programmes'], ['wamm-overview']].map((k) => qc.invalidateQueries({ queryKey: k })))

  if (isLoading) return <Loading />
  if (isError) return <ErrorBox error={error} label={isFrench ? 'Programme introuvable.' : 'Programme not found.'} />

  const region = REGION_BY_ID[p.regionId]
  const totals = p.totals || {}
  const centerTotals = (p.centers || []).reduce((acc, c) => { (c.results || []).forEach((r) => Object.keys(RESULT_FIELDS).forEach((k) => { acc[k] = (acc[k] || 0) + (r[k] || 0) })); return acc }, {})
  const indicators = meta.data?.indicators || {}

  return (
    <div>
      <Link to="/programmes" className="text-sm font-semibold text-primary-700 hover:underline">← {isFrench ? 'Programmes' : 'Programmes'}</Link>
      <PageHeader
        eyebrow={`${L(PILLARS, p.pillar, isFrench)} · ${p.key}`}
        title={p.name}
        subtitle={p.description}
        actions={<>
          {region && <Link to={`/carte?front=${region.id}`} className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 dark:text-slate-200"><MapIcon size={14} />{isFrench ? 'Voir sur la carte' : 'Show on map'}</Link>}
          {canEdit && <Button variant="ghost" onClick={() => setEditing(true)}><Pencil size={14} />{isFrench ? 'Modifier' : 'Edit'}</Button>}
          {isAdmin && <Button variant="danger" onClick={async () => {
            if (!window.confirm(isFrench ? 'Supprimer ce programme ?' : 'Delete this programme?')) return
            await wammApi.programmes.remove(id); await qc.invalidateQueries({ queryKey: ['wamm-programmes'] }); navigate('/programmes')
          }}><Trash2 size={14} /></Button>}
        </>}
      />
      <div className="grid gap-6 lg:grid-cols-3">
        <Card title={isFrench ? 'Fiche' : 'Profile'}>
          <dl className="space-y-2 text-sm">
            <div><dt className="text-xs text-slate-500">{isFrench ? 'Statut' : 'Status'}</dt><dd><Badge color={STATUS_COLOR[p.status]}>{L(PROGRAMME_STATUSES, p.status, isFrench)}</Badge></dd></div>
            {region && <div><dt className="text-xs text-slate-500">{isFrench ? 'Front / zone' : 'Front / area'}</dt><dd style={{ color: region.color }} className="font-semibold">{isFrench ? region.name : region.nameEn}</dd></div>}
            <div><dt className="text-xs text-slate-500">{isFrench ? 'Pays' : 'Countries'}</dt><dd>{(p.countryCodes || []).map((c, i) => <span key={c}>{i ? ', ' : ''}<CountryName code={c} isFrench={isFrench} link /></span>) }{!(p.countryCodes || []).length && '—'}</dd></div>
            <div><dt className="text-xs text-slate-500">{isFrench ? 'Partenaires' : 'Partners'}</dt><dd>{(p.partners || []).map((x, i) => <span key={x._id}>{i ? ', ' : ''}<Link className="text-primary-700 hover:underline" to={`/partenaires/${x._id}`}>{x.acronym || x.name}</Link></span>)}{!(p.partners || []).length && '—'}</dd></div>
            {p.startYear && <div><dt className="text-xs text-slate-500">{isFrench ? 'Période' : 'Period'}</dt><dd>{p.startYear}{p.endYear ? ` → ${p.endYear}` : ''}</dd></div>}
            {p.targetPeoples?.length > 0 && <div><dt className="text-xs text-slate-500">{isFrench ? 'Peuples visés' : 'Target peoples'}</dt><dd>{p.targetPeoples.join(', ')}</dd></div>}
          </dl>
        </Card>

        <Card className="lg:col-span-2" title={isFrench ? 'Cibles annuelles et résultats' : 'Annual targets and results'} action={canEdit && <Button variant="ghost" onClick={() => setResultEdit({})}><Plus size={14} />{isFrench ? 'Saisir des résultats' : 'Add results'}</Button>}>
          {(p.annualTargets || []).length === 0 && Object.keys(totals).every((k) => !totals[k]) && Object.keys(centerTotals).every((k) => !centerTotals[k]) ? (
            <Empty>{isFrench ? 'Pas encore de cibles ni de résultats.' : 'No targets or results yet.'}</Empty>
          ) : (
            <div className="space-y-4">
              {(p.annualTargets || []).map((t) => {
                const done = (totals[t.indicator] || 0) + (centerTotals[t.indicator] || 0)
                return (
                  <div key={t.indicator}>
                    <div className="mb-1 flex justify-between text-sm"><span className="font-semibold">{isFrench ? indicators[t.indicator]?.fr || t.indicator : indicators[t.indicator]?.en || t.indicator}</span><span className="tabular-nums text-slate-500"><strong className="text-slate-900 dark:text-slate-100">{fmt(done, isFrench)}</strong> / {fmt(t.value, isFrench)} {isFrench ? 'par an' : 'per year'}</span></div>
                    <Progress value={t.value ? (done / t.value) * 100 : 0} />
                  </div>
                )
              })}
              {(p.annualTargets || []).length === 0 && (
                <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
                  {Object.keys(RESULT_FIELDS).filter((k) => (totals[k] || 0) + (centerTotals[k] || 0)).map((k) => (
                    <div key={k} className="rounded-lg bg-primary-50 p-3 dark:bg-slate-700"><p className="text-xl font-bold text-primary-800 dark:text-primary-200">{fmt((totals[k] || 0) + (centerTotals[k] || 0), isFrench)}</p><p className="text-[11px] font-semibold text-slate-500">{L(RESULT_FIELDS, k, isFrench)}</p></div>
                  ))}
                </div>
              )}
              <p className="text-[11px] text-slate-400">{isFrench ? 'Résultats = résultats saisis sur le programme + résultats de ses centres.' : 'Results = programme results + its centres’ results.'}</p>
            </div>
          )}
          {(p.results || []).length > 0 && (
            <div className="mt-4 border-t border-slate-100 pt-3 dark:border-slate-700">
              <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">{isFrench ? 'Saisies au niveau du programme' : 'Programme-level entries'}</p>
              <ul className="space-y-1 text-sm">
                {p.results.map((r) => (
                  <li key={r._id}>
                    <button type="button" disabled={!canEdit} onClick={() => setResultEdit(r)} className="text-left hover:underline disabled:no-underline">
                      <strong>{r.periodLabel}</strong> — {Object.keys(RESULT_FIELDS).filter((k) => r[k]).map((k) => `${fmt(r[k], isFrench)} ${L(RESULT_FIELDS, k, isFrench).toLowerCase()}`).join(' · ') || '—'}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </Card>

        <Card className="lg:col-span-3" title={`${isFrench ? 'Centres du programme' : 'Programme centres'} (${(p.centers || []).length})`} bodyClass="p-0">
          <Table
            rows={p.centers || []}
            onRowClick={(r) => navigate(`/centres/${r._id}`)}
            empty={isFrench ? 'Aucun centre rattaché.' : 'No centre.'}
            columns={[
              { key: 'name', label: isFrench ? 'Centre' : 'Centre', render: (r) => <strong>{r.name}</strong> },
              { key: 'type', label: 'Type', render: (r) => L(CENTER_TYPES, r.type, isFrench) },
              { key: 'status', label: isFrench ? 'Statut' : 'Status', render: (r) => L(CENTER_STATUSES, r.status, isFrench) },
              { key: 'country', label: isFrench ? 'Pays' : 'Country', render: (r) => <CountryName code={r.countryCode} isFrench={isFrench} /> },
              { key: 'churches', right: true, label: isFrench ? 'Églises' : 'Churches', render: (r) => fmt((r.results || []).reduce((s, x) => s + (x.churchesPlanted || 0), 0), isFrench) },
            ]}
          />
        </Card>
        {(p.focusPeoples || []).length > 0 && (
          <Card className="lg:col-span-3" title={isFrench ? 'Peuples du programme' : 'Programme peoples'} bodyClass="p-0">
            <Table rows={p.focusPeoples} onRowClick={(r) => navigate(`/adoptions/${r._id}`)} empty="—"
              columns={[
                { key: 'name', label: isFrench ? 'Peuple' : 'People', render: (r) => <strong>{r.name}</strong> },
                { key: 'country', label: isFrench ? 'Pays' : 'Country', render: (r) => <CountryName code={r.countryCode} isFrench={isFrench} /> },
                { key: 'reach', label: isFrench ? 'Atteinte' : 'Reach', render: (r) => <Badge color={REACH_COLORS[r.reachStatus]}>{L(REACH_STATUSES, r.reachStatus, isFrench).split(' (')[0]}</Badge> },
              ]} />
          </Card>
        )}
      </div>
      <Modal open={editing} title={isFrench ? 'Modifier le programme' : 'Edit programme'} onClose={() => setEditing(false)} wide>
        <EntityForm isFrench={isFrench} fields={programmeFields(isFrench, { partners: partners.data || [] })} initial={p} onCancel={() => setEditing(false)}
          onSubmit={async (body) => { await wammApi.programmes.update(id, body); await refresh(); setEditing(false) }} />
      </Modal>
      <Modal open={!!resultEdit} title={isFrench ? 'Résultats du programme' : 'Programme results'} onClose={() => setResultEdit(null)} wide>
        {resultEdit && (
          <>
            <EntityForm isFrench={isFrench} fields={resultFields(isFrench)} initial={resultEdit} onCancel={() => setResultEdit(null)}
              onSubmit={async (body) => {
                if (resultEdit._id) await wammApi.programmes.updateResult(id, resultEdit._id, body); else await wammApi.programmes.addResult(id, body)
                await refresh(); setResultEdit(null)
              }} />
            {resultEdit._id && <button type="button" className="mt-3 text-sm font-semibold text-red-600 hover:underline" onClick={async () => { await wammApi.programmes.removeResult(id, resultEdit._id); await refresh(); setResultEdit(null) }}>{isFrench ? 'Supprimer cette période' : 'Delete this period'}</button>}
          </>
        )}
      </Modal>
    </div>
  )
}
