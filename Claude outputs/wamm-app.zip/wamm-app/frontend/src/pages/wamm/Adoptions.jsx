/**
 * Peuples prioritaires et adoptions — le tableau d'adoption de WAMM.
 * Par pays : peuples à adopter, lots, statut d'atteinte, ouvriers nécessaires,
 * adoptants. Fiche d'un peuple avec ses adoptions.
 */
import { useMemo, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Plus, Pencil, Trash2, MapPin, Heart as HandHeart } from 'lucide-react'
import { useLanguage } from '../../i18n'
import wammApi from '../../services/wammApi'
import { PageHeader, Card, Table, Badge, Button, Modal, EntityForm, Loading, ErrorBox, Empty, CountryName, Stat, Progress, useCanEdit } from '../../components/wamm/ui'
import { focusPeopleFields, adoptionFields } from '../../components/wamm/forms'
import { L, fmt, fmtDate, REACH_STATUSES, REACH_COLORS, PEOPLE_STAGES, STAGE_COLORS, COMMITMENTS } from '../../components/wamm/labels'
import { getCountry } from '../../config/wammGeography'

const useRefs = () => {
  const partners = useQuery({ queryKey: ['wamm-partners'], queryFn: () => wammApi.partners.list() })
  const programmes = useQuery({ queryKey: ['wamm-programmes'], queryFn: () => wammApi.programmes.list() })
  const peoples = useQuery({ queryKey: ['wamm-focus-peoples'], queryFn: () => wammApi.focusPeoples.list() })
  return { partners: partners.data || [], programmes: programmes.data || [], peoples: peoples.data || [] }
}

export function AdoptionBoard() {
  const { isFrench } = useLanguage()
  const { canEdit } = useCanEdit()
  const qc = useQueryClient()
  const navigate = useNavigate()
  const refs = useRefs()
  const [creating, setCreating] = useState(null) // 'people' | 'adoption'
  const [country, setCountry] = useState('')
  const [onlyUnadopted, setOnlyUnadopted] = useState(false)
  const peoplesQ = useQuery({ queryKey: ['wamm-focus-peoples'], queryFn: () => wammApi.focusPeoples.list() })
  const adoptionsQ = useQuery({ queryKey: ['wamm-adoptions'], queryFn: () => wammApi.adoptions.list() })

  const adoptionsByPeople = useMemo(() => {
    const m = {}
    ;(adoptionsQ.data || []).forEach((a) => { const k = a.focusPeople?._id; if (k) (m[k] = m[k] || []).push(a) })
    return m
  }, [adoptionsQ.data])

  const peoples = peoplesQ.data || []
  const adopters = (p) => Math.max((adoptionsByPeople[p._id] || []).length, p.declaredAdopters || 0)
  const countries = [...new Set(peoples.map((p) => p.countryCode))]
  const rows = peoples.filter((p) => (!country || p.countryCode === country) && (!onlyUnadopted || adopters(p) === 0))
  const scope = country ? peoples.filter((p) => p.countryCode === country) : peoples
  const workersNeeded = scope.reduce((s, p) => s + (p.workersNeeded || 0), 0)
  const workersInPlace = scope.reduce((s, p) => s + (p.workersInPlace || 0), 0)
  const pop = scope.reduce((s, p) => s + (p.population || 0), 0)

  const refresh = () => Promise.all(['wamm-focus-peoples', 'wamm-adoptions', 'wamm-map', 'wamm-overview'].map((k) => qc.invalidateQueries({ queryKey: [k] })))

  return (
    <div>
      <PageHeader
        eyebrow="WAMM"
        title={isFrench ? 'Peuples et adoptions' : 'Peoples and adoptions'}
        subtitle={isFrench ? 'Les peuples non atteints (PNA) que WAMM propose à l’adoption des églises et organisations, avec les ouvriers pionniers nécessaires. Objectif 2030 : 150 peuples engagés.' : 'Unreached peoples WAMM offers for adoption, with the pioneer workers needed. 2030 goal: 150 peoples engaged.'}
        actions={canEdit && <>
          <Button variant="ghost" onClick={() => setCreating('adoption')}><HandHeart size={16} />{isFrench ? 'Enregistrer une adoption' : 'Record an adoption'}</Button>
          <Button onClick={() => setCreating('people')}><Plus size={16} />{isFrench ? 'Nouveau peuple' : 'New people'}</Button>
        </>}
      />
      <div className="mb-4 flex flex-wrap gap-2">
        <button type="button" onClick={() => setCountry('')} className={`rounded-full px-3 py-1.5 text-sm font-semibold ${!country ? 'bg-primary-700 text-white' : 'bg-white text-slate-600 ring-1 ring-slate-200 dark:bg-slate-800'}`}>{isFrench ? 'Tous les pays' : 'All countries'}</button>
        {countries.map((c) => (
          <button key={c} type="button" onClick={() => setCountry(c)} className={`rounded-full px-3 py-1.5 text-sm font-semibold ${country === c ? 'bg-primary-700 text-white' : 'bg-white text-slate-600 ring-1 ring-slate-200 dark:bg-slate-800'}`}><CountryName code={c} isFrench={isFrench} /></button>
        ))}
        <label className="ml-auto flex items-center gap-2 text-sm"><input type="checkbox" className="accent-primary-700" checked={onlyUnadopted} onChange={(e) => setOnlyUnadopted(e.target.checked)} />{isFrench ? 'Seulement les peuples sans adoptant' : 'Only peoples without adopter'}</label>
      </div>
      <div className="mb-5 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label={isFrench ? 'Peuples prioritaires' : 'Focus peoples'} value={scope.length} />
        <Stat label="Population" value={fmt(pop, isFrench)} />
        <Stat label={isFrench ? 'Peuples sans adoptant' : 'Peoples without adopter'} value={scope.filter((p) => adopters(p) === 0).length} tone="ochre" />
        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-800">
          <p className="text-3xl font-bold tabular-nums text-slate-900 dark:text-slate-100">{workersInPlace}<span className="text-lg text-slate-400"> / {workersNeeded}</span></p>
          <p className="mt-1 text-xs font-semibold text-slate-600 dark:text-slate-300">{isFrench ? 'Ouvriers pionniers en place / nécessaires' : 'Pioneer workers in place / needed'}</p>
          <div className="mt-2"><Progress value={workersNeeded ? (workersInPlace / workersNeeded) * 100 : 0} color="#c8792b" /></div>
        </div>
      </div>
      {peoplesQ.isLoading ? <Loading /> : peoplesQ.isError ? <ErrorBox error={peoplesQ.error} label={isFrench ? 'Erreur de chargement.' : 'Loading error.'} /> : (
        <Card bodyClass="p-0">
          <Table
            rows={rows}
            onRowClick={(r) => navigate(`/adoptions/${r._id}`)}
            empty={isFrench ? 'Aucun peuple.' : 'No people.'}
            columns={[
              { key: 'name', label: isFrench ? 'Peuple' : 'People', render: (r) => <span><strong className="text-slate-900 dark:text-slate-100">{r.name}</strong>{!r.location?.coordinates?.length && <MapPin size={12} className="ml-1 inline text-amber-500" />}{r.area ? <span className="block text-[11px] text-slate-400">{r.area}</span> : null}</span> },
              { key: 'country', label: isFrench ? 'Pays' : 'Country', render: (r) => <CountryName code={r.countryCode} isFrench={isFrench} /> },
              { key: 'lot', label: 'Lot', render: (r) => r.lot || '—' },
              { key: 'population', label: 'Population', right: true, render: (r) => (r.population ? fmt(r.population, isFrench) : '—') },
              { key: 'reach', label: isFrench ? 'Atteinte' : 'Reach', render: (r) => <Badge color={REACH_COLORS[r.reachStatus]}>{L(REACH_STATUSES, r.reachStatus, isFrench).split(' (')[0]}</Badge> },
              { key: 'stage', label: isFrench ? 'Étape' : 'Stage', render: (r) => <Badge color={STAGE_COLORS[r.stage]}>{L(PEOPLE_STAGES, r.stage, isFrench)}</Badge> },
              { key: 'workers', label: isFrench ? 'Ouvriers' : 'Workers', right: true, render: (r) => (r.workersNeeded ? `${r.workersInPlace || 0} / ${r.workersNeeded}` : '—') },
              { key: 'adopters', label: isFrench ? 'Adoptants' : 'Adopters', right: true, render: (r) => { const n = adopters(r); return n ? <strong className="text-primary-700">{n}</strong> : <span className="text-amber-600">0</span> } },
            ]}
          />
        </Card>
      )}
      <Modal open={creating === 'people'} title={isFrench ? 'Nouveau peuple prioritaire' : 'New focus people'} onClose={() => setCreating(null)} wide>
        <EntityForm isFrench={isFrench} fields={focusPeopleFields(isFrench, refs)} initial={{ reachStatus: 'unreached', stage: 'identified', countryCode: country, locationApprox: true }} onCancel={() => setCreating(null)}
          onSubmit={async (body) => { const p = await wammApi.focusPeoples.create(body); await refresh(); setCreating(null); navigate(`/adoptions/${p._id}`) }} />
      </Modal>
      <Modal open={creating === 'adoption'} title={isFrench ? 'Enregistrer une adoption' : 'Record an adoption'} onClose={() => setCreating(null)} wide>
        <EntityForm isFrench={isFrench} fields={adoptionFields(isFrench, refs)} initial={{ commitments: ['prayer'], status: 'committed' }} onCancel={() => setCreating(null)}
          onSubmit={async (body) => { await wammApi.adoptions.create(body); await refresh(); setCreating(null) }} />
      </Modal>
    </div>
  )
}

export function FocusPeopleDetail() {
  const { id } = useParams()
  const { isFrench } = useLanguage()
  const { canEdit, isAdmin } = useCanEdit()
  const qc = useQueryClient()
  const navigate = useNavigate()
  const refs = useRefs()
  const [editing, setEditing] = useState(false)
  const [adopting, setAdopting] = useState(null)
  const { data: p, isLoading, isError, error } = useQuery({ queryKey: ['wamm-focus-people', id], queryFn: () => wammApi.focusPeoples.get(id) })
  const refresh = () => Promise.all([['wamm-focus-people', id], ['wamm-focus-peoples'], ['wamm-adoptions'], ['wamm-map'], ['wamm-overview']].map((k) => qc.invalidateQueries({ queryKey: k })))

  if (isLoading) return <Loading />
  if (isError) return <ErrorBox error={error} label={isFrench ? 'Peuple introuvable.' : 'People not found.'} />

  const adoptions = p.adoptions || []
  const country = getCountry(p.countryCode)
  return (
    <div>
      <Link to="/adoptions" className="text-sm font-semibold text-primary-700 hover:underline">← {isFrench ? 'Peuples et adoptions' : 'Peoples and adoptions'}</Link>
      <PageHeader
        eyebrow={`${isFrench ? 'Peuple prioritaire' : 'Focus people'} · ${country ? (isFrench ? country.name : country.nameEn) : p.countryCode}`}
        title={p.name}
        subtitle={p.alternateNames?.length ? `${isFrench ? 'Aussi appelé' : 'Also called'} : ${p.alternateNames.join(', ')}` : null}
        actions={<>
          {p.location?.coordinates?.length === 2 && <Link to={`/carte?peuple=${p._id}`} className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 dark:text-slate-200"><MapPin size={14} />{isFrench ? 'Voir sur la carte' : 'Show on map'}</Link>}
          {canEdit && <Button variant="ghost" onClick={() => setEditing(true)}><Pencil size={14} />{isFrench ? 'Modifier' : 'Edit'}</Button>}
          {canEdit && <Button onClick={() => setAdopting({ focusPeople: p._id, commitments: ['prayer'], status: 'committed' })}><HandHeart size={14} />{isFrench ? 'Ajouter un adoptant' : 'Add adopter'}</Button>}
          {isAdmin && <Button variant="danger" onClick={async () => {
            if (!window.confirm(isFrench ? 'Supprimer ce peuple et ses adoptions ?' : 'Delete this people?')) return
            await wammApi.focusPeoples.remove(id); await refresh(); navigate('/adoptions')
          }}><Trash2 size={14} /></Button>}
        </>}
      />
      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-5">
        <Stat label="Population" value={p.population ? fmt(p.population, isFrench) : '—'} />
        <Stat label={isFrench ? 'Atteinte' : 'Reach'} value={<span className="text-xl" style={{ color: REACH_COLORS[p.reachStatus] }}>{L(REACH_STATUSES, p.reachStatus, isFrench).split(' (')[0]}</span>} />
        <Stat label={isFrench ? 'Étape WAMM' : 'WAMM stage'} value={<span className="text-xl" style={{ color: STAGE_COLORS[p.stage] }}>{L(PEOPLE_STAGES, p.stage, isFrench)}</span>} />
        <Stat label={isFrench ? 'Ouvriers en place / nécessaires' : 'Workers in place / needed'} value={`${p.workersInPlace || 0} / ${p.workersNeeded || 0}`} tone="ochre" />
        <Stat label={isFrench ? 'Adoptants' : 'Adopters'} value={Math.max(adoptions.length, p.declaredAdopters || 0)} tone="green" hint={p.declaredAdopters > adoptions.length ? (isFrench ? `${p.declaredAdopters} annoncés, ${adoptions.length} saisis` : `${p.declaredAdopters} announced`) : null} />
      </div>
      <div className="grid gap-6 lg:grid-cols-3">
        <Card title={isFrench ? 'Fiche' : 'Profile'}>
          <dl className="space-y-2 text-sm">
            {p.lot && <div><dt className="text-xs text-slate-500">{isFrench ? 'Lot d’adoption' : 'Adoption lot'}</dt><dd>{p.lot}</dd></div>}
            {p.otherCountryCodes?.length > 0 && <div><dt className="text-xs text-slate-500">{isFrench ? 'Présent aussi dans' : 'Also in'}</dt><dd>{p.otherCountryCodes.map((c, i) => <span key={c}>{i ? ', ' : ''}<CountryName code={c} isFrench={isFrench} /></span>)}</dd></div>}
            {p.religion && <div><dt className="text-xs text-slate-500">{isFrench ? 'Religion' : 'Religion'}</dt><dd>{p.religion}</dd></div>}
            {p.area && <div><dt className="text-xs text-slate-500">{isFrench ? 'Zone' : 'Area'}</dt><dd>{p.area}</dd></div>}
            {p.programme && <div><dt className="text-xs text-slate-500">{isFrench ? 'Programme' : 'Programme'}</dt><dd><Link className="text-primary-700 hover:underline" to={`/programmes/${p.programme._id}`}>{p.programme.name}</Link></dd></div>}
            {p.isPastoral && <div><dd className="rounded bg-amber-50 px-2 py-1 text-xs text-amber-800">{isFrench ? 'Peuple pastoral / nomade' : 'Pastoral / nomadic people'}</dd></div>}
            {p.adoptionEvent && <div><dt className="text-xs text-slate-500">{isFrench ? 'Événement d’adoption' : 'Adoption event'}</dt><dd>{p.adoptionEvent}</dd></div>}
            {p.notes && <div><dt className="text-xs text-slate-500">Notes</dt><dd>{p.notes}</dd></div>}
          </dl>
        </Card>
        <Card className="lg:col-span-2" title={`${isFrench ? 'Adoptants' : 'Adopters'} (${adoptions.length})`} bodyClass="p-0">
          {p.declaredAdopters > adoptions.length && (
            <p className="border-b border-amber-100 bg-amber-50 px-5 py-2 text-xs text-amber-800">
              {isFrench ? `${p.declaredAdopters} adoptants annoncés (${p.adoptionEvent || 'source WAMM'}) : enregistrez-les ici un par un pour suivre leurs engagements.` : `${p.declaredAdopters} adopters announced: record them here one by one.`}
            </p>
          )}
          <Table
            rows={adoptions}
            onRowClick={canEdit ? (r) => setAdopting({ ...r, focusPeople: p._id }) : undefined}
            empty={isFrench ? 'Aucun adoptant enregistré.' : 'No adopter recorded.'}
            columns={[
              { key: 'who', label: isFrench ? 'Adoptant' : 'Adopter', render: (r) => (r.partner ? <Link onClick={(e) => e.stopPropagation()} className="font-semibold text-primary-700 hover:underline" to={`/partenaires/${r.partner._id}`}>{r.partner.name}</Link> : <strong>{r.adopterName || '—'}</strong>) },
              { key: 'commitments', label: isFrench ? 'Engagements' : 'Commitments', render: (r) => (r.commitments || []).map((c) => L(COMMITMENTS, c, isFrench)).join(', ') },
              { key: 'workers', label: isFrench ? 'Ouvriers' : 'Workers', right: true, render: (r) => r.workersCommitted || '—' },
              { key: 'date', label: 'Date', render: (r) => (r.date ? fmtDate(r.date, isFrench) : '—') },
            ]}
          />
        </Card>
        {(p.centers || []).length > 0 && (
          <Card className="lg:col-span-3" title={isFrench ? 'Centres qui servent ce peuple' : 'Centres serving this people'}>
            <ul className="flex flex-wrap gap-2">{p.centers.map((c) => <li key={c._id}><Link className="rounded-full bg-slate-100 px-3 py-1 text-sm hover:bg-slate-200 dark:bg-slate-700" to={`/centres/${c._id}`}>{c.name}</Link></li>)}</ul>
          </Card>
        )}
      </div>
      <Modal open={editing} title={isFrench ? 'Modifier le peuple' : 'Edit people'} onClose={() => setEditing(false)} wide>
        <EntityForm isFrench={isFrench} fields={focusPeopleFields(isFrench, refs)} initial={p} onCancel={() => setEditing(false)}
          onSubmit={async (body) => { await wammApi.focusPeoples.update(id, body); await refresh(); setEditing(false) }} />
      </Modal>
      <Modal open={!!adopting} title={adopting?._id ? (isFrench ? 'Modifier l’adoption' : 'Edit adoption') : (isFrench ? 'Ajouter un adoptant' : 'Add adopter')} onClose={() => setAdopting(null)} wide>
        {adopting && (
          <>
            <EntityForm isFrench={isFrench} fields={adoptionFields(isFrench, refs)} initial={adopting} onCancel={() => setAdopting(null)}
              onSubmit={async (body) => {
                if (adopting._id) await wammApi.adoptions.update(adopting._id, body); else await wammApi.adoptions.create(body)
                await refresh(); setAdopting(null)
              }} />
            {adopting._id && isAdmin && (
              <button type="button" className="mt-3 text-sm font-semibold text-red-600 hover:underline" onClick={async () => {
                if (!window.confirm(isFrench ? 'Supprimer cette adoption ?' : 'Delete this adoption?')) return
                await wammApi.adoptions.remove(adopting._id); await refresh(); setAdopting(null)
              }}>{isFrench ? 'Supprimer cette adoption' : 'Delete this adoption'}</button>
            )}
          </>
        )}
      </Modal>
    </div>
  )
}
