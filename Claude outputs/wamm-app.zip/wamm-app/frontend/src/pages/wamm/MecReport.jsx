/**
 * Bilan M.E.C. — Mobilisation, Équipement, Coaching — pour une période
 * (par défaut le semestre en cours). Reproduit le bilan semestriel WAMM :
 * activités majeures, partenaires appuyés, sessions, peuples, terrains, pays,
 * tableau chronologique.
 */
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Printer, Plus } from 'lucide-react'
import { activitiesApi } from '../../services/api'
import { useLanguage } from '../../i18n'
import wammApi from '../../services/wammApi'
import { PageHeader, Card, Stat, Table, Badge, Loading, ErrorBox, Button, Modal, EntityForm, countryOptions, useCanEdit } from '../../components/wamm/ui'
import { L, fmtRange, options, MEC_PILLARS, MEC_COLORS, ACTIVITY_TYPES, PILLARS } from '../../components/wamm/labels'

const semester = (year, half) => ({ from: `${year}-${half === 1 ? '01-01' : '07-01'}`, to: `${year}-${half === 1 ? '06-30' : '12-31'}` })

export default function MecReport() {
  const { isFrench } = useLanguage()
  const now = new Date()
  const [period, setPeriod] = useState(() => semester(now.getFullYear(), now.getMonth() < 6 ? 1 : 2))
  const { data, isLoading, isError, error } = useQuery({ queryKey: ['wamm-mec', period], queryFn: () => wammApi.mecReport(period) })
  const years = [now.getFullYear() - 1, now.getFullYear(), now.getFullYear() + 1]
  const qc = useQueryClient()
  const { canEdit } = useCanEdit()
  const [adding, setAdding] = useState(false)
  const partnersQ = useQuery({ queryKey: ['wamm-partners'], queryFn: () => wammApi.partners.list() })
  const centersQ = useQuery({ queryKey: ['wamm-centers'], queryFn: () => wammApi.centers.list() })
  const programmesQ = useQuery({ queryKey: ['wamm-programmes'], queryFn: () => wammApi.programmes.list() })
  const fr = isFrench
  const mecOptions = Object.keys(MEC_PILLARS).filter((k) => k !== 'unclassified').map((k) => ({ value: k, label: L(MEC_PILLARS, k, fr) }))
  const activityFields = [
    { name: 'title', label: fr ? 'Intitulé' : 'Title', required: true, full: true },
    { name: 'mecPillar', label: fr ? 'Pilier M.E.C.' : 'M.E.C. pillar', type: 'select', options: mecOptions, required: true },
    { name: 'type', label: 'Type', type: 'select', options: options(ACTIVITY_TYPES, fr), required: true },
    { name: 'date', label: fr ? 'Début' : 'Start', type: 'date', required: true },
    { name: 'endDate', label: fr ? 'Fin' : 'End', type: 'date' },
    { name: 'countryCode', label: fr ? 'Pays' : 'Country', type: 'select', options: countryOptions(fr) },
    { name: 'place', label: fr ? 'Lieu' : 'Place' },
    { name: 'partners', label: fr ? 'Partenaires appuyés' : 'Partners supported', type: 'multiselect', options: (partnersQ.data || []).map((p) => ({ value: p._id, label: p.acronym || p.name })) },
    { name: 'peoples', label: fr ? 'Peuples atteints (virgules)' : 'Peoples reached (comma separated)', type: 'tags', full: true },
    { name: 'center', label: fr ? 'Centre' : 'Centre', type: 'select', options: (centersQ.data || []).map((c) => ({ value: c._id, label: c.name })) },
    { name: 'programme', label: 'Programme', type: 'select', options: (programmesQ.data || []).map((p) => ({ value: p._id, label: p.name })) },
    { name: 'wammPillar', label: fr ? 'Pilier WAMM' : 'WAMM pillar', type: 'select', options: options(PILLARS, fr) },
    { name: 'sessionsCount', label: fr ? 'Sessions de formation / coaching' : 'Training / coaching sessions', type: 'number', min: 0 },
    { name: 'participants', label: fr ? 'Participants' : 'Participants', type: 'number', min: 0 },
    { name: 'description', label: 'Description', type: 'textarea', required: true, help: fr ? '10 caractères minimum.' : 'At least 10 characters.' },
  ]

  return (
    <div>
      <PageHeader
        eyebrow={isFrench ? 'Mobilisation · Équipement · Coaching' : 'Mobilisation · Equipping · Coaching'}
        title={isFrench ? 'Bilan M.E.C.' : 'M.E.C. report'}
        subtitle={isFrench ? 'Calculé automatiquement à partir des activités saisies (classez chaque activité dans un pilier M.E.C. et rattachez-la aux partenaires et aux peuples concernés).' : 'Computed from the activities entered.'}
        actions={<>
          {canEdit && <Button onClick={() => setAdding(true)}><Plus size={14} />{isFrench ? 'Saisir une activité' : 'Add an activity'}</Button>}
          <Link to="/activities" className="rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 dark:text-slate-200">{isFrench ? 'Toutes les activités' : 'All activities'}</Link>
          <Button variant="ghost" onClick={() => window.print()}><Printer size={14} />{isFrench ? 'Imprimer' : 'Print'}</Button>
        </>}
      />
      <div className="mb-5 flex flex-wrap items-end gap-2">
        {years.flatMap((y) => [1, 2].map((h) => {
          const s = semester(y, h); const on = s.from === period.from && s.to === period.to
          return <button key={`${y}-${h}`} type="button" onClick={() => setPeriod(s)} className={`rounded-full px-3 py-1.5 text-sm font-semibold ${on ? 'bg-primary-700 text-white' : 'bg-white text-slate-600 ring-1 ring-slate-200 dark:bg-slate-800'}`}>{isFrench ? `S${h} ${y}` : `H${h} ${y}`}</button>
        }))}
        <label className="ml-2 text-xs text-slate-500">{isFrench ? 'Du' : 'From'} <input type="date" value={period.from} onChange={(e) => setPeriod({ ...period, from: e.target.value })} className="rounded border border-slate-300 px-2 py-1 text-sm dark:bg-slate-800" /></label>
        <label className="text-xs text-slate-500">{isFrench ? 'au' : 'to'} <input type="date" value={period.to} onChange={(e) => setPeriod({ ...period, to: e.target.value })} className="rounded border border-slate-300 px-2 py-1 text-sm dark:bg-slate-800" /></label>
      </div>
      <Modal open={adding} title={isFrench ? 'Nouvelle activité M.E.C.' : 'New M.E.C. activity'} onClose={() => setAdding(false)} wide>
        <EntityForm isFrench={isFrench} fields={activityFields} initial={{ mecPillar: 'equipement', type: 'training', wammPillar: 'dmm', date: new Date().toISOString().slice(0, 10) }}
          onCancel={() => setAdding(false)}
          onSubmit={async (body) => {
            const b = { ...body }
            Object.keys(b).forEach((k) => { if (b[k] === '' || b[k] === null) delete b[k] })
            await activitiesApi.create(b)
            await Promise.all([qc.invalidateQueries({ queryKey: ['wamm-mec'] }), qc.invalidateQueries({ queryKey: ['wamm-overview'] }), qc.invalidateQueries({ queryKey: ['activities'] })])
            setAdding(false)
          }} />
      </Modal>
      {isLoading ? <Loading /> : isError ? <ErrorBox error={error} label={isFrench ? 'Erreur de chargement.' : 'Loading error.'} /> : (
        <>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
            <Stat label={isFrench ? 'activités majeures' : 'major activities'} value={data.summary.activities} tone="green" />
            <Stat label={isFrench ? 'partenaires appuyés' : 'partners supported'} value={data.summary.partnersSupported} />
            <Stat label={isFrench ? 'sessions de formation et coaching' : 'training & coaching sessions'} value={data.summary.trainingSessions} />
            <Stat label={isFrench ? 'peuples atteints' : 'people groups reached'} value={data.summary.peoplesReached} tone="ochre" />
            <Stat label={isFrench ? 'terrains évalués ou visités' : 'fields assessed or visited'} value={data.summary.fieldsAssessed} />
            <Stat label={isFrench ? 'pays' : 'countries'} value={data.summary.countries} hint={data.countries.map((c) => c.name).join(', ')} />
          </div>
          <div className="mt-6 grid gap-6 lg:grid-cols-3">
            <Card title={isFrench ? 'Répartition M.E.C.' : 'M.E.C. breakdown'}>
              <div className="space-y-3">
                {data.byPillar.map((b) => (
                  <div key={b.pillar}>
                    <div className="mb-1 flex justify-between text-sm"><span className="font-semibold" style={{ color: MEC_COLORS[b.pillar] }}>{L(MEC_PILLARS, b.pillar, isFrench)}</span><span className="tabular-nums">{b.count}</span></div>
                    <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-700"><div className="h-2 rounded-full" style={{ width: `${data.summary.activities ? (b.count / data.summary.activities) * 100 : 0}%`, background: MEC_COLORS[b.pillar] }} /></div>
                  </div>
                ))}
              </div>
              {data.peoples.length > 0 && <><p className="mb-1 mt-5 text-xs font-bold uppercase tracking-wide text-slate-500">{isFrench ? 'Peuples atteints' : 'Peoples reached'}</p><p className="text-sm">{data.peoples.join(', ')}</p></>}
            </Card>
            <Card className="lg:col-span-2" title={isFrench ? 'Partenaires appuyés et type d’appui' : 'Partners supported'} bodyClass="p-0">
              <Table rows={data.partners.map((p, i) => ({ ...p, key: p._id || `n${i}` }))} empty={isFrench ? 'Aucun partenaire lié aux activités de la période.' : 'No partner.'}
                columns={[
                  { key: 'name', label: isFrench ? 'Partenaire' : 'Partner', render: (p) => (p._id ? <Link className="font-semibold text-primary-700 hover:underline" to={`/partenaires/${p._id}`}>{p.name}</Link> : <strong>{p.name}</strong>) },
                  { key: 'activities', label: isFrench ? 'Appui' : 'Support', render: (p) => p.activities.join(' · ') },
                ]} />
            </Card>
          </div>
          <Card className="mt-6" title={isFrench ? `Tableau récapitulatif — ${data.summary.activities} activités` : `Summary table — ${data.summary.activities} activities`} bodyClass="p-0">
            <Table rows={data.timeline} empty={<span>{isFrench ? 'Aucune activité sur la période.' : 'No activity in this period.'} <button type="button" className="font-semibold text-primary-700 hover:underline" onClick={() => { const f = new Date(period.from); const prevHalf = f.getMonth() < 6 ? 2 : 1; const y = prevHalf === 2 ? f.getFullYear() - 1 : f.getFullYear(); setPeriod(semester(y, prevHalf)) }}>{isFrench ? '← Semestre précédent' : '← Previous semester'}</button></span>}
              columns={[
                { key: 'period', label: isFrench ? 'Période' : 'Period', render: (a) => <span className="whitespace-nowrap text-slate-600">{fmtRange(a.date, a.endDate, isFrench)}</span> },
                { key: 'title', label: isFrench ? 'Activité' : 'Activity', render: (a) => <span><strong>{a.title}</strong>{a.place ? <span className="text-slate-400"> · {a.place}</span> : null}</span> },
                { key: 'type', label: 'Type', render: (a) => L(ACTIVITY_TYPES, a.type, isFrench) },
                { key: 'mec', label: 'M.E.C.', render: (a) => (a.mecPillar ? <Badge color={MEC_COLORS[a.mecPillar]}>{L(MEC_PILLARS, a.mecPillar, isFrench)}</Badge> : '—') },
                { key: 'partners', label: isFrench ? 'Partenaires' : 'Partners', render: (a) => a.partners.join(', ') || '—' },
              ]} />
          </Card>
        </>
      )}
    </div>
  )
}
