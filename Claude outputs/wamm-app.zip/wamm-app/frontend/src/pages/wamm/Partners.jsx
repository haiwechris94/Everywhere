/**
 * Partenaires WAMM — liste, création, fiche.
 */
import { useMemo, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Plus, Pencil, Trash2 } from 'lucide-react'
import { useLanguage } from '../../i18n'
import wammApi from '../../services/wammApi'
import { PageHeader, Card, Table, Badge, Button, Modal, EntityForm, Loading, ErrorBox, Empty, CountryName, useCanEdit } from '../../components/wamm/ui'
import { partnerFields } from '../../components/wamm/forms'
import { L, fmtRange, PARTNER_TYPES, PARTNER_LEVELS, PARTNER_STATUSES, CENTER_TYPES, CENTER_STATUSES, REACH_STATUSES, REACH_COLORS, ACTIVITY_TYPES } from '../../components/wamm/labels'

const STATUS_COLOR = { active: '#1f6d44', prospect: '#d98e04', paused: '#64748b', ended: '#94a3b8' }

export function PartnersList() {
  const { isFrench } = useLanguage()
  const { canEdit } = useCanEdit()
  const qc = useQueryClient()
  const navigate = useNavigate()
  const [creating, setCreating] = useState(false)
  const [q, setQ] = useState('')
  const [type, setType] = useState('')
  const { data = [], isLoading, isError, error } = useQuery({ queryKey: ['wamm-partners'], queryFn: () => wammApi.partners.list() })

  const rows = useMemo(() => data.filter((p) =>
    (!type || p.type === type) && (!q || `${p.name} ${p.acronym}`.toLowerCase().includes(q.toLowerCase()))), [data, q, type])

  return (
    <div>
      <PageHeader
        eyebrow="WAMM"
        title={isFrench ? 'Partenaires' : 'Partners'}
        subtitle={isFrench ? 'Églises, missions et organisations avec lesquelles WAMM catalyse les mouvements. Objectif 2030 : 120 partenaires stratégiques.' : 'Churches, missions and organisations WAMM works with. 2030 goal: 120 strategic partners.'}
        actions={canEdit && <Button onClick={() => setCreating(true)}><Plus size={16} />{isFrench ? 'Nouveau partenaire' : 'New partner'}</Button>}
      />
      <div className="mb-4 flex flex-wrap gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={isFrench ? 'Rechercher…' : 'Search…'} className="w-64 rounded-lg border border-slate-300 px-3 py-2 text-sm dark:bg-slate-800" />
        <select value={type} onChange={(e) => setType(e.target.value)} className="rounded-lg border border-slate-300 px-3 py-2 text-sm dark:bg-slate-800">
          <option value="">{isFrench ? 'Tous les types' : 'All types'}</option>
          {Object.keys(PARTNER_TYPES).map((k) => <option key={k} value={k}>{L(PARTNER_TYPES, k, isFrench)}</option>)}
        </select>
      </div>
      {isLoading ? <Loading /> : isError ? <ErrorBox error={error} label={isFrench ? 'Erreur de chargement.' : 'Loading error.'} /> : (
        <Card bodyClass="p-0">
          <Table
            rows={rows}
            onRowClick={(r) => navigate(`/partenaires/${r._id}`)}
            empty={isFrench ? 'Aucun partenaire.' : 'No partner.'}
            columns={[
              { key: 'name', label: isFrench ? 'Partenaire' : 'Partner', render: (r) => <span><strong className="text-slate-900 dark:text-slate-100">{r.name}</strong>{r.acronym && r.acronym !== r.name ? <span className="text-slate-400"> · {r.acronym}</span> : null}</span> },
              { key: 'type', label: 'Type', render: (r) => L(PARTNER_TYPES, r.type, isFrench) },
              { key: 'levels', label: isFrench ? 'Partenariat' : 'Partnership', render: (r) => (r.levels || []).map((l) => L(PARTNER_LEVELS, l, isFrench)).join(', ') },
              { key: 'countries', label: isFrench ? 'Pays' : 'Countries', render: (r) => (r.countryCodes || []).map((c, i) => <span key={c}>{i ? ', ' : ''}<CountryName code={c} isFrench={isFrench} /></span>) },
              { key: 'status', label: isFrench ? 'Statut' : 'Status', render: (r) => <Badge color={STATUS_COLOR[r.status]}>{L(PARTNER_STATUSES, r.status, isFrench)}</Badge> },
            ]}
          />
        </Card>
      )}
      <Modal open={creating} title={isFrench ? 'Nouveau partenaire' : 'New partner'} onClose={() => setCreating(false)} wide>
        <EntityForm
          isFrench={isFrench}
          fields={partnerFields(isFrench)}
          initial={{ type: 'church', status: 'active', levels: ['field'] }}
          onCancel={() => setCreating(false)}
          onSubmit={async (body) => {
            const p = await wammApi.partners.create(body)
            await qc.invalidateQueries({ queryKey: ['wamm-partners'] })
            setCreating(false)
            navigate(`/partenaires/${p._id}`)
          }}
        />
      </Modal>
    </div>
  )
}

export function PartnerDetail() {
  const { id } = useParams()
  const { isFrench } = useLanguage()
  const { canEdit, isAdmin } = useCanEdit()
  const qc = useQueryClient()
  const navigate = useNavigate()
  const [editing, setEditing] = useState(false)
  const { data: p, isLoading, isError, error } = useQuery({ queryKey: ['wamm-partner', id], queryFn: () => wammApi.partners.get(id) })

  if (isLoading) return <Loading />
  if (isError) return <ErrorBox error={error} label={isFrench ? 'Partenaire introuvable.' : 'Partner not found.'} />

  return (
    <div>
      <Link to="/partenaires" className="text-sm font-semibold text-primary-700 hover:underline">← {isFrench ? 'Partenaires' : 'Partners'}</Link>
      <PageHeader
        eyebrow={L(PARTNER_TYPES, p.type, isFrench)}
        title={p.name}
        subtitle={p.description}
        actions={<>
          {canEdit && <Button variant="ghost" onClick={() => setEditing(true)}><Pencil size={14} />{isFrench ? 'Modifier' : 'Edit'}</Button>}
          {isAdmin && <Button variant="danger" onClick={async () => {
            if (!window.confirm(isFrench ? 'Supprimer ce partenaire ? Ses centres et adoptions sont conservés.' : 'Delete this partner?')) return
            await wammApi.partners.remove(id); await qc.invalidateQueries({ queryKey: ['wamm-partners'] }); navigate('/partenaires')
          }}><Trash2 size={14} />{isFrench ? 'Supprimer' : 'Delete'}</Button>}
        </>}
      />
      <div className="grid gap-6 lg:grid-cols-3">
        <Card title={isFrench ? 'Fiche' : 'Profile'}>
          <dl className="space-y-2 text-sm">
            <div><dt className="text-xs text-slate-500">{isFrench ? 'Statut' : 'Status'}</dt><dd><Badge color={STATUS_COLOR[p.status]}>{L(PARTNER_STATUSES, p.status, isFrench)}</Badge></dd></div>
            <div><dt className="text-xs text-slate-500">{isFrench ? 'Partenariat' : 'Partnership'}</dt><dd>{(p.levels || []).map((l) => L(PARTNER_LEVELS, l, isFrench)).join(', ') || '—'}</dd></div>
            <div><dt className="text-xs text-slate-500">{isFrench ? 'Pays' : 'Countries'}</dt><dd>{(p.countryCodes || []).map((c, i) => <span key={c}>{i ? ', ' : ''}<CountryName code={c} isFrench={isFrench} link /></span>)}</dd></div>
            {p.city && <div><dt className="text-xs text-slate-500">{isFrench ? 'Siège' : 'HQ'}</dt><dd>{p.city}</dd></div>}
            {p.since && <div><dt className="text-xs text-slate-500">{isFrench ? 'Depuis' : 'Since'}</dt><dd>{p.since}</dd></div>}
            {p.website && <div><dt className="text-xs text-slate-500">Web</dt><dd><a className="text-primary-700 hover:underline" href={p.website} target="_blank" rel="noreferrer">{p.website}</a></dd></div>}
            {p.supportTypes?.length > 0 && <div><dt className="text-xs text-slate-500">{isFrench ? 'Appui de WAMM' : 'WAMM support'}</dt><dd><ul className="list-disc pl-4">{p.supportTypes.map((s) => <li key={s}>{s}</li>)}</ul></dd></div>}
          </dl>
        </Card>
        <Card className="lg:col-span-2" title={`${isFrench ? 'Centres' : 'Centres'} (${p.centers?.length || 0})`} bodyClass="p-0">
          <Table
            rows={p.centers || []}
            onRowClick={(r) => navigate(`/centres/${r._id}`)}
            empty={isFrench ? 'Aucun centre rattaché.' : 'No centre.'}
            columns={[
              { key: 'name', label: isFrench ? 'Centre' : 'Centre', render: (r) => <strong>{r.name}</strong> },
              { key: 'type', label: 'Type', render: (r) => L(CENTER_TYPES, r.type, isFrench) },
              { key: 'status', label: isFrench ? 'Statut' : 'Status', render: (r) => L(CENTER_STATUSES, r.status, isFrench) },
              { key: 'country', label: isFrench ? 'Pays' : 'Country', render: (r) => <CountryName code={r.countryCode} isFrench={isFrench} /> },
            ]}
          />
        </Card>
        <Card className="lg:col-span-3" title={`${isFrench ? 'Peuples engagés ou adoptés' : 'Peoples engaged or adopted'} (${p.adoptions?.length || 0})`} bodyClass="p-0">
          <Table
            rows={(p.adoptions || []).filter((a) => a.focusPeople)}
            onRowClick={(r) => navigate(`/adoptions/${r.focusPeople._id}`)}
            empty={isFrench ? 'Aucun peuple.' : 'No people.'}
            columns={[
              { key: 'name', label: isFrench ? 'Peuple' : 'People', render: (r) => <strong>{r.focusPeople.name}</strong> },
              { key: 'country', label: isFrench ? 'Pays' : 'Country', render: (r) => <CountryName code={r.focusPeople.countryCode} isFrench={isFrench} /> },
              { key: 'status', label: isFrench ? 'Statut' : 'Status', render: (r) => <Badge color={REACH_COLORS[r.focusPeople.reachStatus]}>{L(REACH_STATUSES, r.focusPeople.reachStatus, isFrench).split(' (')[0]}</Badge> },
              { key: 'event', label: isFrench ? 'Événement' : 'Event', render: (r) => r.event || '—' },
            ]}
          />
        </Card>
        <Card className="lg:col-span-3" title={isFrench ? 'Activités avec ce partenaire' : 'Activities with this partner'} bodyClass="p-0">
          {(p.activities || []).length === 0 ? <div className="p-5"><Empty>{isFrench ? 'Aucune activité.' : 'No activity.'}</Empty></div> : (
            <ul className="divide-y divide-slate-100 dark:divide-slate-700">
              {p.activities.map((a) => (
                <li key={a._id} className="px-5 py-3 text-sm"><strong>{a.title || a.description}</strong><span className="block text-xs text-slate-500">{fmtRange(a.date, a.endDate, isFrench)}{a.place ? ` · ${a.place}` : ''} · {L(ACTIVITY_TYPES, a.type, isFrench)}</span></li>
              ))}
            </ul>
          )}
        </Card>
      </div>
      <Modal open={editing} title={isFrench ? 'Modifier le partenaire' : 'Edit partner'} onClose={() => setEditing(false)} wide>
        <EntityForm
          isFrench={isFrench}
          fields={partnerFields(isFrench)}
          initial={p}
          onCancel={() => setEditing(false)}
          onSubmit={async (body) => {
            await wammApi.partners.update(id, body)
            await Promise.all([qc.invalidateQueries({ queryKey: ['wamm-partner', id] }), qc.invalidateQueries({ queryKey: ['wamm-partners'] })])
            setEditing(false)
          }}
        />
      </Modal>
    </div>
  )
}
