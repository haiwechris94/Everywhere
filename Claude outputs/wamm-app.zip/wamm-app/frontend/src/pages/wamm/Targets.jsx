/**
 * Objectifs WAMM — cumulés 2026-2030 et cibles par pays ou programme.
 */
import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Plus } from 'lucide-react'
import { useLanguage } from '../../i18n'
import wammApi from '../../services/wammApi'
import { PageHeader, Card, Table, Button, Modal, EntityForm, Loading, ErrorBox, Progress, CountryName, useCanEdit, countryOptions } from '../../components/wamm/ui'
import { fmt } from '../../components/wamm/labels'

export default function Targets() {
  const { isFrench } = useLanguage()
  const { canEdit, isAdmin } = useCanEdit()
  const qc = useQueryClient()
  const [edit, setEdit] = useState(null)
  const overview = useQuery({ queryKey: ['wamm-overview'], queryFn: wammApi.overview })
  const meta = useQuery({ queryKey: ['wamm-meta'], queryFn: wammApi.meta })
  const programmes = useQuery({ queryKey: ['wamm-programmes'], queryFn: () => wammApi.programmes.list() })
  const refresh = () => qc.invalidateQueries({ queryKey: ['wamm-overview'] })

  if (overview.isLoading) return <Loading />
  if (overview.isError) return <ErrorBox error={overview.error} label={isFrench ? 'Erreur de chargement.' : 'Loading error.'} />

  const targets = overview.data?.targets || []
  const indicators = meta.data?.indicators || {}
  const fields = [
    { name: 'indicator', label: isFrench ? 'Indicateur' : 'Indicator', type: 'select', required: true, options: Object.keys(indicators).map((k) => ({ value: k, label: isFrench ? indicators[k].fr : indicators[k].en })) },
    { name: 'scope', label: isFrench ? 'Portée' : 'Scope', type: 'select', options: [{ value: 'global', label: isFrench ? 'Globale (WAMM)' : 'Global' }, { value: 'country', label: isFrench ? 'Pays' : 'Country' }, { value: 'programme', label: 'Programme' }] },
    { name: 'countryCode', label: isFrench ? 'Pays (si portée pays)' : 'Country (if country scope)', type: 'select', options: countryOptions(isFrench) },
    { name: 'programme', label: isFrench ? 'Programme (si portée programme)' : 'Programme', type: 'select', nullable: true, options: (programmes.data || []).map((p) => ({ value: p._id, label: p.name })) },
    { name: 'periodLabel', label: isFrench ? 'Période' : 'Period', placeholder: '2026-2030' },
    { name: 'value', label: isFrench ? 'Cible' : 'Target', type: 'number', required: true, min: 0 },
    { name: 'manualActual', label: isFrench ? 'Réalisé saisi à la main (optionnel)' : 'Manual actual (optional)', type: 'number', min: 0, help: isFrench ? 'Laisser vide pour utiliser le calcul automatique.' : 'Leave empty for automatic calculation.' },
    { name: 'notes', label: 'Notes', type: 'textarea' },
  ]
  const scopeLabel = (t) => (t.scope === 'global' ? (isFrench ? 'WAMM' : 'WAMM') : t.scope === 'country' ? <CountryName code={t.countryCode} isFrench={isFrench} /> : (t.programme?.name || 'Programme'))

  return (
    <div>
      <PageHeader
        eyebrow="WAMM"
        title={isFrench ? 'Objectifs' : 'Targets'}
        subtitle={isFrench ? 'Cibles cumulées 2026-2030 et cibles annuelles. Le réalisé se met à jour automatiquement à partir des centres, peuples, adoptions et résultats saisis.' : 'Cumulative 2026-2030 and annual targets. Actuals update automatically from the data entered.'}
        actions={canEdit && <Button onClick={() => setEdit({ scope: 'global', periodLabel: '2026-2030' })}><Plus size={16} />{isFrench ? 'Nouvel objectif' : 'New target'}</Button>}
      />
      <Card bodyClass="p-0">
        <Table
          rows={targets}
          onRowClick={canEdit ? (t) => setEdit({ ...t, programme: t.programme?._id || null, manualActual: t.manualActual ?? '' }) : undefined}
          empty={isFrench ? 'Aucun objectif.' : 'No target.'}
          columns={[
            { key: 'label', label: isFrench ? 'Indicateur' : 'Indicator', render: (t) => <strong>{isFrench ? t.label : t.labelEn}</strong> },
            { key: 'scope', label: isFrench ? 'Portée' : 'Scope', render: scopeLabel },
            { key: 'period', label: isFrench ? 'Période' : 'Period', render: (t) => t.periodLabel },
            { key: 'actual', label: isFrench ? 'Réalisé' : 'Actual', right: true, render: (t) => `${fmt(t.actual, isFrench)}${t.manual ? ' ✎' : ''}` },
            { key: 'value', label: isFrench ? 'Cible' : 'Target', right: true, render: (t) => fmt(t.value, isFrench) },
            { key: 'progress', label: '%', render: (t) => <div className="flex w-40 items-center gap-2"><Progress value={t.value ? (t.actual / t.value) * 100 : 0} color={t.progress >= 50 ? '#1f6d44' : '#c8792b'} /><span className="w-10 text-right text-xs tabular-nums">{t.value ? `${Math.round((t.actual / t.value) * 1000) / 10}` : 0}</span></div> },
          ]}
        />
      </Card>
      <p className="mt-3 text-xs text-slate-500">{isFrench ? 'Repère : « chaque leader formé implante au moins 5 églises de 15 disciples » — 3 000 églises représentent 600 leaders formés et 45 000 disciples.' : 'Rule of thumb: each trained leader plants at least 5 churches of 15 disciples.'}</p>
      <Modal open={!!edit} title={edit?._id ? (isFrench ? 'Modifier l’objectif' : 'Edit target') : (isFrench ? 'Nouvel objectif' : 'New target')} onClose={() => setEdit(null)} wide>
        {edit && (
          <>
            <EntityForm isFrench={isFrench} fields={fields} initial={edit} onCancel={() => setEdit(null)}
              onSubmit={async (body) => {
                const b = { ...body, manualActual: body.manualActual === undefined ? null : body.manualActual }
                if (edit._id) await wammApi.targets.update(edit._id, b); else await wammApi.targets.create(b)
                await refresh(); setEdit(null)
              }} />
            {edit._id && isAdmin && <button type="button" className="mt-3 text-sm font-semibold text-red-600 hover:underline" onClick={async () => { await wammApi.targets.remove(edit._id); await refresh(); setEdit(null) }}>{isFrench ? 'Supprimer cet objectif' : 'Delete this target'}</button>}
          </>
        )}
      </Modal>
    </div>
  )
}
