import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { reportingApi, regionAdminApi } from '../services/reportingApi'
import { StateLoading, StateError, StateEmpty } from './geography/geoComponents'
import { useLanguage } from '../i18n'
import { useAuth } from '../context/AuthContext'
import { RegionForm } from '../components/admin/RegionCountryForms'

const Regions = () => {
  const { isFrench } = useLanguage()
  const queryClient = useQueryClient()
  const navigate = useNavigate()
  const { user } = useAuth()
  const canManage = !!user && (user.role === 'admin' || user.role === 'supervisor')
  const [creating, setCreating] = useState(false)
  const [editRegion, setEditRegion] = useState(null)

  const { data, isLoading, isError } = useQuery({
    queryKey: ['ng-regions'],
    queryFn: async () => {
      const res = await reportingApi.getRegions()
      return Array.isArray(res?.data?.data) ? res.data.data : []
    },
  })

  const regions = data || []

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.14em] text-accent-600">WAMM</p>
          <h1 className="text-4xl font-bold text-slate-900 dark:text-slate-100">{isFrench ? 'Régions et fronts' : 'Regions and fronts'}</h1>
          <p className="mt-2 max-w-3xl text-sm text-slate-600 dark:text-slate-300">{isFrench ? "Toute l'Afrique en 5 sous-régions, la ceinture de sécurité du Sahel et les fronts opérationnels de WAMM. Un pays appartient à une sous-région et peut faire partie de plusieurs fronts." : 'All of Africa in 5 sub-regions, the Sahel Security Belt and WAMM operational fronts.'}</p>
        </div>
        {canManage && !creating && (
          <button
            type="button"
            onClick={() => setCreating(true)}
            className="rounded-lg bg-primary-700 px-3 py-2 text-sm font-semibold text-white hover:bg-primary-800 disabled:opacity-60"
          >
            {isFrench ? '＋ Créer une région' : '＋ New region'}
          </button>
        )}
      </div>

      {creating && (
        <RegionForm
          mode="create"
          onCancel={() => setCreating(false)}
          onSubmit={async (body) => {
            await regionAdminApi.createRegion(body)
            await queryClient.invalidateQueries({ queryKey: ['ng-regions'] })
            setCreating(false)
          }}
          isFrench={isFrench}
        />
      )}

      {isLoading ? (
        <StateLoading label={isFrench ? 'Chargement des régions…' : 'Loading regions…'} />
      ) : isError ? (
        <StateError label={isFrench ? 'Impossible de charger les régions.' : 'Unable to load regions.'} />
      ) : regions.length === 0 ? (
        <StateEmpty label={isFrench ? 'Aucune région disponible.' : 'No region available.'} />
      ) : (
        <div className="space-y-8">
          {[
            ['front', isFrench ? 'Fronts WAMM' : 'WAMM fronts'],
            ['belt', isFrench ? 'Ceinture sahélienne' : 'Sahel belt'],
            ['subregion', isFrench ? "Sous-régions de l'Afrique" : 'African sub-regions'],
            ['custom', isFrench ? 'Régions personnalisées' : 'Custom regions'],
          ].map(([kind, title]) => {
            const list = regions.filter((r) => (r.kind || 'custom') === kind)
            if (!list.length) return null
            return (
              <section key={kind}>
                <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-500">{title}</h2>
                <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                  {list.map((region) => (
                    <Link
                      key={region.id}
                      to={`/regions/${region.id}`}
                      className="relative flex flex-col rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-5 shadow-sm hover:shadow-md transition-shadow"
                    >
                      {canManage && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.preventDefault()
                            e.stopPropagation()
                            setEditRegion(region)
                          }}
                          className="absolute right-2 top-2 rounded border px-2 py-1 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                        >
                          {isFrench ? '✎ Modifier' : '✎ Edit'}
                        </button>
                      )}
                      <span className="mb-3 h-1.5 w-12 rounded-full" style={{ background: region.color || '#94a3b8' }} />
                      <h3 className="pr-16 text-xl font-bold text-slate-900 dark:text-slate-100">{isFrench ? region.name : (region.nameEn || region.name)}</h3>
                      {region.description && <p className="mt-1 line-clamp-3 text-sm text-slate-500 dark:text-slate-400">{region.description}</p>}
                      <p className="mt-3 text-xs text-slate-500">
                        <strong className="text-slate-700 dark:text-slate-200">{region.countryCount}</strong> {isFrench ? 'pays' : 'countries'} · {(region.countries || []).slice(0, 6).map((c) => (isFrench ? c.name : (c.nameEn || c.name))).join(', ')}{(region.countries || []).length > 6 ? '…' : ''}
                      </p>
                      <span className="mt-3 text-xs font-semibold text-primary-700">
                        <button type="button" onClick={(e) => { e.preventDefault(); e.stopPropagation(); navigate(`/carte?front=${region.id}`) }} className="hover:underline">{isFrench ? 'Voir sur la carte →' : 'Show on map →'}</button>
                      </span>
                    </Link>
                  ))}
                </div>
              </section>
            )
          })}
        </div>
      )}

      {editRegion && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="max-w-lg w-full bg-white rounded-xl p-4 max-h-[85vh] overflow-y-auto">
            <RegionForm
              mode="edit"
              initial={editRegion}
              onCancel={() => setEditRegion(null)}
              onSubmit={async (body) => {
                await regionAdminApi.updateRegion(editRegion.id, body)
                await queryClient.invalidateQueries({ queryKey: ['ng-regions'] })
                setEditRegion(null)
              }}
              isFrench={isFrench}
            />
            {editRegion.isCustom && (
              <div className="mt-3 border-t border-slate-200 pt-3">
                <button
                  type="button"
                  onClick={async () => {
                    const ok = window.confirm(
                      isFrench ? 'Supprimer cette région ?' : 'Delete this region?'
                    )
                    if (!ok) return
                    await regionAdminApi.deleteRegion(editRegion.id)
                    await queryClient.invalidateQueries({ queryKey: ['ng-regions'] })
                    setEditRegion(null)
                  }}
                  className="rounded border border-red-300 px-3 py-1.5 text-sm font-semibold text-red-600 hover:bg-red-50"
                >
                  {isFrench ? 'Supprimer la région' : 'Delete region'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export default Regions
