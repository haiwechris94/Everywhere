import { AFRICA_COUNTRIES } from './wammGeography'
/**
 * Country Configuration
 * 
 * Contains configuration for all supported countries including:
 * - ISO codes (alpha-2 and alpha-3)
 * - Names in French and English
 * - Geographic center coordinates
 * - Default zoom levels
 * - Bounding boxes for map fitting
 * 
 * @author WAMM
 * @version 1.0.0
 */

// Default country code
export const DEFAULT_COUNTRY = 'CI' // Côte d'Ivoire, pôle historique de WAMM

// Cameroon-specific exports for backward compatibility
export const CAMEROON_CENTER = [7.3697, 12.3547]
export const CAMEROON_ZOOM = 6

// Country configurations — toute l'Afrique (config/wammGeography.js)
export const COUNTRY_CONFIG = Object.fromEntries(
  AFRICA_COUNTRIES.map((c) => [c.code, { ...c, region: c.subregion }])
)

// List of available country codes for selection components
export const AVAILABLE_COUNTRIES = Object.keys(COUNTRY_CONFIG)

/**
 * Get country configuration by code
 * @param {string} code - ISO 3166-1 alpha-2 or alpha-3 code
 * @returns {Object|null} Country configuration or null if not found
 */
export const getCountryConfig = (code) => {
  if (!code) return null
  
  const upperCode = code.toUpperCase()
  
  // Try direct match (alpha-2)
  if (COUNTRY_CONFIG[upperCode]) {
    return COUNTRY_CONFIG[upperCode]
  }
  
  // Try alpha-3 match
  const country = Object.values(COUNTRY_CONFIG).find(c => c.code3 === upperCode)
  return country || null
}

/**
 * Get all countries in a specific region
 * @param {string} region - Region name (e.g., 'Central Africa')
 * @returns {Array} Array of country configurations
 */
export const getCountriesByRegion = (region) => {
  return Object.values(COUNTRY_CONFIG).filter(c => c.region === region)
}

/**
 * Get country name by code
 * @param {string} code - ISO country code
 * @param {string} language - Language code ('en' or 'fr')
 * @returns {string} Country name
 */
export const getCountryName = (code, language = 'fr') => {
  const config = getCountryConfig(code)
  if (!config) return code
  return language === 'en' ? config.nameEn : config.name
}

/**
 * Get country bounds as Leaflet LatLngBounds
 * @param {string} code - ISO country code
 * @returns {Array|null} Bounds array [[south, west], [north, east]]
 */
export const getCountryBounds = (code) => {
  const config = getCountryConfig(code)
  return config?.bounds || null
}

/**
 * Get country center coordinates
 * @param {string} code - ISO country code
 * @returns {Array|null} Center coordinates [lat, lng]
 */
export const getCountryCenter = (code) => {
  const config = getCountryConfig(code)
  return config?.center || null
}

/**
 * Convert country code to name for database queries
 * @param {string} code - ISO country code
 * @returns {string|null} Country name in French (for database)
 */
export const countryCodeToDbName = (code) => {
  const config = getCountryConfig(code)
  return config?.name || null
}

export default COUNTRY_CONFIG

/**
 * Zoom-aware Voronoi/admin display configuration.
 * Each level defines the inclusive zoom range at which it should be rendered.
 *
 * - village        : finest level — actual Voronoi polygons around villages
 * - arrondissement : admin level 3 (commune / sub-prefecture)
 * - departement    : admin level 2 (department / prefecture)
 * - region         : admin level 1 (region / province)
 */
export const VORONOI_ZOOM_CONFIG = {
  village:        { minZoom: 10, maxZoom: 22, label: 'Village' },
  arrondissement: { minZoom: 9,  maxZoom: 9,  label: 'Arrondissement' },
  departement:    { minZoom: 7,  maxZoom: 8,  label: 'Département' },
  region:         { minZoom: 0,  maxZoom: 6,  label: 'Région' },
}

/**
 * Returns the Voronoi/admin display level for a given map zoom.
 * Falls back to 'region' for any zoom that doesn't match (defensive).
 * @param {number} zoom - current Leaflet map zoom
 * @returns {'village'|'arrondissement'|'departement'|'region'}
 */
export function getVoronoiLevelForZoom(zoom) {
  const z = Number(zoom)
  if (!Number.isFinite(z)) return 'region'
  for (const level of Object.keys(VORONOI_ZOOM_CONFIG)) {
    const { minZoom, maxZoom } = VORONOI_ZOOM_CONFIG[level]
    if (z >= minZoom && z <= maxZoom) return level
  }
  return 'region'
}

/**
 * Returns true when the given level should be visible at the given zoom.
 * @param {'village'|'arrondissement'|'departement'|'region'} level
 * @param {number} zoom
 * @returns {boolean}
 */
export function shouldShowVoronoiAtLevel(level, zoom) {
  const cfg = VORONOI_ZOOM_CONFIG[level]
  if (!cfg) return false
  const z = Number(zoom)
  if (!Number.isFinite(z)) return false
  return z >= cfg.minZoom && z <= cfg.maxZoom
}