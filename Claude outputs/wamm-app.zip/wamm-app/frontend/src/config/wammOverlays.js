/**
 * Tracés thématiques de la carte WAMM (positions INDICATIVES, [lat, lng]).
 *
 * - SAHEL_SECURITY_BELT : la « Ceinture de sécurité du Sahel » telle que WAMM
 *   la dessine sur ses cartes (trait rouge) : nord de la Guinée et de la Côte
 *   d'Ivoire, nord du Ghana (Tamale), Kara, Djougou, puis le pôle Tchad-Cameroun.
 * - GREAT_GREEN_WALL : tracé de la Grande Muraille Verte (Dakar → Djibouti),
 *   dont la ceinture missiologique suit presque exactement la géographie.
 *
 * À ajuster par WAMM si besoin : ce sont des lignes de repère, pas des frontières.
 */
export const SAHEL_SECURITY_BELT = [
  [10.9, -14.2], [10.6, -12.2], [10.3, -10.4], [10.1, -8.6], [10.35, -7.4], [10.45, -6.2],
  [10.25, -5.0], [9.95, -3.6], [9.6, -2.7], [9.4, -0.85], [9.35, 0.4], [9.55, 1.19],
  [9.7, 1.67], [9.85, 2.8], [10.0, 5.0], [9.9, 8.0], [9.6, 11.0], [9.3, 13.4], [9.9, 15.2], [10.6, 16.8], [11.2, 18.6],
]

export const GREAT_GREEN_WALL = [
  [14.7, -17.4], [15.4, -15.1], [15.6, -13.3], [14.4, -11.4], [15.2, -9.6], [14.5, -4.2], [13.6, -2.4],
  [14.0, 0.0], [14.2, 1.45], [14.9, 5.3], [13.8, 9.0], [13.3, 12.6], [13.6, 14.6], [14.1, 15.3], [13.8, 20.8],
  [13.45, 22.45], [13.6, 25.35], [13.2, 30.2], [13.2, 32.7], [14.0, 35.4], [15.45, 36.4], [15.78, 38.45],
  [13.5, 39.5], [11.6, 43.1],
]

// Emprise de l'Afrique pour la vue initiale
export const AFRICA_BOUNDS = [[-36, -26], [38.5, 58]]
export const AFRICA_CENTER = [4, 17]
