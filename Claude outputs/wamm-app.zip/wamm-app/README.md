# WAMM — application interne

Application de travail de **WAMM (West Africa Missionary Movements)**, le cabinet de recherche qui catalyse les mouvements de faiseurs de disciples (MFD) parmi les peuples non atteints du Sahel et des îles de l'océan Indien.

C'est une instance **séparée** de l'application EVERYWHERE (church-planting-map) : elle a son propre code, sa propre base de données et ses propres comptes. Aucune donnée de MOPROSADEV n'y est copiée.

## Ce que fait l'application

| Module | Route | Rôle |
|---|---|---|
| Tableau de bord | `/dashboard` | Objectifs 2026-2030 et réalisé, pays d'intervention, églises par centre, programmes, activités récentes |
| Carte WAMM | `/carte` | Toute l'Afrique, interactive : présence WAMM par pays, sous-régions, fronts, ceinture de sécurité du Sahel, Grande Muraille Verte, centres, peuples prioritaires et adoptions, axes d'envoi, découpages administratifs |
| Objectifs | `/objectifs` | Cibles cumulées 2026-2030 et cibles annuelles (globales, par pays ou par programme) |
| Bilan M.E.C. | `/bilan` | Bilan semestriel Mobilisation / Équipement / Coaching calculé à partir des activités |
| Partenaires | `/partenaires` | Églises, missions et organisations partenaires |
| Centres et instituts | `/centres` | IFM, CEIMP, alphabétisation, santé, agriculture, radio, centres pivots, avec saisie des résultats par période |
| Peuples et adoptions | `/adoptions` | Peuples prioritaires, lots, ouvriers pionniers nécessaires, adoptants |
| Programmes | `/programmes` | Programmes WAMM (centres CI, Guinée, corridor GTB, programme peul-Mergon, compassion, prière) |
| Terrain MFD | `/regions`, `/countries`, `/people-groups`, `/engagements`, `/activities`, `/dmm-reporting` | Les outils de suivi DMM/MFD hérités d'EVERYWHERE, étendus à toute l'Afrique |

### Régions

Les régions du réseau NG (FCA, AWA, FWA) ont été supprimées. Elles sont remplacées par :

- **5 sous-régions** couvrant les 55 pays et territoires africains : Ouest, Centre, Est, Australe, Nord ;
- **la ceinture sahélienne de sécurité** (pays cités dans la projection WAMM) ;
- **5 fronts WAMM** : Côte d'Ivoire, Guinée Conakry, corridor Ghana-Togo-Bénin, front peul Togo-Bénin-Tchad, îles de l'océan Indien.

Source unique : `backend/config/wammGeography.js` (copie identique dans `frontend/src/config/wammGeography.js`).

## Démarrer en local

Prérequis : Node.js 18 ou plus, une base MongoDB **dédiée à WAMM** (locale ou Atlas).

```bash
# 1. API
cd backend
cp .env.example .env        # puis renseigner MONGODB_URI (base « wamm »), JWT_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD
npm install
npm run seed:wamm           # données de démarrage WAMM + compte administrateur
npm run dev                 # http://localhost:5000

# 2. Interface
cd ../frontend
cp .env.example .env
npm install
npm run dev                 # http://localhost:8082
```

Se connecter avec `ADMIN_EMAIL` / `ADMIN_PASSWORD`, puis changer le mot de passe.

`npm run seed:wamm` est idempotent (il met à jour sans dupliquer). `npm run seed:wamm:reset` vide d'abord les collections WAMM.

### Référentiel des peuples (Joshua Project)

Renseigner `JP_API_KEY` (clé personnelle Joshua Project) dans `backend/.env`, puis `npm run jp:sync`. La synchronisation est limitée à l'Afrique (`JP_CONTINENT=africa`) et tourne ensuite chaque semaine.

## Données de démarrage

`backend/seed/wammSeed2026.js` reprend **uniquement** le contenu de la présentation « Sahel Security Belt — WAMM Global Projection 2024-2030 » :

- 9 partenaires (Vineyard CI, Emmanuel World Mission, MIDJ, Elim, Word of God, Vineyard Guinée, Église Wesleyenne, Christ pour Tous, Mergon) ;
- 48 centres : réseau de Côte d'Ivoire (carte murale et résultats d'avril-mai 2026), instituts et centres prévus en Guinée, centres pivots et centres en prospection du corridor, centres du programme peul ;
- 24 peuples prioritaires : peuples engagés en CI, les dix peuples à adopter en Guinée (lots, population, statut, ouvriers), peuples adoptés à Lomé, Peuls ;
- les objectifs 2026-2030, les cibles annuelles du programme peul, 12 axes d'envoi et les 18 activités du premier semestre 2026.

Les positions marquées « indicatives » ont été lues sur les cartes WAMM de la présentation. Les lieux qu'on n'a pas pu situer (Miani, Amanikro, Boko, Liabo, Kounongou, Bambara) n'ont pas de coordonnées : la carte les liste « à géolocaliser ».

## Déploiement

Même schéma que pour EVERYWHERE, avec des services **nouveaux** :

- base MongoDB Atlas : une base `wamm` (ou un cluster) distincte ;
- API : un nouveau service Render (racine `backend`, commande `npm start`), variables de `.env.example` ;
- interface : un nouveau projet Vercel (racine `frontend`, `npm run build`, dossier `dist`), avec `VITE_API_URL` = URL de l'API.

## Géographie

- `frontend/public/data/africa_countries.geojson` : frontières des 55 pays et territoires (Natural Earth, simplifiées) ;
- `frontend/public/data/africa_admin1.geojson` et `frontend/public/data/admin/<ISO3>_admin1.geojson` : premier niveau administratif de chaque pays (Natural Earth).

Les polygones de villages ne sont pas livrés. Ils s'ajoutent pays par pays : extraction OSM, puis déclaration dans `VILLAGE_FILES` (`frontend/src/pages/UnifiedMapView.jsx`).
